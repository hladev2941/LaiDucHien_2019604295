
$(window).ready(function(){
	$(".nav-toggle").click(function(){
		$(".menus-box").toggleClass("show");
		$(".overlay-common").addClass("show");
	});
	$(".overlay-common,.menus-box .close").click(function(){
		$(".menus-box").removeClass("show");
		$(".overlay-common").removeClass("show");
	});


})
