import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NZ_DATE_LOCALE, NZ_I18N, vi_VN } from 'ng-zorro-antd/i18n';
import { vi as VN} from 'date-fns/locale';
import { registerLocaleData } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NotFoundComponent } from './404-notfound/app.component';
import { ModuleShare } from './ng-zorro-antd.module';
import { TokenInterceptor } from './config/token-intercepter';
import { AuthLoginComponent } from './authentication/auth-login/auth-login.component';
import { AuthForgotPasswordComponent } from './authentication/auth-forgot-password/auth-forgot-password.component';
import vi from '@angular/common/locales/vi';
import { AuthGuardService } from './authentication/auth-guard.service';
registerLocaleData(vi);

@NgModule({
  declarations: [
    AppComponent,
    NotFoundComponent,
    AuthLoginComponent,
    AuthForgotPasswordComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    BrowserAnimationsModule,
    ModuleShare
  ],
  providers: [
    { provide: NZ_I18N, useValue: vi_VN },
    { provide: NZ_DATE_LOCALE, useValue: VN},
    {
      provide: HTTP_INTERCEPTORS,
      useClass: TokenInterceptor,
      multi: true
    },
    [AuthGuardService],
  
],
  bootstrap: [AppComponent],
})
export class AppModule { }
