export interface ISelect2 {
    id?: number;
    code?:string,
    name?: string;
    fullName?: string;
    status?: number;
    page?: number;
    size?: number;
  }
  
  export class Select2 implements ISelect2 {
    constructor(
      public id?: number,
      public code?:string,
      public name?: string,
      public fullName?: string,
      public status?: number,
      public page?: number,
      public size?: number,
    ) {}
  }
  