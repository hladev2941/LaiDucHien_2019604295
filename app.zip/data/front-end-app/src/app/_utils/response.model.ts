export interface ResponseAPI<T>{
    data: T,
    err_code?: number;
    message?: string;
    total?:number;
  }
export interface RemoteResponseAPI<T>{
  message?: string;
  object: T;
}

export interface RemotePaginationResponse<T>{
  data: T;
  maxSize: number;
  page: number;
  propertiesSort: null | string;
  sort: null | string;
  totalElement: number;
  totalPages: number;
}

export interface PaginationRemoteResponseAPI<T> extends
  RemoteResponseAPI<RemotePaginationResponse<T>>{
}
