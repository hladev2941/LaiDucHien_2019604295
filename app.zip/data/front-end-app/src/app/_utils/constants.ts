export class Constants {
    public static HOST: string = 'http://localhost:8080';
}
