import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { NotFoundComponent } from './404-notfound/app.component';
import { AuthLoginComponent } from './authentication/auth-login/auth-login.component';
import { 
  AuthGuardService as AuthGuard 
} from "./authentication/auth-guard.service";
const routes: Routes = [
  { path: 'login', component: AuthLoginComponent },
  { path: 'pages', loadChildren: () => import('./pages/pages.module').then(m => m.PagesModule), canActivate: [AuthGuard]},
  { path: '', redirectTo: 'pages/home', pathMatch: 'full'},
  { path: '**', component: NotFoundComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
