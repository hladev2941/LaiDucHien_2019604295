export interface IAutoGenRoom {
    name?: string;
    status?: number;
    amountOfPeople?: number;
    floor?: number;
    rent?: number;
    parkingFee?: number;
    electricFee?: number;
    waterFee?: number;
    area?: number;
    internetFee?: number;
    environmentFee?: number;
    buildingId?: number;
    floors?: any;
    buildingName?: string;
    description?: string;
    amountRooms?: number;
  }
  
  export class AutoGenRoom implements IAutoGenRoom {
    constructor(
      public name?: string,
      public status?: number,
      public amountOfPeople?: number,
      public floor?: number,
      public area?: number,
      public rent?: number,
      public floors?: any,
      public parkingFee?: number,
      public electricFee?: number,
      public waterFee?: number,
      public internetFee?: number,
      public environmentFee?: number,
      public buildingId?: number,
      public buildingName?: string,
      public description?: string,
      public amountRooms?: number,
    ) {}
  }