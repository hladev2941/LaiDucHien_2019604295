import { Component, ElementRef, Input, OnInit, ViewChild } from '@angular/core';
import { AlertService } from 'src/app/_utils/notification.service';
import { RoomService } from '../../room/room.service';
import { NzModalRef } from 'ng-zorro-antd/modal';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AutoGenRoom } from './auto-gen-room.model';
import { IBuilding } from '../building.model';
import { BuildingService } from '../building.service';

@Component({
  selector: 'app-auto-gen-room',
  templateUrl: './auto-gen-room.component.html',
  styleUrls: ['./auto-gen-room.component.scss']
})
export class AutoGenRoomComponent implements OnInit {

  listOfControl: Array<any> = [];
  autoGenForm: FormGroup;
  isSearch: boolean = false;
  isLoading = false;
  @Input() data?: IBuilding;

  @ViewChild("amountOfPeople") amountOfPeople: ElementRef;
  amountOfPeopleErrMsg: any;
  focusOnErrAmountOfPeople() {
    this.amountOfPeople.nativeElement.focus();
  }

  @ViewChild("floor") floor: ElementRef;
  floorErrMsg: any;
  focusOnErrFloor() {
    this.floor.nativeElement.focus();
  }

  @ViewChild("electricFee") electricFee: ElementRef;
  electricFeeErrMsg: any;
  focusOnErrElectricFee() {
    this.electricFee.nativeElement.focus();
  }

  @ViewChild("waterFee") waterFee: ElementRef;
  waterFeeErrMsg: any;
  focusOnErrWaterFee() {
    this.waterFee.nativeElement.focus();
  }

  @ViewChild("internetFee") internetFee: ElementRef;
  internetFeeErrMsg: any;
  focusOnErrInternetFee() {
    this.internetFee.nativeElement.focus();
  }

  @ViewChild("environmentFee") environmentFee: ElementRef;
  environmentFeeErrMsg: any;
  focusOnErrEnvironmentFee() {
    this.environmentFee.nativeElement.focus();
  }

  @ViewChild("building") building: ElementRef;
  buildingErrMsg: any;
  focusOnErrBuilding() {
    this.building.nativeElement.focus();
  }

  @ViewChild("rent") rent: ElementRef;
  rentErrMsg: any;
  focusOnErrRent() {
    this.rent.nativeElement.focus();
  }

  @ViewChild("area") area: ElementRef;
  areaErrMsg: any;
  focusOnErArea() {
    this.area.nativeElement.focus();
  }

  @ViewChild("parkingFee") parkingFee: ElementRef;
  parkingFeeErrMsg: any;
  focusOnErrParkingFee() {
    this.parkingFee.nativeElement.focus();
  }


  constructor(private fb: FormBuilder,
    private modal: NzModalRef,
    private buildingService: BuildingService,
    private notification: AlertService) { }

  ngOnInit(): void {
    this.autoGenForm = this.fb.group({
        amountOfPeople:[null, []],
        electricFee:[null, []],
        waterFee:[null, []],
        internetFee:[null, []],
        rent:[null, []],
        area:[null, []],
        parkingFee:[null, []],
        environmentFee:[null, []],
        building:[null, []],
        description:[null, []],
        status: [false, []],
    });
    this.addField();
  }

  getFromSearch(data: any): AutoGenRoom {
      let { amountOfPeople, electricFee, waterFee, internetFee, environmentFee, rent, parkingFee, area, status, description } = this.autoGenForm.value;
      return {
          ...new AutoGenRoom(),
          amountOfPeople: amountOfPeople,
          electricFee: electricFee,
          waterFee: waterFee,
          internetFee: internetFee,
          rent: rent,
          area: area,
          parkingFee: parkingFee,
          environmentFee: environmentFee,
          buildingId: this.data.id,
          buildingName: this.data.name,
          description: description,
          amountRooms: this.data.amountRooms,
          floors: data,
          status: status ? 1 : 0
      };
  }

  handleOk(): void {
    if (this.validateCreate()) {
      let floors = [];
      this.listOfControl.forEach(e => {
        floors.push({
          floor: this.autoGenForm.value[e.floor], 
          amountOfRoom: this.autoGenForm.value[e.amountOfRoom]
        })
      });
      this.isLoading = true;
      this.buildingService.syncRoom(this.getFromSearch(floors)).subscribe(
        {
            next: (res) => {
              this.isLoading = false;
              this.notification.success("Thao tác thực hiện thành công!");
              this.modal.destroy();
            }, error: (err) => {
              this.notification.error("Có lỗi sảy ra trong quá trình thực hiện!");
            }
        })
    }
  }

  handleCancel(): void {
    this.modal.destroy();
  }

  validateCreate() {
    let isValid = true;
    if (!this.autoGenForm.value.amountOfPeople) {
      this.amountOfPeopleErrMsg = "Giá trị của nội thất bắt buộc nhập";
      isValid = false;
      this.focusOnErrAmountOfPeople();
    }
    if (!this.autoGenForm.value.rent) {
      this.rentErrMsg = "Bạn phải nhập giá thue";
      isValid = false;
      this.focusOnErrRent();
    }
    if (!this.autoGenForm.value.electricFee) {
      this.electricFeeErrMsg = "Bạn phải nhập thông tin phí sử dụng điện";
      isValid = false;
      this.focusOnErrElectricFee();
    }
    if (!this.autoGenForm.value.waterFee) {
      this.waterFeeErrMsg = "Bạn phải nhập thông tin phí sử dụng nước";
      isValid = false;
      this.focusOnErrWaterFee();
    }
    if (!this.autoGenForm.value.internetFee) {
      this.internetFeeErrMsg = "Bạn phải nhập thông tin phí sử dụng mạng";
      isValid = false;
      this.focusOnErrInternetFee();
    }
    if (!this.autoGenForm.value.environmentFee) {
      this.environmentFeeErrMsg = "Bạn phải nhập thông tin phí vệ sinh môi trường";
      isValid = false;
      this.focusOnErrEnvironmentFee();
    }
    if (!this.autoGenForm.value.parkingFee) {
      this.parkingFeeErrMsg = "Bạn phải nhập thông tin phí giữ xe";
      isValid = false;
      this.focusOnErrParkingFee();
    }
    if (!this.autoGenForm.value.area) {
      this.areaErrMsg = "Diện tích bắt buộc phải nhập";
      isValid = false;
      this.focusOnErArea();
    }

    return isValid;
  }

  clearAmountOfPeopleMessage(){
    this.amountOfPeopleErrMsg = "";
  }

  clearElectricFeeMessage(){
    this.electricFeeErrMsg = "";
  }
  
  clearWaterFeeMessage(){
    this.waterFeeErrMsg = "";
  }

  clearInternetFeeMessage(){
    this.internetFeeErrMsg = "";
  }

  clearEnvironmentFeeMessage(){
    this.environmentFeeErrMsg = "";
  }

  clearBuildingMessage(){
    this.buildingErrMsg = "";
  }

  clearParkingFeeMessage(){
    this.parkingFeeErrMsg = "";
  }

  clearRentMessage(){
    this.rentErrMsg = "";
  }

  clearAreaMessage() {
    this.areaErrMsg = "";
  }

  addField(e?: MouseEvent): void {
    if(!this.checkFormInitInValid()){
      return;
    }
    e?.preventDefault();
    const id = this.listOfControl.length > 0 ? this.listOfControl.length : 0;
    const control = {
      id,
      floor: `f-${id}`,
      amountOfRoom: `a-${id}`,
    };
    this.listOfControl.push(control);
    this.autoGenForm.addControl(control.floor, this.fb.control(null, [Validators.required]));
    this.autoGenForm.addControl(control.amountOfRoom, this.fb.control(null, [Validators.required]));
  }

  checkFormInitInValid(): boolean{
    let count = 0;
    this.listOfControl.forEach((e) => {
      if(this.autoGenForm.get(e.floor).invalid){
        count ++;
        this.autoGenForm.get(e.floor).markAsDirty();
        this.autoGenForm.get(e.floor).updateValueAndValidity();
      }
      if(this.autoGenForm.get(e.amountOfRoom).invalid){
        count ++;
        this.autoGenForm.get(e.amountOfRoom).markAsDirty();
        this.autoGenForm.get(e.amountOfRoom).updateValueAndValidity();
      }
    })

    return count == 0;
  }

  removeField(e?: MouseEvent, i?: number): void {
    if (this.listOfControl.length == 1) {
        this.notification.warning('Bạn cần cấu hình thông tin phòng!');
        return;
    };
    e?.preventDefault();
    if (i != undefined) {
      this.autoGenForm.removeControl(this.listOfControl[i].floor);
      this.autoGenForm.removeControl(this.listOfControl[i].amountOfRoom);
      this.listOfControl.splice(i, 1);
    } else {
      this.listOfControl.pop();
      this.autoGenForm.removeControl(this.listOfControl[this.listOfControl.length].floor);
      this.autoGenForm.removeControl(this.listOfControl[this.listOfControl.length].amountOfRoom);
    }
  }

}
