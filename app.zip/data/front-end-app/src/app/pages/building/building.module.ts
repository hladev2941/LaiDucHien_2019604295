import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { BuildingRoutingModule } from './building-routing.module';
import { BuildingListComponent } from './building-list/building-list.component';
import { AddEditBuildingComponent } from './add-edit-building/add-edit-building.component';
import { ModuleShare } from 'src/app/ng-zorro-antd.module';
import { AutoGenRoomComponent } from './auto-gen-room/auto-gen-room.component';
import { ViewBuildingComponent } from './view-building/view-building.component';
import { RoomEachFloorBuildingComponent } from './room-each-floor-building/room-each-floor-building.component';


@NgModule({
  declarations: [
    BuildingListComponent,
    AddEditBuildingComponent,
    AutoGenRoomComponent,
    ViewBuildingComponent,
    RoomEachFloorBuildingComponent
  ],
  imports: [
    CommonModule,
    BuildingRoutingModule,
    ModuleShare
  ]
})
export class BuildingModule { }
