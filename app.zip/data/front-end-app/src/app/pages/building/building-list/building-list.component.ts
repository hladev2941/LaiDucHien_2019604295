import { ChangeDetectorRef, Component, EventEmitter, HostListener, OnInit, ViewContainerRef } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { NzModalService } from 'ng-zorro-antd/modal';
import { AlertService } from 'src/app/_utils/notification.service';
import { AddEditBuildingComponent } from '../add-edit-building/add-edit-building.component';
import { Building, IBuilding } from '../building.model';
import { BuildingService } from '../building.service';
import { AutoGenRoomComponent } from '../auto-gen-room/auto-gen-room.component';
import { ViewBuildingComponent } from '../view-building/view-building.component';
import { RoomEachFloorBuildingComponent } from '../room-each-floor-building/room-each-floor-building.component';
import { ISelect2, Select2 } from 'src/app/_utils/select2.model';

@Component({
  selector: 'app-building-list',
  templateUrl: './building-list.component.html',
  styleUrls: ['./building-list.component.scss']
})
export class BuildingListComponent implements OnInit {

  building: IBuilding[];
  size = 10;
  page = 1;
  total: number = 0;
  searchForm: FormGroup;
  pageSizeOptions: number[] = [10, 20, 50, 100];

  constructor(
    private fb: FormBuilder,
    private nzModalService: NzModalService,
    private viewContainerRef: ViewContainerRef,
    private buildingService: BuildingService,
    private notification: AlertService,
    private ref: ChangeDetectorRef,
  ) { }

  ngOnInit(): void {
    this.searchForm = this.fb.group({
      name: [null, []],
      status: [null, []],
      tinh: [null, []],
      huyen: [null, []],
      addressDetail: [null, []],
      xa: [null, []],
    });

    this.search();
  }

  getFromSearch(): Building {
    let { name, addressDetail, status, tinh, huyen, xa } = this.searchForm.value;
    return {
      ...new Building(),
      name: name,
      addressDetail: addressDetail,
      status: status ? (status == '0' ? 0 : 1) : null,
      cityId: tinh?.id,
      districtId: huyen?.id,
      wardId: xa?.id,
      page: this.page,
      size: this.size,
    };
  }

  onSearch() {
    this.buildingService.search(this.getFromSearch()).subscribe({
      next: (res) => {
        this.total = res.total;
        this.building = res.data;
      },
      error: (err) => console.log(err),
    });
  }

  search() {
    this.page = 1;
    this.size = 10;
    this.onSearch();
  }

  resetForm() {

  }

  showModal() {
    const modal = this.nzModalService.create({
      nzTitle: 'Thêm mới thông tin tòa nhà',
      nzContent: AddEditBuildingComponent,
      nzViewContainerRef: this.viewContainerRef,
      nzWidth: '1000px',
      nzComponentParams: {
      },
      nzOnCancel: () => this.handleCancel(modal),
    });
    modal.afterClose.subscribe(() => {
      this.onSearch();
    });
  }

  handleCancel(modal): Promise<void> {
    return new Promise((resolve, reject) => {
      const confirmModal = this.nzModalService.confirm({
        nzTitle: 'Thông báo xác nhận huỷ',
        nzContent: 'Bạn có chắc chắn muốn huỷ?',
        nzOnOk: () => {
          modal.close();
          confirmModal.close();
          resolve();
        },
        nzOnCancel: () => {
          reject();
        },
      });
    });
  }

  isLoading = false;

  showModalEdit(data: any) {
    const modal = this.nzModalService.create({
      nzTitle: 'Chỉnh sửa thông tin tòa nhà',
      nzContent: AddEditBuildingComponent,
      nzViewContainerRef: this.viewContainerRef,
      nzWidth: '1000px',
      nzComponentParams: {
        data: data
      },
      nzOnCancel: () => this.handleCancel(modal),
    });
    modal.afterClose.subscribe(() => {
      this.onSearch();
    });
  }

  showModalSyncRoom(data: any) {
    const modal = this.nzModalService.create({
      nzTitle: 'Đồng bộ phòng',
      nzContent: AutoGenRoomComponent,
      nzViewContainerRef: this.viewContainerRef,
      nzWidth: '1000px',
      nzComponentParams: {
        data: data
      },
      nzOnCancel: () => this.handleCancel(modal),
    });
    modal.afterClose.subscribe(() => {
      this.onSearch();
    });
  }

  showModalView(data: any) {
    const modal = this.nzModalService.create({
      nzTitle: 'Xem chi tiết thông tin tòa nhà',
      nzContent: ViewBuildingComponent,
      nzViewContainerRef: this.viewContainerRef,
      nzWidth: '800px',
      nzComponentParams: {
        data: data,
      },
      nzFooter: null,
    });
  }

  showModalViewStatusRoom(data: any) {
    const modal = this.nzModalService.create({
      nzTitle: 'Xem trạng thái phòng từng tầng của tòa nhà',
      nzContent: RoomEachFloorBuildingComponent,
      nzViewContainerRef: this.viewContainerRef,
      nzWidth: '800px',
      nzComponentParams: {
        data: data,
      },
      nzFooter: null,
    });
  }

  onChangePage($event: number) {
    this.page = $event;
    this.onSearch();
  }

  onChangeSizePage($event: number) {
    this.page = 1;
    this.size = $event;
    this.onSearch();
  }


  delete(data: any) {
    this.nzModalService.confirm({
      nzTitle: 'Thông báo xác nhận xóa',
      nzContent: 'Bạn có chắc chắn muốn xóa tòa nhà này không?',
      nzOkText: 'Xác nhận',
      nzCancelText: 'Huỷ',
      nzOkDanger: true,
      nzIconType: 'delete',
      nzOnOk: () => {
        this.buildingService.delete(data).subscribe((res) => {
          if (res.err_code == 0) {
            this.notification.success(
              'Thao tác thực hiện thành công!'
            );
          } else {
            this.notification.error(
              'Thao tác thực hiện không thành công!'
            );
          }
          this.search();
        });
      },
    });
  }

  @HostListener('document:keypress', ['$event'])
  keyEvent(event: KeyboardEvent) {
    if (event.keyCode === 13) {
      this.search();
    }
  }

   //SELECT2 tinh
   totalTinh: number = 1;
   pageTinh = 1;
   tinhs: ISelect2[] = [];
   loadMoreTinh(key?: any): void {
       if (this.tinhs.length <= this.totalTinh) {
           this.isLoading = true;
           this.buildingService
               .getDiaChiById({
                   ...new Select2(),
                   key: key ?? '',
                   page: this.pageTinh,
                   size: 10,
               })
               .subscribe((res) => {
                   if (res != null && res.data) {
                       this.tinhs = this.tinhs.concat(res.data);
                       this.pageTinh += 1;
                       this.totalTinh = res.total;
                       this.isLoading = false;
                   }
               });
       }
   }

   onSearchTinh(key?: any): void {
       this.isSearch = true;
       this.pageTinh = 1;
       this.tinhs = [];
       this.loadMoreTinh(key);
   }

   loadHuyen() {
       this.searchForm.get('huyen').setValue(null);
       this.searchForm.get('xa').setValue(null);
       this.onSearchHuyen();
   }

   //Select2 Huyen
   totalHuyen: number = 1;
   pageHuyen = 1;
   huyens: ISelect2[] = [];
   loadMoreHuyen(key?: any): void {
       if (!this.isLoading && this.huyens.length <= this.totalHuyen) {
           this.isLoading = true;
           this.buildingService
               .getDiaChiById({
                   ...new Select2(),
                   key: key ?? '',
                   cha_id: this.searchForm.value.tinh?.id,
                   page: this.pageHuyen,
                   size: 10,
               })
               .subscribe((res) => {
                   if (res != null && res.data) {
                       this.huyens = this.huyens.concat(res.data);
                       this.pageHuyen += 1;
                       this.totalHuyen = res.total;
                       this.isLoading = false;
                   }
               });
       }
   }

   onSearchHuyen(key?: any): void {
       this.isSearch = true;
       this.pageHuyen = 1;
       this.huyens = [];
       this.loadMoreHuyen(key);
   }

   loadXa() {
       this.searchForm.get('xa').setValue(null);
       this.onSearchXa();
   }
   //Select2 Xa
   totalXa: number = 1;
   pageXa = 1;
   xas: ISelect2[] = [];
   loadMoreXa(key?: any): void {
       if (!this.isLoading && this.xas.length <= this.totalXa) {
           this.isLoading = true;
           this.buildingService
               .getDiaChiById({
                   ...new Select2(),
                   key: key ?? '',
                   cha_id: this.searchForm.value.huyen?.id,
                   page: this.pageXa,
                   size: 10,
               })
               .subscribe((res) => {
                   if (res != null && res.data) {
                       this.xas = this.xas.concat(res.data);
                       this.pageXa += 1;
                       this.totalXa = res.total;
                       this.isLoading = false;
                   }
               });
       }
   }
   isSearch: any
   onSearchXa(key?: any): void {
       this.isSearch = true;
       this.pageXa = 1;
       this.xas = [];
       this.loadMoreXa(key);
   }
}
