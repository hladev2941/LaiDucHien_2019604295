import { Component, ElementRef, EventEmitter, Input, OnInit, Output, ViewChild, ViewContainerRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NzModalRef, NzModalService } from 'ng-zorro-antd/modal';
import { BuildingService } from '../building.service';
import { AlertService } from 'src/app/_utils/notification.service';
import { Building, IBuilding } from '../building.model';
import { ISelect2, Select2 } from 'src/app/_utils/select2.model';

@Component({
  selector: 'app-add-edit-building',
  templateUrl: './add-edit-building.component.html',
  styleUrls: ['./add-edit-building.component.scss']
})
export class AddEditBuildingComponent implements OnInit {

  addEditForm: FormGroup;
  isSearch: boolean = false;
  isLoading = false;

  @Input() data?: IBuilding;

  @ViewChild("name") name: ElementRef;
  nameErrMsg: any;
  focusOnErrName() {
    this.name.nativeElement.focus();
  }

  @ViewChild("amountRooms") amountRooms: ElementRef;
  amountRoomsErrMsg: any;
  focusOnErrAmountRooms() {
    this.amountRooms.nativeElement.focus();
  }

  @ViewChild("floors") floors: ElementRef;
  floorsErrMsg: any;
  focusOnErrFloors() {
    this.floors.nativeElement.focus();
  }

  @ViewChild("addressDetail") addressDetail: ElementRef;
  addressDetailErrMsg: any;
  focusOnErrAddressDetail() {
    this.addressDetail.nativeElement.focus();
  }

  @ViewChild("tinh") tinh: ElementRef;
  tinhErrMsg: any;
  focusOnErrTinh() {
    this.tinh.nativeElement.focus();
  }

  @ViewChild("huyen") huyen: ElementRef;
  huyenErrMsg: any;
  focusOnErrHuyen() {
    this.huyen.nativeElement.focus();
  }

  @ViewChild("xa") xa: ElementRef;
  xaErrMsg: any;
  focusOnErrXa() {
    this.xa.nativeElement.focus();
  }

  descriptionErrMsg: any;


  constructor(private fb: FormBuilder,
    private modal: NzModalRef,
    private buildingService: BuildingService,
    private notification: AlertService) { }

  ngOnInit(): void {
    this.addEditForm = this.fb.group({
        id:[null, []],
        name: [null, [Validators.required]],
        amountRooms:[null, [Validators.required]],
        floors:[null, [Validators.required]],
        addressDetail:[null, [Validators.required]],
        tinh:[null, []],
        huyen:[null, []],
        xa:[null, []],
        description:[null, []],
        status: [false, []],
    });
    if (this.data) {
      this.onPatch(this.data);
      this.selectedValueTinh = {
          ...new Select2(),
          id: this.data?.cityId,
          name: this.data?.cityName,
      };
      this.selectedValueHuyen = {
          ...new Select2(),
          id: this.data?.districtId,
          name: this.data?.districtName,
      };
      this.selectedValueXa = {
          ...new Select2(),
          id: this.data?.wardId,
          name: this.data?.wardName,
      };
    }
  }

  onPatch(patchData: IBuilding): void {
    this.addEditForm.patchValue({
        id: patchData.id,
        name: patchData.name,
        amountRooms: patchData.amountRooms,
        floors: patchData.floors,
        addressDetail: patchData.addressDetail,
        tinh: patchData.cityId,
        huyen: patchData.districtId,
        xa: patchData.wardId,
        description: patchData.description,
        status: patchData.status == 1 ? true : false,
    });
  }

  getFromSearch(): Building {
      let { name, amountRooms, floors, addressDetail, tinh, huyen, xa, description, status } = this.addEditForm.value;
      return {
          ...new Building(),
          id: this.data?.id,
          name: name,
          amountRooms: amountRooms,
          floors: floors,
          addressDetail: addressDetail,
          cityId: tinh?.id,
          districtId: huyen?.id,
          wardId: xa?.id,
          cityName: tinh?.name,
          districtName: huyen?.name,
          wardName: xa?.name,
          description: description,
          status: status ? 1 : 0
      };
  }

  handleOk(): void {
    if (this.validateCreate()) {
      this.isLoading = true;
      this.buildingService.save(this.getFromSearch()).subscribe(
        {
            next: (res) => {
              this.isLoading = false;
              this.notification.success("Thao tác thực hiện thành công!");
              this.modal.destroy();
            }, error: (err) => {
              this.notification.error(err.error.message);
            }
        })
    }
  }

  handleCancel(): void {
    this.modal.destroy();
  }

  validateCreate() {
    let isValid = true;
    if (!this.addEditForm.value.name || !this.addEditForm.value.name.trim()) {
      this.nameErrMsg = "Tên tòa nhà bắt buộc nhập";
      isValid = false;
      this.focusOnErrName();
    }
    if (!this.addEditForm.value.addressDetail || !this.addEditForm.value.addressDetail.trim()) {
      this.addressDetailErrMsg = "Địa chỉ cụ thể của tòa nhà bắt buộc nhập";
      isValid = false;
      this.focusOnErrAddressDetail();
    }
    if (!this.addEditForm.value.amountRooms) {
      this.amountRoomsErrMsg = "Số phòng của tòa nhà bắt buộc nhập";
      isValid = false;
      this.focusOnErrAmountRooms();
    }
    if (!this.addEditForm.value.floors) {
      this.floorsErrMsg = "Số tầng của tòa nhà bắt buộc nhập";
      isValid = false;
      this.focusOnErrFloors();
    }

    return isValid;
  }

  clearNameMessage(){
    this.nameErrMsg = "";
  }

  clearRoomslMessage(){
    this.amountRoomsErrMsg = "";
  }

  clearFloorlMessage(){
    this.floorsErrMsg = "";
  }

  clearAddressMessage(){
    this.addressDetailErrMsg = "";
  }

  
  compareFn = (o1: any, o2: any) => (o1 && o2 ? o1.id === o2.id : o1 === o2);
    //SELECT2 tinh
    totalTinh: number = 1;
    pageTinh = 1;
    tinhs: ISelect2[] = [];
    selectedValueTinh: ISelect2;

    loadMoreTinh(key?: any): void {
        if (this.tinhs.length <= this.totalTinh) {
            this.isLoading = true;
            this.buildingService
                .getDiaChiById({
                    ...new Select2(),
                    key: key ?? '',
                    page: this.pageTinh,
                    size: 10,
                })
                .subscribe((res) => {
                    if (res != null && res.data) {
                        this.tinhs = this.tinhs.concat(res.data);
                        this.pageTinh += 1;
                        this.totalTinh = res.total;
                        this.isLoading = false;
                    }
                });
        }
    }

    onSearchTinh(key?: any): void {
        this.isSearch = true;
        this.pageTinh = 1;
        this.tinhs = [];
        this.loadMoreTinh(key);
    }

    loadHuyen() {
        this.addEditForm.get('huyen').setValue(null);
        this.addEditForm.get('xa').setValue(null);
        this.onSearchHuyen();
    }

    //Select2 Huyen
    totalHuyen: number = 1;
    pageHuyen = 1;
    huyens: ISelect2[] = [];
    selectedValueHuyen: ISelect2;

    loadMoreHuyen(key?: any): void {
        if (!this.isLoading && this.huyens.length <= this.totalHuyen) {
            this.isLoading = true;
            if (!this.selectedValueTinh) {
                this.isLoading = false;
                return;
            }
            this.buildingService
                .getDiaChiById({
                    ...new Select2(),
                    key: key ?? '',
                    cha_id: this.addEditForm.value.tinh.id,
                    page: this.pageHuyen,
                    size: 10,
                })
                .subscribe((res) => {
                    if (res != null && res.data) {
                        this.huyens = this.huyens.concat(res.data);
                        this.pageHuyen += 1;
                        this.totalHuyen = res.total;
                        this.isLoading = false;
                    }
                });
        }
    }

    onSearchHuyen(key?: any): void {
        this.isSearch = true;
        this.pageHuyen = 1;
        this.huyens = [];
        this.loadMoreHuyen(key);
    }

    loadXa() {
        this.addEditForm.get('xa').setValue(null);
        this.onSearchXa();
    }
    //Select2 Xa
    totalXa: number = 1;
    pageXa = 1;
    xas: ISelect2[] = [];
    selectedValueXa: ISelect2;

    loadMoreXa(key?: any): void {
        if (!this.isLoading && this.xas.length <= this.totalXa) {
            this.isLoading = true;
            if (!this.selectedValueHuyen) {
              this.isLoading = false;
              return;
            }
            this.buildingService
                .getDiaChiById({
                    ...new Select2(),
                    key: key ?? '',
                    cha_id: this.addEditForm.value.huyen.id,
                    page: this.pageXa,
                    size: 10,
                })
                .subscribe((res) => {
                    if (res != null && res.data) {
                        this.xas = this.xas.concat(res.data);
                        this.pageXa += 1;
                        this.totalXa = res.total;
                        this.isLoading = false;
                    }
                });
        }
    }

    onSearchXa(key?: any): void {
        this.isSearch = true;
        this.pageXa = 1;
        this.xas = [];
        this.loadMoreXa(key);
    }
}
