import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ResponseAPI } from 'src/app/_utils/response.model';
import { Constants } from '../../_utils/constants';
import { IBuilding } from './building.model';

@Injectable({
  providedIn: 'root',
})
export class BuildingService {
  private baseUrl = Constants.HOST + "/v1/building";
  constructor(private http: HttpClient) {}

  search(building: IBuilding) {
    return this.http.post<ResponseAPI<IBuilding[]>>(`${this.baseUrl}/search`, building);
  }

  save(building: IBuilding){
    return this.http.post<ResponseAPI<any>>(`${this.baseUrl}/save`, building)
  }

  delete(building: IBuilding){
    return this.http.post<ResponseAPI<any>>(`${this.baseUrl}/delete`, building)
  }
  
  getDiaChiById(data: any) {
    return this.http.post<ResponseAPI<IBuilding[]>>(`${this.baseUrl}/dia-chi`, data);
  }

  syncRoom(data: any) {
    return this.http.post<ResponseAPI<IBuilding[]>>(`${this.baseUrl}/syn`, data);
  }

  getDetailFloor(buildingId: number, floor: number) {
    return this.http.get<ResponseAPI<any>>(`${this.baseUrl}/get-detail-floor/${buildingId}/${floor}`);
  }
}
