import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { IBuilding, StatusRoomEachFloor } from '../building.model';
import { BuildingService } from '../building.service';

@Component({
  selector: 'app-room-each-floor-building',
  templateUrl: './room-each-floor-building.component.html',
  styleUrls: ['./room-each-floor-building.component.scss'],
})
export class RoomEachFloorBuildingComponent implements OnInit {
  @Input() data?: IBuilding;
  searchForm: FormGroup;
  listOfRoomEachFloor: StatusRoomEachFloor[] = [];
  isLoading: boolean = false;

  constructor(private readonly fb: FormBuilder, private readonly buildingService: BuildingService) {}
  floors: number[] = [];

  ngOnInit(): void {
    this.searchForm = this.fb.group({
      floor: [1, []],
    });

    if (this.data && typeof this.data.floors === 'number') {
        this.floors = Array.from({ length: this.data.floors }, (_, i) => i + 1);
        this.getStatusRoomEachFloor(1);
      }
  }

  onChangeFloor(floor: number): void {
    this.getStatusRoomEachFloor(floor);
  }

  getStatusRoomEachFloor(floor: number): Promise<void> {
    this.isLoading = true;
    return new Promise((resolve, reject) => {
        this.buildingService.getDetailFloor(this.data.id, floor).subscribe({
            next: (res) => {
                this.listOfRoomEachFloor = res.data;
                setTimeout(() => {
                    this.isLoading = false;
                }, 300);
                resolve();
            },
            error: (err) => {
                this.isLoading = false;
                reject(err);
            },
        });
    })
  }
}
