interface IBuilding {
    id?: number;
    name?: string;
    cityId?: number;
    districtId?: number;
    wardId?: number;
    cityName?: string;
    districtName?: string;
    wardName?: string;
    addressDetail?: string;
    status?: number;
    amountRooms?: number;
    floors?: number;
    description?:string;
    owner?:any;
    page?: number;
    size?: number;
    lastModifiedBy? : string;
    lastModifiedDate? : string;
    createdBy? : string;
    createdDate? : string;
  }

  interface StatusRoomEachFloor {
    name: string,
    status: 1 | 0 | 2;
  }
  
  class Building implements IBuilding {
    constructor(
      public id?: number,
      public name?: string,
      public cityId?: number,
      public districtId?: number,
      public wardId?: number,
      public cityName?: string,
      public districtName?: string,
      public wardName?: string,
      public addressDetail?: string,
      public status?: number,
      public amountRooms?: number,
      public floors?: number,
      public description?: string,
      public owner?:any,
      public page?: number,
      public size?: number
    ) {}
  }

  export { StatusRoomEachFloor, Building, IBuilding }