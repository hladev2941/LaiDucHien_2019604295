import { Component, Input, OnInit } from '@angular/core';
import { IBuilding } from '../building.model';

@Component({
  selector: 'app-view-building',
  templateUrl: './view-building.component.html',
  styleUrls: ['./view-building.component.scss']
})
export class ViewBuildingComponent implements OnInit {
  @Input() data?: IBuilding;

  constructor() { }

  ngOnInit(): void {
  }
}
