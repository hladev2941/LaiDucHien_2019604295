import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PagesRoutingModule } from './pages-routing.module';
import { PagesComponent } from './pages.component';
import { ModuleShare } from '../ng-zorro-antd.module';
import { SidebarComponent } from './navigation/sidebar/app.component';
import { HeaderComponent } from './navigation/header/app.component';
import { NZ_I18N, vi_VN } from 'ng-zorro-antd/i18n';


@NgModule({
  declarations: [
    HeaderComponent, 
    SidebarComponent,
    PagesComponent, 
  ],
  imports: [
    CommonModule,
    PagesRoutingModule,
    ModuleShare
  ],
  providers: [{ provide: NZ_I18N, useValue: vi_VN }],
  bootstrap: [PagesComponent],
})
export class PagesModule { }
