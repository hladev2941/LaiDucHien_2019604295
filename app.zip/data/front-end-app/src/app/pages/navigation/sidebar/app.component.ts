import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sidebar',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class SidebarComponent implements OnInit {
  title = 'dashboard_theme';

  constructor() {
  }

  ngOnInit(): void {
  }
}
