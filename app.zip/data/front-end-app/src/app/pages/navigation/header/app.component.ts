import { Component, OnInit } from '@angular/core';
import { Route, Router } from '@angular/router';
import { AuthService } from 'src/app/authentication/auth.service';

@Component({
    selector: 'app-header',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.scss'],
})
export class HeaderComponent implements OnInit {

    constructor(private authService: AuthService,private router : Router) {}

    ngOnInit(): void {
    }

    logout(){
        this.authService.logout();
        this.router.navigateByUrl("/login");
    }

    isVisibleMenu = false;
    sidebar = document.getElementsByClassName('sidebar');
    overlay = document.getElementsByClassName('overlay-common');

    toggleMenu() {
        this.isVisibleMenu = !this.isVisibleMenu;
        if (this.isVisibleMenu) {
          this.sidebar[0].classList.add('collapsed');
          this.overlay[0].classList.add('show');
        } else {
          this.sidebar[0].classList.remove('collapsed');
          this.overlay[0].classList.remove('show');
        }
        setTimeout(() => {
          window.dispatchEvent(new Event('resize'));
        }, 300);
      }
}
