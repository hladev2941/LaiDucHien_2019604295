import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PagesComponent } from './pages.component';
import { AuthGuardService } from '../authentication/auth-guard.service';

const routes: Routes = [
  {
    path: '',
    component: PagesComponent,
    children: [{
      path: 'home',
      loadChildren: () =>
        import('./home/home.module').then(
          (m) => m.HomeModule
        ),
      data: {
        breadcrumb: 'Trang chủ',
      },
    },
    {
      path: 'furniture',
      loadChildren: () =>
        import('./furniture/furniture.module').then(
          (m) => m.FurnitureModule
        ),
      data: {
        breadcrumb: 'Trang chủ',
      },
    },
    {
      path: 'building',
      loadChildren: () =>
        import('./building/building.module').then(
          (m) => m.BuildingModule
        ),
      data: {
        breadcrumb: 'Tòa nhà',
      },
    },
    {
      path: 'room',
      loadChildren: () =>
        import('./room/room.module').then(
          (m) => m.RoomModule
        ),
      data: {
        breadcrumb: 'Phòng',
      },
    },
    {
      path: 'services',
      loadChildren: () =>
        import('./services-in-building/services-in-building.module').then(
          (m) => m.ServicesInBuildingModule
        ),
      data: {
        breadcrumb: 'Dịch vụ',
      },
    },
    {
      path: 'customer',
      loadChildren: () =>
        import('./customer/customer.module').then(
          (m) => m.CustomerModule
        ),
      data: {
        breadcrumb: 'Khách hàng',
      },
    },
    {
      path: 'contract',
      loadChildren: () =>
        import('./contract-rent/contract-rent.module').then(
          (m) => m.ContractRentModule
        ),
      data: {
        breadcrumb: 'Hợp đồng',
      },
    },
    {
      path: 'notice-warning',
      loadChildren: () =>
        import('./notice-warning/notice-warning.module').then(
          (m) => m.NoticeWarningModule
        ),
      data: {
        breadcrumb: 'Cảnh báo',
      },
    },
    {
      path: 'bill',
      loadChildren: () =>
        import('./bill/bill.module').then(
          (m) => m.BillModule
        ),
      data: {
        breadcrumb: 'Hóa đơn hàng tháng',
      },
    },
    {
      path: 'booking',
      loadChildren: () =>
        import('./booking/booking.module').then(
          (m) => m.BookingModule
        ),
      data: {
        breadcrumb: 'Quản lý phòng đã được cọc',
      },
    },
    {
      path: 'report',
      loadChildren: () =>
        import('./report/report.module').then(
          (m) => m.ReportModule
        ),
      data: {
        breadcrumb: 'Báo cáo thống kê',
      },
    },
    ]
  }
];

routes[0].children.forEach((route) => {
  route.canActivate = [AuthGuardService];
});
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PagesRoutingModule { }
