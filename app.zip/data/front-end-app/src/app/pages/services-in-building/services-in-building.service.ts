import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ResponseAPI } from 'src/app/_utils/response.model';
import { Constants } from '../../_utils/constants';
import { IServiceInBuilding } from './services-in-building.model';

@Injectable({
  providedIn: 'root',
})
export class ServiceInBuildingService {
  private baseUrl = Constants.HOST + "/v1/services-in-building";
  constructor(private http: HttpClient) {}

  search(ServiceInBuilding: IServiceInBuilding) {
    return this.http.post<ResponseAPI<IServiceInBuilding[]>>(`${this.baseUrl}/search`, ServiceInBuilding);
  }

  save(ServiceInBuilding: IServiceInBuilding){
    return this.http.post<ResponseAPI<any>>(`${this.baseUrl}/save`, ServiceInBuilding)
  }

  delete(ServiceInBuilding: IServiceInBuilding){
    return this.http.post<ResponseAPI<any>>(`${this.baseUrl}/delete`, ServiceInBuilding)
  }
  
  getPackages(data: any) {
    return this.http.get<ResponseAPI<any>>(`${this.baseUrl}/list-packages/`+ data.id);
  }

  editPackages(data: any, serviceId: any) {
    return this.http.post<ResponseAPI<any>>(`${this.baseUrl}/edit-packages`, {data: data, serviceId: serviceId});
  }
}
