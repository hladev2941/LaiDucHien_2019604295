import { Component, ElementRef, Input, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { IServiceInBuilding, ServiceInBuilding } from '../services-in-building.model';
import { NzModalRef } from 'ng-zorro-antd/modal';
import { ServiceInBuildingService } from '../services-in-building.service';
import { AlertService } from 'src/app/_utils/notification.service';
import { ISelect2, Select2 } from 'src/app/_utils/select2.model';
import { RoomService } from '../../room/room.service';

@Component({
  selector: 'app-add-edit-service',
  templateUrl: './add-edit-service.component.html',
  styleUrls: ['./add-edit-service.component.scss']
})
export class AddEditServiceComponent implements OnInit {

  addEditForm: FormGroup;
  isSearch: boolean = false;
  isLoading = false;
  selectedImages: any[] = [];
  @Input() data?: IServiceInBuilding;

  @ViewChild("name") name: ElementRef;
  nameErrMsg: any;
  focusOnErrName() {
    this.name.nativeElement.focus();
  }

  @ViewChild("address") address: ElementRef;
  addressErrMsg: any;
  focusOnErrAddress() {
    this.address.nativeElement.focus();
  }

  @ViewChild("phone") phone: ElementRef;
  phoneErrMsg: any;
  focusOnErrPhone() {
    this.phone.nativeElement.focus();
  }

  constructor(private fb: FormBuilder,
    private modal: NzModalRef,
    private serviceInBuildingService: ServiceInBuildingService,
    private notification: AlertService,
    private readonly roomService: RoomService
  ) { }

  ngOnInit(): void {
    this.addEditForm = this.fb.group({
        id:[null, []],
        name: [null, []],
        phone: [null, []],
        email: [null, []],
        address: [null, []],
        building: [null, []],
        description: [null, []],
        status: [true, []],
    });
    if (this.data) {
      this.onPatch(this.data);
      this.selectedValueBuilding = {
        ...new Select2(),
        id: this.data?.buildingId,
        name: this.data?.buildingName,
      };
    }
  }

  onPatch(patchData: IServiceInBuilding): void {
    this.addEditForm.patchValue({
        id: patchData.id,
        name: patchData.name,
        phone: patchData.phone,
        email: patchData.email,
        address: patchData.address,
        description: patchData.description,
        status: patchData.status == 1 ? true : false,
    });
  }

  getFromSearch(): ServiceInBuilding {
      let { name, phone, email, address, description, building, status } = this.addEditForm.value;
      return {
          ...new ServiceInBuilding(),
          id: this.data?.id,
          name: name,
          phone: phone,
          email: email,
          address: address,
          buildingId: building.id ? 1 : 2,
          buildingName: building.name,
          description: description,
          status: status ? 1 : 0
      };
  }

  handleOk(): void {
    if (this.validateCreate()) {
      this.isLoading = true;
      this.serviceInBuildingService.save(this.getFromSearch()).subscribe(
        {
            next: (res) => {
              this.isLoading = false;
              this.notification.success("Thao tác thực hiện thành công!");
              this.modal.destroy();
            }, error: (err) => {
              this.notification.error("Có lỗi sảy ra trong quá trình thực hiện!");
            }
        })
    }
  }

  handleCancel(): void {
    this.modal.destroy();
  }

  validateCreate() {
    let isValid = true;
    if (!this.addEditForm.value.name || !this.addEditForm.value.name.trim()) {
      this.nameErrMsg = "Tên dịch bắt buộc nhập";
      isValid = false;
      this.focusOnErrName();
    }
    if (!this.addEditForm.value.address || !this.addEditForm.value.name.trim()) {
      this.addressErrMsg = "Địa chỉ bắt buộc nhập";
      isValid = false;
      this.focusOnErrAddress();
    }
    if (!this.addEditForm.value.phone || !this.addEditForm.value.phone.trim()) {
      this.phoneErrMsg = "Số điện thoại bắt buộc nhập";
      isValid = false;
      this.focusOnErrPhone();
    }

    return isValid;
  }

  clearNameMessage(){
    this.nameErrMsg = "";
  }

  clearAddressMessage(){
    this.addressErrMsg = "";
  }

  clearPhoneMessage(){
    this.phoneErrMsg = "";
  }

  compareFn = (o1: any, o2: any) => (o1 && o2 ? o1.id === o2.id : o1 === o2);
  //SELECT2 Building
  totalBuilding: number = 1;
  pageBuilding = 1;
  buildings: ISelect2[] = [];
  selectedValueBuilding: ISelect2;

  loadMoreBuilding(key?: any): void {
    if (this.buildings.length <= this.totalBuilding) {
      this.isLoading = true;
      this.roomService
        .loadBuilding({
          ...new Select2(),
          key: key ?? '',
          page: this.pageBuilding,
          size: 10,
        })
        .subscribe((res) => {
          if (res != null && res.data) {
            this.buildings = this.buildings.concat(res.data);
            this.pageBuilding += 1;
            this.totalBuilding = res.total;
            this.isLoading = false;
          }
        });
    }
  }

  onSearchBuilding(key?: any): void {
    this.isSearch = true;
    this.pageBuilding = 1;
    this.buildings = [];
    this.loadMoreBuilding(key);
  }
}
