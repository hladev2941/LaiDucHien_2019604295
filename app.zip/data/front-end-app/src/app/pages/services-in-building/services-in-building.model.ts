export interface IServiceInBuilding {
    id?: number;
    name?: string;
    status?: number;
    description?: string;
    phone?: string;
    email?: string;
    address?: string;
    buildingName?: string;
    buildingId?: number;
    lastModifiedBy?: string;
    lastModifiedDate?: string;
    createdBy?: string;
    createdDate?: string;
    page?: number;
    size?: number;
  }
  
  export class ServiceInBuilding implements IServiceInBuilding {
    constructor(
      public id?: number,
      public name?: string,
      public status?: number,
      public description?: string,
      public phone?: string,
      public email?: string,
      public address?: string,
      public buildingName?: string,
      public buildingId?: number,
      public lastModifiedBy?: string,
      public lastModifiedDate?: string,
      public createdBy?: string,
      public createdDate?: string,
      public page?: number,
      public size?: number
    ) {}
  }