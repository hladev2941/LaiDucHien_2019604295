import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ServicesInBuildingRoutingModule } from './services-in-building-routing.module';
import { ListServicesComponent } from './list-services/list-services.component';
import { AddEditServiceComponent } from './add-edit-service/add-edit-service.component';
import { ModuleShare } from 'src/app/ng-zorro-antd.module';
import { ListPackageComponent } from './service-package/list-package/list-package.component';
import { ViewServicesComponent } from './view-services/view-services.component';


@NgModule({
  declarations: [
    ListServicesComponent,
    AddEditServiceComponent,
    ListPackageComponent,
    ViewServicesComponent
  ],
  imports: [
    CommonModule,
    ServicesInBuildingRoutingModule,
    ModuleShare
  ]
})
export class ServicesInBuildingModule { }
