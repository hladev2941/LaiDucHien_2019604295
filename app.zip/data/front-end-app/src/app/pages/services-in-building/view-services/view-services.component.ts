import { Component, Input, OnInit } from '@angular/core';
import { IServiceInBuilding } from '../services-in-building.model';

@Component({
  selector: 'app-view-services',
  templateUrl: './view-services.component.html',
  styleUrls: ['./view-services.component.scss']
})
export class ViewServicesComponent implements OnInit {
  @Input() data?: IServiceInBuilding;

  constructor() { }

  ngOnInit(): void {
  }
}
