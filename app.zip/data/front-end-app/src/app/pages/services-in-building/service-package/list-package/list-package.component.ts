import { Component, ElementRef, Input, OnInit, ViewChild } from '@angular/core';
import { ServiceInBuilding } from '../../services-in-building.model';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ServiceInBuildingService } from '../../services-in-building.service';
import { AlertService } from 'src/app/_utils/notification.service';
import { NzModalRef } from 'ng-zorro-antd/modal';

@Component({
  selector: 'app-list-package',
  templateUrl: './list-package.component.html',
  styleUrls: ['./list-package.component.scss']
})
export class ListPackageComponent implements OnInit {

  @Input() data?: ServiceInBuilding;
  addEditForm: FormGroup;
  listOfControl: Array<any> = [];

  constructor(
    private fb: FormBuilder,
    private modal: NzModalRef,
    private service: ServiceInBuildingService,
    private notification: AlertService
  ) { }

  ngOnInit(): void {
    this.addEditForm = this.fb.group({});
    this.addField();
  }

  isLoading = false
  compareFn = (o1: any, o2: any) => (o1 && o2 ? o1.id === o2.id : o1 === o2);

  addField(e?: MouseEvent): void {
    e?.preventDefault();
    const id = this.listOfControl.length > 0 ? this.listOfControl.length : 0;
    const control = {
      id,
      controlName: `name-${id}`,
      controlPrice: `price-${id}`,
      controlLimitPeople: `limitPeople-${id}`,
      controlLimitProduct: `limitProduct-${id}`,
      controlNote: `note-${id}`,
      controlDescription: `description-${id}`
    };
    this.listOfControl.push(control);
    this.addEditForm.addControl(control.controlName, this.fb.control(null, [Validators.required]));
    this.addEditForm.addControl(control.controlPrice, this.fb.control(null, [Validators.required]));
    this.addEditForm.addControl(control.controlLimitPeople, this.fb.control(null));
    this.addEditForm.addControl(control.controlLimitProduct, this.fb.control(null));
    this.addEditForm.addControl(control.controlNote, this.fb.control(null));
    this.addEditForm.addControl(control.controlDescription, this.fb.control(null));
  }

  initPackage() {
    setTimeout(() => {
      this.service.getPackages(this.data).subscribe((res) => {
        if (res.data.length == 0) this.addField();
        res.data.forEach(e => {
          const id = this.listOfControl.length > 0 ? this.listOfControl.length : 0;
          const control = {
            id,
            controlName: `name-${id}`,
            controlPrice: `price-${id}`,
            controlLimitPeople: `limitPeople-${id}`,
            controlLimitProduct: `limitProduct-${id}`,
            controlNote: `note-${id}`,
            controlDescription: `description-${id}`
          };
          this.listOfControl.push(control);
          this.addEditForm.addControl(control.controlName, this.fb.control(e.name, [Validators.required]));
          this.addEditForm.addControl(control.controlPrice, this.fb.control(e.price, [Validators.required]));
          this.addEditForm.addControl(control.controlLimitPeople, this.fb.control(e.limitPeople));
          this.addEditForm.addControl(control.controlLimitProduct, this.fb.control(e.limitProduct));
          this.addEditForm.addControl(control.controlNote, this.fb.control(e.note));
          this.addEditForm.addControl(control.controlDescription, this.fb.control(e.description));
        });
      });
    }, 0);

  }

  removeField(e?: MouseEvent, i?: number): void {
    e?.preventDefault();
    if (i != undefined) {
      this.addEditForm.removeControl("id-" + i);
      this.addEditForm.removeControl(this.listOfControl[i].controlName);
      this.addEditForm.removeControl(this.listOfControl[i].controlPrice);
      this.addEditForm.removeControl(this.listOfControl[i].controlLimitPeople);
      this.addEditForm.removeControl(this.listOfControl[i].controlLimitProduct);
      this.addEditForm.removeControl(this.listOfControl[i].controlNote);
      this.addEditForm.removeControl(this.listOfControl[i].controlDescription);
      this.listOfControl.splice(i, 1);
    } else {
      this.listOfControl.pop();
      this.addEditForm.removeControl("id-" + this.listOfControl.length);
      this.addEditForm.removeControl(this.listOfControl[this.listOfControl.length].controlName);
      this.addEditForm.removeControl(this.listOfControl[this.listOfControl.length].controlPrice);
      this.addEditForm.removeControl(this.listOfControl[this.listOfControl.length].controlLimitPeople);
      this.addEditForm.removeControl(this.listOfControl[this.listOfControl.length].controlLimitProduct);
      this.addEditForm.removeControl(this.listOfControl[this.listOfControl.length].controlNote);
      this.addEditForm.removeControl(this.listOfControl[this.listOfControl.length].controlDescription);
    }
  }

  checkFormNDLInValid(): boolean {
    let count = 0;
    this.listOfControl.forEach((e) => {
      if (this.addEditForm.get(e.controlName).invalid) {
        count++;
        this.addEditForm.get(e.controlName).markAsDirty();
        this.addEditForm.get(e.controlName).updateValueAndValidity();
      }
      if (this.addEditForm.get(e.controlPrice).invalid) {
        count++;
        this.addEditForm.get(e.controlPrice).markAsDirty();
        this.addEditForm.get(e.controlPrice).updateValueAndValidity();
      }
    })

    return count == 0;
  }

  handleOk() {
    let packages = [];
    this.listOfControl.forEach(e => {
      packages.push({
        name: this.addEditForm.value[e.controlName], price: this.addEditForm.value[e.controlPrice],
        limitPeople: this.addEditForm.value[e.controlLimitPeople], limitProduct: this.addEditForm.value[e.controlLimitProduct],
        note: this.addEditForm.value[e.controlNote], description: this.addEditForm.value[e.controlDescription],
      })
    });
    if( this.checkFormNDLInValid()){
      this.service.editPackages(packages, this.data.id).subscribe(
      {
          next: (res) => {
            this.isLoading = false;
            this.notification.success("Thao tác thực hiện thành công!");
            this.modal.destroy();
          }, error: (err) => {
            this.notification.error("Có lỗi sảy ra trong quá trình thực hiện!");
          }
      })
    }
  }

  handleCancel() {

  }
}
