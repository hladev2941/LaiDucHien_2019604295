export interface IPackageService {
    name?: string;
    price?: number;
    limitPeople?: number;
    limitProduct?: number;
    note?: string;
    description?: string;
  }
  
  export class PackageService implements IPackageService {
    constructor(
      public name?: string,
      public price?: number,
      public limitPeople?: number,
      public limitProduct?: number,
      public note?: string,
      public description?: string,
    ) {}
  }