import { Component, ElementRef, Input, OnInit, ViewChild } from '@angular/core';
import { ISelect2, Select2 } from 'src/app/_utils/select2.model';
import { Customer, ICustomer } from '../customer.model';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NzModalRef } from 'ng-zorro-antd/modal';
import { CustomerService } from '../customer.service';
import { AlertService } from 'src/app/_utils/notification.service';

@Component({
  selector: 'app-add-edit-customer',
  templateUrl: './add-edit-customer.component.html',
  styleUrls: ['./add-edit-customer.component.scss']
})
export class AddEditCustomerComponent implements OnInit {

  
  addEditForm: FormGroup;
  isSearch: boolean = false;
  isLoading = false;
  @ViewChild('fileInput') fileInput!: ElementRef<HTMLInputElement>;
  public imageUrl: any;

  @Input() data?: ICustomer;
  @Input() view?: boolean;

  @ViewChild("username") username: ElementRef;
  usernameErrMsg: any;
  focusOnErrUsername() {
    this.username.nativeElement.focus();
  }

  @ViewChild("password") password: ElementRef;
  passwordErrMsg: any;
  focusOnErrPassword() {
    this.password.nativeElement.focus();
  }

  @ViewChild("fullName") fullName: ElementRef;
  fullNameErrMsg: any;
  focusOnErrFullName() {
    this.fullName.nativeElement.focus();
  }

  @ViewChild("phone") phone: ElementRef;
  phoneErrMsg: any;
  focusOnErrPhone() {
    this.phone.nativeElement.focus();
  }

  @ViewChild("email") email: ElementRef;
  emailErrMsg: any;
  focusOnErrEmail() {
    this.email.nativeElement.focus();
  }

  @ViewChild("citizenIdentificationNumber") citizenIdentificationNumber: ElementRef;
  citizenIdentificationNumberErrMsg: any;
  focusOnErrCitizenIdentificationNumber() {
    this.citizenIdentificationNumber.nativeElement.focus();
  }

  @ViewChild("issuedBy") issuedBy: ElementRef;
  issuedByErrMsg: any;
  focusOnErrIssuedBy() {
    this.issuedBy.nativeElement.focus();
  }

  @ViewChild("permanentAddress") permanentAddress: ElementRef;
  permanentAddressErrMsg: any;
  focusOnErrPermanentAddress() {
    this.permanentAddress.nativeElement.focus();
  }
  
  issuedOnErrMsg: any;
  moveInDateErrMsg: any;
  descriptionErrMsg: any;


  constructor(private fb: FormBuilder,
    private modal: NzModalRef,
    private customerService: CustomerService,
    private notification: AlertService) { }

  ngOnInit(): void {
    this.addEditForm = this.fb.group({
        id:[null, []],
        username: [null, [Validators.required]],
        password:[null, [Validators.required]],
        role:[null, []],
        phone:[null, [Validators.required]],
        fullName:[null, [Validators.required]],
        email:[null, [Validators.required]],
        dob:[null, []],
        citizenIdentificationNumber:[null, []],
        gender: [null, []],
        issuedBy:[null, []],
        issuedOn:[null, []],
        moveInDate:[null, [Validators.required]],
        permanentAddress: [null, []],
        description:[null, []],
        status:[true, []],
        tinh:[null, []],
        huyen: [null, []],
        xa: [null, []],
    });
    if (this.data) {
      this.onPatch(this.data);
      this.initViewImages();
      this.selectedValueTinh = {
          ...new Select2(),
          id: this.data?.cityId,
          name: this.data?.cityName,
      };
      this.selectedValueHuyen = {
          ...new Select2(),
          id: this.data?.districtId,
          name: this.data?.districtName,
      };
      this.selectedValueXa = {
          ...new Select2(),
          id: this.data?.wardId,
          name: this.data?.wardName,
      };
    }
    if (this.view) {
      this.addEditForm.disable();
    }
  }

  onPatch(patchData: ICustomer): void {
    this.addEditForm.patchValue({
        id: patchData.id,
        username: patchData.username,
        password: patchData.password,
        role: patchData.role,
        fullName: patchData.fullName,
        email: patchData.email,
        phone: patchData.phone,
        dob: patchData.dob,
        citizenIdentificationNumber: patchData.citizenIdentificationNumber,
        gender: patchData.gender + "",
        issuedBy: patchData.issuedBy,
        issuedOn: patchData.issuedOn,
        moveInDate: patchData.moveInDate,
        permanentAddress: patchData.permanentAddress,
        description: patchData.description,
        status: patchData.status == 1 ? true : false,
    });
  }

  initViewImages() {
    this.customerService.getFiles(this.data?.username).subscribe({
      next: (res) => {        
        this.imageUrl = { file: null, url: res.data };
      },
      error: (err) => console.log(err),
    });
  }

  getFromSearch(avatar: any): Customer {
      let { username, password, role, fullName, email, phone, dob, citizenIdentificationNumber, gender, issuedBy, issuedOn, moveInDate, permanentAddress,
         tinh, huyen, xa, description, status } = this.addEditForm.value;
      return {
          ...new Customer(),
          id: this.data?.id,
          username: username,
          password: password,
          avatar: avatar,
          role: role,
          fullName: fullName,
          email: email,
          phone: phone,
          dob: dob,
          citizenIdentificationNumber: citizenIdentificationNumber,
          gender: Number(gender),
          issuedBy: issuedBy,
          issuedOn: issuedOn,
          moveInDate: moveInDate,
          permanentAddress: permanentAddress,
          cityId: tinh?.id,
          districtId: huyen?.id,
          wardId: xa?.id,
          cityName: tinh?.name,
          districtName: huyen?.name,
          wardName: xa?.name,
          description: description,
          status: status ? 1 : 0
      };
  }

  openFileInput() {
    this.fileInput.nativeElement.click();
  }

  onFileChange(event: any) {
    if (event.target.files && event.target.files.length) {
      const files: File[] = event.target.files;
      for (const file of files) {
        const reader = new FileReader();
        reader.onload = (e: any) => {
          this.imageUrl= { file: file, url: e.target.result };
        };
        reader.readAsDataURL(file);
      }
    }
  }
  handleOk(): void {
    if (this.validateCreate()) {
      this.isLoading = true;
      if(this.imageUrl?.file){
        const formData: FormData = new FormData();
        formData.append("username", this.addEditForm.value.username)
        formData.append('fileUpload', this.imageUrl.file);
        this.customerService.addFiles(formData).subscribe((res) => {
          this.customerService.save(this.getFromSearch(res.data)).subscribe(
            {
                next: (res) => {
                  this.isLoading = false;
                  this.notification.success("Thao tác thực hiện thành công!");
                  this.modal.destroy();
                }, error: (err) => {
                  this.notification.error("Có lỗi sảy ra trong quá trình thực hiện!");
                }
            })
        })
      }else{
        this.customerService.save(this.getFromSearch(null)).subscribe(
          {
              next: (res) => {
                this.isLoading = false;
                this.notification.success("Thao tác thực hiện thành công!");
                this.modal.destroy();
              }, error: (err) => {
                this.notification.error("Có lỗi xảy ra trong quá trình thực hiện!");
              }
          })
      }
    }
  }

  handleCancel(): void {
    this.modal.destroy();
  }

  validateCreate() {
    let isValid = true;
    if (!this.addEditForm.value.username || !this.addEditForm.value.username.trim()) {
      this.usernameErrMsg = "Tên tài khoản bắt buộc nhập";
      isValid = false;
      this.focusOnErrUsername();
    }
    if (!this.data && (!this.addEditForm.value.password || !this.addEditForm.value.password.trim())) {
      this.passwordErrMsg = "Mật khẩu đăng nhập bắt buộc nhập";
      isValid = false;
      this.focusOnErrPassword();
    }
    if (!this.addEditForm.value.fullName || !this.addEditForm.value.fullName.trim()) {
      this.fullNameErrMsg = "Họ tên bắt buộc nhập";
      isValid = false;
      this.focusOnErrFullName();
    }
    if (!this.addEditForm.value.phone || !this.addEditForm.value.phone.trim()) {
      this.phoneErrMsg = "Số điện thoại bắt buộc nhập";
      isValid = false;
      this.focusOnErrPhone();
    }
    if (!this.addEditForm.value.email || !this.addEditForm.value.email.trim()) {
      this.emailErrMsg = "Thông tin email bắt buộc nhập";
      isValid = false;
      this.focusOnErrEmail();
    }
    if (!this.addEditForm.value.citizenIdentificationNumber || !this.addEditForm.value.citizenIdentificationNumber.trim()) {
      this.citizenIdentificationNumberErrMsg = "Số cccd/cmnd bắt buộc nhập";
      isValid = false;
      this.focusOnErrCitizenIdentificationNumber();
    }
    if (!this.addEditForm.value.issuedBy || !this.addEditForm.value.issuedBy.trim()) {
      this.issuedByErrMsg = "Nơi cấp cccd/cmnd bắt buộc nhập";
      isValid = false;
      this.focusOnErrIssuedBy();
    }
    if (!this.addEditForm.value.permanentAddress || !this.addEditForm.value.permanentAddress.trim()) {
      this.permanentAddressErrMsg = "Địa chỉ thường trú bắt buộc nhập";
      isValid = false;
      this.focusOnErrPermanentAddress();
    }
    if (!this.addEditForm.value.issuedOn) {
      this.issuedOnErrMsg = "Ngày cấp cccd/cmnd bắt buộc nhập";
      isValid = false;
    }
    if (!this.addEditForm.value.moveInDate) {
      this.moveInDateErrMsg = "Ngày chuyển đến bắt buộc nhập";
      isValid = false;
    }
    

    return isValid;
  }

  clearUsernameMessage(){
    this.usernameErrMsg = "";
  }

  clearPasswordMessage(){
    this.passwordErrMsg = "";
  }

  clearFullNameMessage(){
    this.fullNameErrMsg = "";
  }

  clearPhoneMessage(){
    this.phoneErrMsg = "";
  }

  clearCitizenIdentificationNumberMessage(){
    this.citizenIdentificationNumberErrMsg = "";
  }

  clearIssuedByMessage(){
    this.issuedByErrMsg = "";
  }

  clearIssuedOnMessage(){
    this.issuedOnErrMsg = "";
  }

  clearEmailMessage(){
    this.emailErrMsg = "";
  }

  clearPermanentAddressMessage(){
    this.permanentAddressErrMsg = "";
  }

  clearMoveInDateMessage(){
    console.log("clearMoveInDateMessage");
    
    this.moveInDateErrMsg = "";
  }

  compareFn = (o1: any, o2: any) => (o1 && o2 ? o1.id === o2.id : o1 === o2);
    //SELECT2 tinh
    totalTinh: number = 1;
    pageTinh = 1;
    tinhs: ISelect2[] = [];
    selectedValueTinh: ISelect2;

    loadMoreTinh(key?: any): void {
        if (this.tinhs.length <= this.totalTinh) {
            this.isLoading = true;
            this.customerService
                .getDiaChiById({
                    ...new Select2(),
                    key: key ?? '',
                    page: this.pageTinh,
                    size: 10,
                })
                .subscribe((res) => {
                
                    if (res != null && res.data) {
                        this.tinhs = this.tinhs.concat(res.data);
                        this.pageTinh += 1;
                        this.totalTinh = res.total;
                        this.isLoading = false;
                    }
                });
        }
    }

    onSearchTinh(key?: any): void {
        this.isSearch = true;
        this.pageTinh = 1;
        this.tinhs = [];
        this.loadMoreTinh(key);
    }

    loadHuyen() {
        this.addEditForm.get('huyen').setValue(null);
        this.addEditForm.get('xa').setValue(null);
        this.onSearchHuyen();
    }

    //Select2 Huyen
    totalHuyen: number = 1;
    pageHuyen = 1;
    huyens: ISelect2[] = [];
    selectedValueHuyen: ISelect2;

    loadMoreHuyen(key?: any): void {
        if (this.huyens.length <= this.totalHuyen) {
            this.isLoading = true;
            if (!this.addEditForm.value.tinh) {
                return;
            }
            this.customerService
                .getDiaChiById({
                    ...new Select2(),
                    key: key ?? '',
                    cha_id: this.addEditForm.value.tinh.id,
                    page: this.pageHuyen,
                    size: 10,
                })
                .subscribe((res) => {
                    if (res != null && res.data) {
                        this.huyens = this.huyens.concat(res.data);
                        this.pageHuyen += 1;
                        this.totalHuyen = res.total;
                        this.isLoading = false;
                    }
                });
        }
    }

    onSearchHuyen(key?: any): void {
        this.isSearch = true;
        this.pageHuyen = 1;
        this.huyens = [];
        this.loadMoreHuyen(key);
    }

    loadXa() {
        this.addEditForm.get('xa').setValue(null);
        this.onSearchXa();
    }
    //Select2 Xa
    totalXa: number = 1;
    pageXa = 1;
    xas: ISelect2[] = [];
    selectedValueXa: ISelect2;

    loadMoreXa(key?: any): void {
        if (this.xas.length <= this.totalXa) {
            this.isLoading = true;
            if (!this.addEditForm.value.huyen) {
                return;
            }
            this.customerService
                .getDiaChiById({
                    ...new Select2(),
                    key: key ?? '',
                    cha_id: this.addEditForm.value.huyen.id,
                    page: this.pageXa,
                    size: 10,
                })
                .subscribe((res) => {
                    if (res != null && res.data) {
                        this.xas = this.xas.concat(res.data);
                        this.pageXa += 1;
                        this.totalXa = res.total;
                        this.isLoading = false;
                    }
                });
        }
    }

    onSearchXa(key?: any): void {
        this.isSearch = true;
        this.pageXa = 1;
        this.xas = [];
        this.loadMoreXa(key);
    }

  previewImage: string | undefined = '';
  previewVisible = false;

  handlePreview = (file: { url: string; }) => {
    this.previewImage = file.url;
    this.previewVisible = true;
  }

}
