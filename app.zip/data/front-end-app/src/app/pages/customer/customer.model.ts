export interface ICustomer {
    id?: number;
    username?: string;
    password?: string;
    role?: string;
    numberFailures?: number;
    avatar?: string;
    fullName?: string;
    email?: string;
    phone?: string;
    dob?: string;
    citizenIdentificationNumber?: string;
    gender?: number;
    issuedBy?:string;
    issuedOn?:string;
    moveInDate?:string;
    permanentAddress?: number;
    description?:string;
    status?:number;
    cityId?:number;
    districtId?:number;
    wardId?:number;
    cityName?:string;
    districtName?:string;
    wardName?:string;
    page?: number;
    size?: number;
  }
  
  export class Customer implements ICustomer {
    constructor(
        public id?: number,
        public username?: string,
        public password?: string,
        public role?: string,
        public numberFailures?: number,
        public avatar?: string,
        public fullName?: string,
        public email?: string,
        public phone?: string,
        public dob?: string,
        public citizenIdentificationNumber?: string,
        public gender?: number,
        public issuedBy?:string,
        public issuedOn?:string,
        public moveInDate?:string,
        public permanentAddress?: number,
        public description?:string,
        public status?:number,
        public cityId?:number,
        public districtId?:number,
        public wardId?:number,
        public cityName?:string,
        public districtName?:string,
        public wardName?:string,
        public page?: number,
        public size?: number
    ) {}
  }