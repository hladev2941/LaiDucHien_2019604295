import { ChangeDetectorRef, Component, HostListener, OnInit, ViewContainerRef } from '@angular/core';
import { AddEditCustomerComponent } from '../add-edit-customer/add-edit-customer.component';
import { Customer, ICustomer } from '../customer.model';
import { AlertService } from 'src/app/_utils/notification.service';
import { CustomerService } from '../customer.service';
import { NzModalService } from 'ng-zorro-antd/modal';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ISelect2, Select2 } from 'src/app/_utils/select2.model';

@Component({
  selector: 'app-list-customer',
  templateUrl: './list-customer.component.html',
  styleUrls: ['./list-customer.component.scss']
})
export class ListCustomerComponent implements OnInit {

  building: ICustomer[];
  size = 10;
  page = 1;
  total: number = 0;
  searchForm: FormGroup;
  pageSizeOptions: number[] = [10, 20, 50, 100];

  constructor(
    private fb: FormBuilder,
    private nzModalService: NzModalService,
    private viewContainerRef: ViewContainerRef,
    private customerService: CustomerService,
    private notification: AlertService,
    private ref: ChangeDetectorRef,
  ) { }

  ngOnInit(): void {
    this.searchForm = this.fb.group({
      name: [null, []],
      status: [null, []],
      phone: [null, []],
      gender: [null, []],
      tinh: [null, []],
      huyen: [null, []],
      xa: [null, []],
    });

    this.search();
  }

  getFromSearch(): Customer {
    let { name, status, phone, gender, tinh, huyen, xa } = this.searchForm.value;
    return {
      ...new Customer(),
      fullName: name,
      status: status ? (status == '0' ? 0 : 1) : null,
      phone: phone,
      gender: gender,
      cityId: tinh?.id,
      districtId: huyen?.id,
      wardId: xa?.id,
      page: this.page,
      size: this.size,
    };
  }

  onSearch() {
    this.customerService.search(this.getFromSearch()).subscribe({
      next: (res) => {
        this.total = res.total;
        this.building = res.data;
      },
      error: (err) => console.log(err),
    });
  }

  search() {
    this.page = 1;
    this.size = 10;
    this.onSearch();
  }

  resetForm() {

  }

  showModal() {
    const modal = this.nzModalService.create({
      nzTitle: 'Thêm mới thông tin người thuê',
      nzContent: AddEditCustomerComponent,
      nzViewContainerRef: this.viewContainerRef,
      nzWidth: '1000px',
      nzComponentParams: {
      },
      nzOnCancel: () => this.handleCancel(modal),
    });
    modal.afterClose.subscribe(() => {
      this.onSearch();
    });
  }

  handleCancel(modal): Promise<void> {
    return new Promise((resolve, reject) => {
      const confirmModal = this.nzModalService.confirm({
        nzTitle: 'Thông báo xác nhận huỷ',
        nzContent: 'Bạn có chắc chắn muốn huỷ?',
        nzOnOk: () => {
          modal.close();
          confirmModal.close();
          resolve();
        },
        nzOnCancel: () => {
          reject();
        },
      });
    });
  }

  isLoading = false;

  showModalEdit(data: any) {
    const modal = this.nzModalService.create({
      nzTitle: 'Chỉnh sửa thông tin người thuê',
      nzContent: AddEditCustomerComponent,
      nzViewContainerRef: this.viewContainerRef,
      nzWidth: '1000px',
      nzComponentParams: {
        data: data
      },
      nzOnCancel: () => this.handleCancel(modal),
    });
    modal.afterClose.subscribe(() => {
      this.onSearch();
    });
  }

  showModalView(data: any) {
    const modal = this.nzModalService.create({
      nzTitle: 'Chỉnh sửa thông tin người thuê',
      nzContent: AddEditCustomerComponent,
      nzViewContainerRef: this.viewContainerRef,
      nzWidth: '1000px',
      nzComponentParams: {
        data: data,
        view: true
      },
      nzOnCancel: () => this.handleCancel(modal),
    });
  }

  onChangePage($event: number) {
    this.page = $event;
    this.onSearch();
  }

  onChangeSizePage($event: number) {
    this.page = 1;
    this.size = $event;
    this.onSearch();
  }


  delete(data: any) {
    this.nzModalService.confirm({
      nzTitle: 'Thông báo xác nhận xóa',
      nzContent: 'Bạn có chắc chắn muốn xóa thông tin người thuê này không?',
      nzOkText: 'Xác nhận',
      nzCancelText: 'Huỷ',
      nzOkDanger: true,
      nzIconType: 'delete',
      nzOnOk: () => {
        this.customerService.delete(data).subscribe((res) => {
          if (res.err_code == 0) {
            this.notification.success(
              'Thao tác thực hiện thành công!'
            );
          } else {
            this.notification.error(
              'Thao tác thực hiện không thành công!'
            );
          }
          this.search();
        });
      },
    });
  }

    //SELECT2 tinh
    isSearch = false
    totalTinh: number = 1;
    pageTinh = 1;
    tinhs: ISelect2[] = [];
    loadMoreTinh(key?: any): void {
        if (this.tinhs.length <= this.totalTinh) {
            this.isLoading = true;
            this.customerService
                .getDiaChiById({
                    ...new Select2(),
                    key: key ?? '',
                    page: this.pageTinh,
                    size: 10,
                })
                .subscribe((res) => {
                
                    if (res != null && res.data) {
                        this.tinhs = this.tinhs.concat(res.data);
                        this.pageTinh += 1;
                        this.totalTinh = res.total;
                        this.isLoading = false;
                    }
                });
        }
    }

    onSearchTinh(key?: any): void {
        this.isSearch = true;
        this.pageTinh = 1;
        this.tinhs = [];
        this.loadMoreTinh(key);
    }

    loadHuyen() {
        this.searchForm.get('huyen').setValue(null);
        this.searchForm.get('xa').setValue(null);
        this.onSearchHuyen();
    }

    //Select2 Huyen
    totalHuyen: number = 1;
    pageHuyen = 1;
    huyens: ISelect2[] = [];

    loadMoreHuyen(key?: any): void {
        if (this.huyens.length <= this.totalHuyen) {
            this.isLoading = true;
            if (!this.searchForm.value.tinh) {
                return;
            }
            this.customerService
                .getDiaChiById({
                    ...new Select2(),
                    key: key ?? '',
                    cha_id: this.searchForm.value.tinh.id,
                    page: this.pageHuyen,
                    size: 10,
                })
                .subscribe((res) => {
                    if (res != null && res.data) {
                        this.huyens = this.huyens.concat(res.data);
                        this.pageHuyen += 1;
                        this.totalHuyen = res.total;
                        this.isLoading = false;
                    }
                });
        }
    }

    onSearchHuyen(key?: any): void {
        this.isSearch = true;
        this.pageHuyen = 1;
        this.huyens = [];
        this.loadMoreHuyen(key);
    }

    loadXa() {
        this.searchForm.get('xa').setValue(null);
        this.onSearchXa();
    }
    //Select2 Xa
    totalXa: number = 1;
    pageXa = 1;
    xas: ISelect2[] = [];

    loadMoreXa(key?: any): void {
        if (this.xas.length <= this.totalXa) {
            this.isLoading = true;
            if (!this.searchForm.value.huyen) {
                return;
            }
            this.customerService
                .getDiaChiById({
                    ...new Select2(),
                    key: key ?? '',
                    cha_id: this.searchForm.value.huyen.id,
                    page: this.pageXa,
                    size: 10,
                })
                .subscribe((res) => {
                    if (res != null && res.data) {
                        this.xas = this.xas.concat(res.data);
                        this.pageXa += 1;
                        this.totalXa = res.total;
                        this.isLoading = false;
                    }
                });
        }
    }

    onSearchXa(key?: any): void {
        this.isSearch = true;
        this.pageXa = 1;
        this.xas = [];
        this.loadMoreXa(key);
    }

  @HostListener('document:keypress', ['$event'])
  keyEvent(event: KeyboardEvent) {
    if (event.keyCode === 13) {
      this.search();
    }
  }

}
