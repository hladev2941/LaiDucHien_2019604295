import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CustomerRoutingModule } from './customer-routing.module';
import { ListCustomerComponent } from './list-customer/list-customer.component';
import { AddEditCustomerComponent } from './add-edit-customer/add-edit-customer.component';
import { ModuleShare } from 'src/app/ng-zorro-antd.module';


@NgModule({
  declarations: [
    ListCustomerComponent,
    AddEditCustomerComponent
  ],
  imports: [
    CommonModule,
    CustomerRoutingModule,
    ModuleShare
  ]
})
export class CustomerModule { }
