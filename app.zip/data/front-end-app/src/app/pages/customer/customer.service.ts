import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ResponseAPI } from 'src/app/_utils/response.model';
import { Constants } from '../../_utils/constants';
import { ICustomer } from './customer.model';

@Injectable({
  providedIn: 'root',
})
export class CustomerService {
  private baseUrl = Constants.HOST + "/v1/user";
  constructor(private http: HttpClient) {}

  search(building: ICustomer) {
    return this.http.post<ResponseAPI<ICustomer[]>>(`${this.baseUrl}/search`, building);
  }

  save(building: ICustomer){
    return this.http.post<ResponseAPI<any>>(`${this.baseUrl}/save`, building)
  }

  delete(building: ICustomer){
    return this.http.post<ResponseAPI<any>>(`${this.baseUrl}/delete`, building)
  }
  
  getDiaChiById(data: any) {
    return this.http.post<ResponseAPI<ICustomer[]>>(`${this.baseUrl}/dia-chi`, data);
  }

  getFiles(username: any) {
    return this.http.get<ResponseAPI<any>>(`${this.baseUrl}/get-files/` + username);
  }

  addFiles(data: any) {
    return this.http.post<ResponseAPI<any>>(`${this.baseUrl}/add-file`, data);
  }
}
