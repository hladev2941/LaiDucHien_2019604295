import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ResponseAPI } from 'src/app/_utils/response.model';
import { Constants } from '../../_utils/constants';
import { IContract } from './contract.model';

@Injectable({
  providedIn: 'root',
})
export class ContractService {
  private baseUrl = Constants.HOST + "/v1/contract";
  constructor(private http: HttpClient) {}

  search(contract: IContract) {
    return this.http.post<ResponseAPI<IContract[]>>(`${this.baseUrl}/search`, contract);
  }

  save(contract: IContract){
    return this.http.post<ResponseAPI<any>>(`${this.baseUrl}/save`, contract)
  }

  delete(contract: IContract){
    return this.http.post<ResponseAPI<any>>(`${this.baseUrl}/delete`, contract)
  }

  getPeopleInRoom(roomId: any, contractId: any) {
    return this.http.get<ResponseAPI<any>>(`${this.baseUrl}/get-people-in-room/`+contractId +`/` + roomId);
  }

  loadBuilding(data: any) {
    return this.http.post<ResponseAPI<any>>(`${this.baseUrl}/load-building`, data);
  }

  loadRoom(data: any, buildingId: any) {
    data = {
      ...data,
      status : 1
    }
    return this.http.post<ResponseAPI<any>>(`${this.baseUrl}/load-room/`+buildingId, data);
  }

  loadRoomInfo(roomId: any) {
    return this.http.get<ResponseAPI<any>>(`${this.baseUrl}/load-room-info/`+roomId);
  }

  loadUser(data: any) {
    return this.http.post<ResponseAPI<any>>(`${this.baseUrl}/load-user`, data);
  }
}
