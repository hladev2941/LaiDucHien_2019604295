import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ContractRentRoutingModule } from './contract-rent-routing.module';
import { ListContractRentComponent } from './list-contract-rent/list-contract-rent.component';
import { AddEditContracRentComponent } from './add-edit-contrac-rent/add-edit-contrac-rent.component';
import { ModuleShare } from 'src/app/ng-zorro-antd.module';
import { ViewContracRentComponent } from './view-contract-rent/view-contract-rent.component';


@NgModule({
  declarations: [
    ListContractRentComponent,
    AddEditContracRentComponent,
    ViewContracRentComponent
  ],
  imports: [
    CommonModule,
    ContractRentRoutingModule,
    ModuleShare
  ]
})
export class ContractRentModule { }
