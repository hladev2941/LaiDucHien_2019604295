interface IContract {
  id?: number;
  signDate?: string;
  dueDate?: string;
  status?: number;
  roomId?: number;
  roomName?: string;
  buildingId?: number;
  buildingName?: string;
  rent?: number;
  parkingFee?: number;
  electricFee?: number;
  waterFee?: number;
  internetFee?: number;
  environmentFee?: number;
  users?: any[];
  fromDateSignDate?: string;
  toDateSignDate?: string;
  fromDateDueDate?: string;
  toDateDueDate?: string;
  createdBy?: string;
  createdDate?: string;
  notes?: string;
  page?: number;
  size?: number;
}

interface IUser {
  id: number;
  fullName: string;
  email: string;
  phone: string;
  dob: Date;
  citizenIdentificationNumber: string;
  gender: number;
}

class Contract implements IContract {
  constructor(
    public id?: number,
    public signDate?: string,
    public dueDate?: string,
    public status?: number,
    public roomId?: number,
    public roomName?: string,
    public buildingId?: number,
    public buildingName?: string,
    public rent?: number,
    public parkingFee?: number,
    public electricFee?: number,
    public waterFee?: number,
    public internetFee?: number,
    public environmentFee?: number,
    public users?: any[],
    public fromDateSignDate?: string,
    public toDateSignDate?: string,
    public fromDateDueDate?: string,
    public toDateDueDate?: string,
    public createdBy?: string,
    public createdDate?: string,
    public notes?: string,
    public page?: number,
    public size?: number
  ) {}
}

export { IUser, Contract, IContract };
