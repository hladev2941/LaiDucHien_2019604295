import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ListContractRentComponent } from './list-contract-rent/list-contract-rent.component';

const routes: Routes = [
  {
    path:'',
    component: ListContractRentComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ContractRentRoutingModule { }
