import { Component, ElementRef, Input, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Contract, IContract } from '../contract.model';
import { NzModalRef } from 'ng-zorro-antd/modal';
import { ContractService } from '../contract.service';
import { AlertService } from 'src/app/_utils/notification.service';
import { ISelect2, Select2 } from 'src/app/_utils/select2.model';

@Component({
  selector: 'app-add-edit-contrac-rent',
  templateUrl: './add-edit-contrac-rent.component.html',
  styleUrls: ['./add-edit-contrac-rent.component.scss']
})
export class AddEditContracRentComponent implements OnInit {
  addEditForm: FormGroup;
  isSearch: boolean = false;
  isLoading = false;
  @Input() data?: IContract;

  @ViewChild("building") building: ElementRef;
  buildingErrMsg: any;
  focusOnErrBuilding() {
    this.building.nativeElement.focus();
  }
  @ViewChild("room") room: ElementRef;
  roomErrMsg: any;
  focusOnErrRoom() {
    this.room.nativeElement.focus();
  }
  @ViewChild("user") user: ElementRef;
  userErrMsg: any;
  focusOnErrUser() {
    this.user.nativeElement.focus();
  }
  @ViewChild("signDate") signDate: ElementRef;
  signDateErrMsg: any;
  focusOnErrSignDate() {
    this.signDate.nativeElement.focus();
  }
  @ViewChild("dueDate") dueDate: ElementRef;
  dueDateErrMsg: any;
  focusOnErrDueDate() {
    this.dueDate.nativeElement.focus();
  }

  @ViewChild("electricFee") electricFee: ElementRef;
  electricFeeErrMsg: any;
  focusOnErrElectricFee() {
    this.electricFee.nativeElement.focus();
  }

  @ViewChild("waterFee") waterFee: ElementRef;
  waterFeeErrMsg: any;
  focusOnErrWaterFee() {
    this.waterFee.nativeElement.focus();
  }

  @ViewChild("internetFee") internetFee: ElementRef;
  internetFeeErrMsg: any;
  focusOnErrInternetFee() {
    this.internetFee.nativeElement.focus();
  }

  @ViewChild("environmentFee") environmentFee: ElementRef;
  environmentFeeErrMsg: any;
  focusOnErrEnvironmentFee() {
    this.environmentFee.nativeElement.focus();
  }

  @ViewChild("rent") rent: ElementRef;
  rentErrMsg: any;
  focusOnErrRent() {
    this.rent.nativeElement.focus();
  }

  @ViewChild("parkingFee") parkingFee: ElementRef;
  parkingFeeErrMsg: any;
  focusOnErrParkingFee() {
    this.parkingFee.nativeElement.focus();
  }

  constructor(private fb: FormBuilder,
    private modal: NzModalRef,
    private contractService: ContractService,
    private notification: AlertService) { }

  ngOnInit(): void {
    this.addEditForm = this.fb.group({
      id: [null, []],
      signDate: [null, []],
      dueDate: [null, []],
      building: [null, []],
      room: [null, []],
      rent: [null, []],
      parkingFee: [null, []],
      electricFee: [null, []],
      waterFee: [null, []],
      internetFee: [null, []],
      environmentFee: [null, []],
      user: [[], []],
      description: [null, []],
      status: [true, []],
    });
    if (this.data) {
      this.onPatch(this.data);
      this.initRoleForUser();
      this.selectedValueBuilding = {
        ...new Select2(),
        id: this.data?.buildingId,
        name: this.data?.buildingName,
      };
      this.selectedValueRoom = {
        ...new Select2(),
        id: this.data?.roomId,
        name: this.data?.roomName,
      };
    }
  }

  onPatch(patchData: IContract): void {
    this.addEditForm.patchValue({
      id: patchData.id,
      signDate: patchData.signDate,
      dueDate: patchData.dueDate,
      rent: patchData.rent,
      parkingFee: patchData.parkingFee,
      electricFee: patchData.electricFee,
      waterFee: patchData.waterFee,
      internetFee: patchData.internetFee,
      environmentFee: patchData.environmentFee,
      status: patchData.status == 1 ? true : false,
      description: patchData.notes
    });
  }

  initRoleForUser(): void {
      this.contractService.getPeopleInRoom(this.data.roomId, this.data.id).subscribe({
          next: (res) => {
              if (res != null && res.data) {
                  this.selectedValueUser = res.data;
                  this.addEditForm.patchValue({
                    user: this.selectedValueUser
                  });
              }
          },
          error: (error) => {
            this.notification.error(error.error.message);
          }
      });
  }

  getFromSearch(): Contract {
    let { signDate, dueDate, status, room, building, user, rent, parkingFee, electricFee, waterFee, internetFee, environmentFee, description } = this.addEditForm.value;
    return {
      ...new Contract(),
      id: this.data?.id,
      signDate: signDate,
      dueDate: dueDate,
      roomId: room?.id,
      roomName: room?.name,
      buildingId: building?.id,
      buildingName: building?.name,
      users: user,
      rent: rent,
      parkingFee: parkingFee,
      electricFee: electricFee,
      waterFee: waterFee,
      internetFee: internetFee,
      environmentFee: environmentFee,
      notes: description,
      status: status ? 1 : 0
    };
  }

  handleOk(): void {
    if (this.validateCreate()) {
      this.isLoading = true;
      this.contractService.save(this.getFromSearch()).subscribe(
        {
          next: (res) => {
            this.isLoading = false;
            this.notification.success("Thao tác thực hiện thành công!");
            this.modal.destroy();
          }, error: (err) => {
            this.notification.error("Có lỗi sảy ra trong quá trình thực hiện!");
          }
        })
    }
  }

  handleCancel(): void {
    this.modal.destroy();
  }

  validateCreate() {
    let isValid = true;
    if (!this.addEditForm.value.building) {
      this.buildingErrMsg = "Bắt buộc phải chọn tòa nhà";
      isValid = false;
      this.focusOnErrBuilding();
    }
    if (!this.addEditForm.value.room) {
      this.roomErrMsg = "Bắt buộc phải chọn tòa nhà";
      isValid = false;
      this.focusOnErrRoom();
    }
    if (!this.addEditForm.value.user) {
      this.userErrMsg = "Bắt buộc phải chọn phòng";
      isValid = false;
      this.focusOnErrUser();
    }
    if (!this.addEditForm.value.signDate) {
      this.signDateErrMsg = "Bắt buộc phải chọn ngày ký";
      isValid = false;
      this.focusOnErrSignDate();
    }
    if (!this.addEditForm.value.dueDate) {
      this.dueDateErrMsg = "Bắt buộc phải chọn ngày hết hạn";
      isValid = false;
      this.focusOnErrDueDate();
    }
    if (!this.addEditForm.value.electricFee) {
      this.electricFeeErrMsg = "Bạn phải chọn thông tin phòng";
      isValid = false;
      this.focusOnErrElectricFee();
    }
    if (!this.addEditForm.value.waterFee) {
      this.waterFeeErrMsg = "Tên nội thất bắt buộc nhập";
      isValid = false;
      this.focusOnErrWaterFee();
    }
    if (!this.addEditForm.value.internetFee) {
      this.internetFeeErrMsg = "Giá trị của nội thất bắt buộc nhập";
      isValid = false;
      this.focusOnErrInternetFee();
    }
    if (!this.addEditForm.value.environmentFee) {
      this.environmentFeeErrMsg = "Giá trị của nội thất bắt buộc nhập";
      isValid = false;
      this.focusOnErrEnvironmentFee();
    }
    if (!this.addEditForm.value.rent) {
      this.rentErrMsg = "Tiền thuê phòng bắt buộc nhập";
      isValid = false;
      this.focusOnErrRent();
    }
    if (!this.addEditForm.value.parkingFee) {
      this.parkingFeeErrMsg = "Phì gửi xe bắt buộc nhập";
      isValid = false;
      this.focusOnErrParkingFee();
    }

    return isValid;
  }
  clearBuildingMessage() {
    this.buildingErrMsg = "";
  }

  clearRoomMessage() {
    this.roomErrMsg = "";
  }

  clearUserMessage() {
    this.userErrMsg = "";
  }

  clearDueDateMessage() {
    this.dueDateErrMsg = "";
  }

  clearSignDateMessage() {
    this.signDateErrMsg = "";
  }

  clearRentMessage() {
    this.rentErrMsg = "";
  }

  clearParkingFeeMessage() {
    this.parkingFeeErrMsg = "";
  }

  clearElectricFeeMessage() {
    this.electricFeeErrMsg = "";
  }

  clearWaterFeeMessage() {
    this.waterFeeErrMsg = "";
  }

  clearInternetFeeMessage() {
    this.internetFeeErrMsg = "";
  }

  clearEnvironmentFeeMessage() {
    this.environmentFeeErrMsg = "";
  }

  compareFn = (o1: any, o2: any) => (o1 && o2 ? o1.id === o2.id : o1 === o2);
  // SELECT2 Building
  totalBuilding: number = 1;
  pageBuilding = 1;
  buildings: ISelect2[] = [];
  selectedValueBuilding: ISelect2;

  loadMoreBuilding(key?: any): void {
    if (this.buildings.length <= this.totalBuilding) {
      this.isLoading = true;
      this.contractService
        .loadBuilding({
          ...new Select2(),
          key: key ?? '',
          page: this.pageBuilding,
          size: 10,
        })
        .subscribe((res) => {
          if (res != null && res.data) {
            this.buildings = this.buildings.concat(res.data);
            this.pageBuilding += 1;
            this.totalBuilding = res.total;
            this.isLoading = false;
          }
        });
    }
  }

  onSearchBuilding(key?: any): void {
    this.isSearch = true;
    this.pageBuilding = 1;
    this.buildings = [];
    this.loadMoreBuilding(key);
  }

  loadRoom() {
    this.addEditForm.get('room').setValue(null);
    this.onSearchRoom();
  }

  //SELECT2 Room
  totalRoom: number = 1;
  pageRoom = 1;
  rooms: ISelect2[] = [];
  selectedValueRoom: ISelect2;

  loadMoreRoom(key?: any): void {
    if (this.rooms.length <= this.totalRoom) {
      this.isLoading = true;
      if (!this.addEditForm.value.building) {
        return;
      }
      this.contractService
        .loadRoom({
          key: key ?? '',
          page: this.pageRoom,
          size: 10,
        }, this.addEditForm.value.building?.id)
        .subscribe((res) => {
          if (res != null && res.data) {
            this.rooms = this.rooms.concat(res.data);

            this.pageRoom += 1;
            this.totalRoom = res.total;
            this.isLoading = false;
          }
        });
    }
  }

  onSearchRoom(key?: any): void {
    this.isSearch = true;
    this.totalRoom = 1;
    this.pageRoom = 1;
    this.rooms = [];
    this.loadMoreRoom(key);
  }

  loadRoomInfo(): void {
    if (this.addEditForm.value.room) {
      this.isLoading = true;
      this.contractService
        .loadRoomInfo(this.addEditForm.value.room?.id)
        .subscribe((res) => {
          if (res != null && res.data) {
            this.addEditForm.get('rent').setValue(res.data.rent);
            this.addEditForm.get('parkingFee').setValue(res.data.parkingFee);
            this.addEditForm.get('electricFee').setValue(res.data.electricFee);
            this.addEditForm.get('waterFee').setValue(res.data.waterFee);
            this.addEditForm.get('internetFee').setValue(res.data.internetFee);
            this.addEditForm.get('environmentFee').setValue(res.data.environmentFee);
          }
        });
    }
  }

  //SELECT2 User
  totalUser: number = 1;
  pageUser = 1;
  users: ISelect2[] = [];
  selectedValueUser: any[];

  loadMoreUser(key?: any): void {
    if (this.users.length <= this.totalUser) {
      this.isLoading = true;
      this.contractService
        .loadUser({
          ...new Select2(),
          key: key ?? '',
          page: this.pageUser,
          size: 10,
        })
        .subscribe((res) => {
          if (res != null && res.data) {
            this.users = this.users.concat(res.data);
            this.pageUser += 1;
            this.totalUser = res.total;
            this.isLoading = false;
          }
        });
    }
  }

  onSearchUser(key?: any): void {
    this.isSearch = true;
    this.pageUser = 1;
    this.users = [];
    this.loadMoreUser(key);
  }
}
