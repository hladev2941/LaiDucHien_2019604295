import { Component, HostListener, ViewContainerRef } from '@angular/core';
import { AddEditContracRentComponent } from '../add-edit-contrac-rent/add-edit-contrac-rent.component';
import { Contract, IContract } from '../contract.model';
import { AlertService } from 'src/app/_utils/notification.service';
import { ContractService } from '../contract.service';
import { NzModalService } from 'ng-zorro-antd/modal';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ISelect2, Select2 } from 'src/app/_utils/select2.model';
import { ViewContracRentComponent } from '../view-contract-rent/view-contract-rent.component';

@Component({
  selector: 'app-list-contract-rent',
  templateUrl: './list-contract-rent.component.html',
  styleUrls: ['./list-contract-rent.component.scss']
})
export class ListContractRentComponent {
  contracts: IContract[];
  size = 10;
  page = 1;
  total: number = 0;
  searchForm: FormGroup;
  pageSizeOptions: number[] = [10, 20, 50, 100];
  fromSignDate = null;
  fromDueDate = null;
  toSignDate = null;
  toDueDate = null;
  status = null;

  constructor(
    private fb: FormBuilder,
    private nzModalService: NzModalService,
    private viewContainerRef: ViewContainerRef,
    private contractService: ContractService,
    private notification: AlertService,
  ) { }

  ngOnInit(): void {
    this.searchForm = this.fb.group({
      fromDateSignDate: [null, []],
      toDateSignDate: [null, []],
      fromDateDueDate: [null, []],
      toDateDueDate: [null, []],
      building: [null, []],
      room: [null, []],
      status: [null, []]
    })
    this.search();
  }

  getFromSearch(): Contract {
    let { fromDateSignDate, toDateSignDate, fromDateDueDate, toDateDueDate, building, room, status } = this.searchForm.value;
    return {
      ...new Contract(),
      fromDateSignDate: fromDateSignDate,
      toDateSignDate: toDateSignDate,
      fromDateDueDate: fromDateDueDate, 
      buildingId: building?.id,
      roomId: room?.id,
      toDateDueDate: toDateDueDate,
      status: status ? (status == '0' ? 0 : 1) : null,
    };
  }

  onSearch() {
    this.contractService.search(this.getFromSearch()).subscribe({
      next: (res) => {
        this.total = res.total;
        this.contracts = res.data;
      },
      error: (err) => console.log(err),
    });
  }

  search() {
    this.page = 1;
    this.size = 10;
    this.onSearch();
  }

  onChangeSignDate(result: Date[]): void {
    if(result){
      this.fromSignDate = result[0]
      this.toSignDate = result[1]
    }
  }

  onChangeDueDate(result: Date[]): void {
    if(result){
      this.fromDueDate = result[0]
      this.toDueDate = result[1]
    }
  }

  resetForm() {

  }

  showModal() {
    const modal = this.nzModalService.create({
      nzTitle: 'Thêm mới thông tin hợp đồng',
      nzContent: AddEditContracRentComponent,
      nzViewContainerRef: this.viewContainerRef,
      nzWidth: '1000px',
      nzComponentParams: {
      },
      nzOnCancel: () => this.handleCancel(modal),
    });
    modal.afterClose.subscribe(() => {
      this.onSearch();
    });
  }

  handleCancel(modal): Promise<void> {
    return new Promise((resolve, reject) => {
      const confirmModal = this.nzModalService.confirm({
        nzTitle: 'Thông báo xác nhận huỷ',
        nzContent: 'Bạn có chắc chắn muốn huỷ?',
        nzOnOk: () => {
          modal.close();
          confirmModal.close();
          resolve();
        },
        nzOnCancel: () => {
          reject();
        },
      });
    });
  }

  isLoading = false;

  showModalEdit(data: any) {
    const modal = this.nzModalService.create({
      nzTitle: 'Chỉnh sửa thông tin hợp đồng',
      nzContent: AddEditContracRentComponent,
      nzViewContainerRef: this.viewContainerRef,
      nzWidth: '1000px',
      nzComponentParams: {
        data: data
      },
      nzOnCancel: () => this.handleCancel(modal),
    });
    modal.afterClose.subscribe(() => {
      this.onSearch();
    });
  }

  showModalView(data: any) {
    const modal = this.nzModalService.create({
      nzTitle: 'Xem chi tiết thông tin hợp đồng',
      nzContent: ViewContracRentComponent,
      nzViewContainerRef: this.viewContainerRef,
      nzWidth: '1000px',
      nzComponentParams: {
        data: data,
      },
      nzFooter: null,
    });
  }

  onChangePage($event: number) {
    this.page = $event;
    this.onSearch();
  }

  onChangeSizePage($event: number) {
    this.page = 1;
    this.size = $event;
    this.onSearch();
  }


  delete(data: any) {
    this.nzModalService.confirm({
      nzTitle: 'Thông báo xác nhận xóa',
      nzContent: 'Bạn có chắc chắn muốn xóa thông tin hợp đồng này không?',
      nzOkText: 'Xác nhận',
      nzCancelText: 'Huỷ',
      nzOkDanger: true,
      nzIconType: 'delete',
      nzOnOk: () => {
        this.contractService.delete(data).subscribe((res) => {
          if (res.err_code == 0) {
            this.notification.success(
              'Thao tác thực hiện thành công!'
            );
          } else {
            this.notification.error(
              'Thao tác thực hiện không thành công!'
            );
          }
          this.search();
        });
      },
    });
  }

  // SELECT2 Building
  isSearch: boolean = false;
  totalBuilding: number = 1;
  pageBuilding = 1;
  buildings: ISelect2[] = [];

  loadMoreBuilding(key?: any): void {
    if (this.buildings.length <= this.totalBuilding) {
      this.isLoading = true;
      this.contractService
        .loadBuilding({
          ...new Select2(),
          key: key ?? '',
          page: this.pageBuilding,
          size: 10,
        })
        .subscribe((res) => {
          if (res != null && res.data) {
            this.buildings = this.buildings.concat(res.data);
            this.pageBuilding += 1;
            this.totalBuilding = res.total;
            this.isLoading = false;
          }
        });
    }
  }

  onSearchBuilding(key?: any): void {
    this.isSearch = true;
    this.pageBuilding = 1;
    this.buildings = [];
    this.loadMoreBuilding(key);
  }

  loadRoom() {
    this.searchForm.get('room').setValue(null);
    this.onSearchRoom();
  }

  //SELECT2 Room
  totalRoom: number = 1;
  pageRoom = 1;
  rooms: ISelect2[] = [];
  selectedValueRoom: ISelect2;

  loadMoreRoom(key?: any): void {
    if (this.rooms.length <= this.totalRoom) {
      this.isLoading = true;
      if (!this.searchForm.value.building) {
        return;
      }
      this.contractService
        .loadRoom({
          ...new Select2(),
          key: key ?? '',
          page: this.pageRoom,
          size: 10,
        }, this.searchForm.value.building?.id)
        .subscribe((res) => {
          if (res != null && res.data) {
            this.rooms = this.rooms.concat(res.data);
            this.pageRoom += 1;
            this.totalRoom = res.total;
            this.isLoading = false;
          }
        });
    }
  }

  onSearchRoom(key?: any): void {
    this.isSearch = true;
    this.pageRoom = 1;
    this.rooms = [];
    this.loadMoreRoom(key);
  }

  @HostListener('document:keypress', ['$event'])
  keyEvent(event: KeyboardEvent) {
    if (event.keyCode === 13) {
      this.search();
    }
  }
}
