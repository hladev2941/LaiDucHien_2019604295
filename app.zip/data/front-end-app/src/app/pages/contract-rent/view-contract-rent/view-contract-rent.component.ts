import { AfterViewInit, Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { IContract, IUser } from '../contract.model';
import { NzModalRef } from 'ng-zorro-antd/modal';
import { ContractService } from '../contract.service';
import { AlertService } from 'src/app/_utils/notification.service';

@Component({
  selector: 'app-view-contrac-rent',
  templateUrl: './view-contract-rent.component.html',
  styleUrls: ['./view-contract-rent.component.scss']
})
export class ViewContracRentComponent implements OnInit, AfterViewInit   {
  addEditForm: FormGroup;
  isSearch: boolean = false;
  isLoading = false;
  @Input() data?: IContract;
  informationUser: IUser[];

  constructor(private fb: FormBuilder,
    private modal: NzModalRef,
    private contractService: ContractService,
    private notification: AlertService) { }

    async ngAfterViewInit(): Promise<void> {
        if (this.data && this.data.roomId && this.data.id) {
            await this.callAPIGetPeopleInRoom();
        } else {
            console.error('Data is not initialized');
        }
    }

   ngOnInit() {
    
   }

  callAPIGetPeopleInRoom(): Promise<void> {
    return new Promise((resolve, reject) => {
      this.contractService.getPeopleInRoom(this.data.roomId, this.data.id).subscribe((res) => {
        this.informationUser = res.data.reduce((accumulator, currentValue) => {
            if (accumulator.every((user) => user.id !== currentValue.id) || accumulator.length == 0) {
                if (currentValue.dob.length > 0) currentValue.dob = new Date(Date.UTC(currentValue.dob[0], currentValue.dob[1] - 1, currentValue.dob[2], currentValue.dob[3], currentValue.dob[4], currentValue.dob[5], currentValue.dob[6]));
                accumulator.push(currentValue);
            }
            return accumulator;
        }, [] as IUser[]);
        resolve();
      }, (error) => {
        reject();
      })
    })

  }
}
