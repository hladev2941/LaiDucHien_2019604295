import { AfterViewInit, Component, Input, OnInit } from '@angular/core';
import { IRoom } from '../room.model';
import { FormBuilder, FormGroup } from '@angular/forms';
import { RoomService } from '../room.service';
import { IFurniture } from '../../furniture/furniture.model';
import { FurnitureService } from '../../furniture/furniture.service';

@Component({
  selector: 'app-view-room',
  templateUrl: './view-room.component.html',
  styleUrls: ['./view-room.component.scss']
})
export class ViewRoomComponent implements OnInit {
  @Input() data?: IRoom;
  searchForm: FormGroup;
  listOfFurnitures: IFurniture[] = [];
  isLoading: boolean = false;
  total: number = 0;

  constructor(private readonly fb: FormBuilder, private readonly roomService: RoomService, private readonly furnitureService: FurnitureService) { }

  async ngOnInit() {
    this.searchForm = this.fb.group({
      floor: [1, []],
    });
    await this.getStatusRoomEachFloor(this.data.id);
  }

  getStatusRoomEachFloor(floor: number): Promise<void> {
    this.isLoading = true;
    return new Promise((resolve, reject) => {
        this.roomService.loadFurniture(this.data.id).subscribe({
            next: (res) => {
                this.listOfFurnitures = res.data;
                this.total = this.listOfFurnitures.length;
                this.listOfFurnitures.forEach(async (furniture) => {
                    furniture.images = [];
                    let imageObject = await this.getImageUrl(furniture.id);
                    for (let key in imageObject) {
                      if (imageObject.hasOwnProperty(key)) furniture.images.push(imageObject[key]);
                    }
                });
                this.isLoading = false;
                resolve();
            },
            error: (err) => {
                this.isLoading = false;
                reject(err);
            },
        });
    })
  }

  getImageUrl(furnitureId: number): Promise<Object> {
    return new Promise((resolve, reject) => {
      this.furnitureService.getFiles(furnitureId).subscribe({
        next: (res) => {
          resolve(res.data);
        },
        error: (err) => {
          reject(err);
        }
      });
    });
  }
}
