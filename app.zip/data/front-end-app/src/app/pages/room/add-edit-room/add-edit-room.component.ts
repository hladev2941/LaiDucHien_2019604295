import { Component, ElementRef, Input, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { IRoom, Room } from '../room.model';
import { NzModalRef } from 'ng-zorro-antd/modal';
import { RoomService } from '../room.service';
import { AlertService } from 'src/app/_utils/notification.service';
import { ISelect2, Select2 } from 'src/app/_utils/select2.model';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'app-add-edit-room',
  templateUrl: './add-edit-room.component.html',
  styleUrls: ['./add-edit-room.component.scss']
})
export class AddEditRoomComponent implements OnInit {

  addEditForm: FormGroup;
  isSearch: boolean = false;
  isLoading = false;
  @Input() data?: IRoom;

  @ViewChild("name") name: ElementRef;
  nameErrMsg: any;
  focusOnErrName() {
    this.name.nativeElement.focus();
  }

  @ViewChild("amountOfPeople") amountOfPeople: ElementRef;
  amountOfPeopleErrMsg: any;
  focusOnErrAmountOfPeople() {
    this.amountOfPeople.nativeElement.focus();
  }

  @ViewChild("floor") floor: ElementRef;
  floorErrMsg: any;
  focusOnErrFloor() {
    this.floor.nativeElement.focus();
  }

  @ViewChild("electricFee") electricFee: ElementRef;
  electricFeeErrMsg: any;
  focusOnErrElectricFee() {
    this.electricFee.nativeElement.focus();
  }

  @ViewChild("waterFee") waterFee: ElementRef;
  waterFeeErrMsg: any;
  focusOnErrWaterFee() {
    this.waterFee.nativeElement.focus();
  }

  @ViewChild("internetFee") internetFee: ElementRef;
  internetFeeErrMsg: any;
  focusOnErrInternetFee() {
    this.internetFee.nativeElement.focus();
  }

  @ViewChild("environmentFee") environmentFee: ElementRef;
  environmentFeeErrMsg: any;
  focusOnErrEnvironmentFee() {
    this.environmentFee.nativeElement.focus();
  }

  @ViewChild("building") building: ElementRef;
  buildingErrMsg: any;
  focusOnErrBuilding() {
    this.building.nativeElement.focus();
  }

  @ViewChild("rent") rent: ElementRef;
  rentErrMsg: any;
  focusOnErrRent() {
    this.rent.nativeElement.focus();
  }

  @ViewChild("parkingFee") parkingFee: ElementRef;
  parkingFeeErrMsg: any;
  focusOnErrParkingFee() {
    this.parkingFee.nativeElement.focus();
  }

  @ViewChild("area") area: ElementRef;
  areaErrMsg: any;
  focusOnErArea() {
    this.area.nativeElement.focus();
  }


  constructor(private fb: FormBuilder,
    private modal: NzModalRef,
    private roomService: RoomService,
    private notification: AlertService) { }

  ngOnInit(): void {
    this.addEditForm = this.fb.group({
      id: [null, []],
      name: [null, []],
      amountOfPeople: [null, []],
      floor: [null, []],
      area: [null, []],
      rent: [null, []],
      parkingFee: [null, []],
      electricFee: [null, []],
      waterFee: [null, []],
      internetFee: [null, []],
      environmentFee: [null, []],
      building: [null, []],
      description: [null, []],
      status: [true, []],
    });
    if (this.data) {
      this.onPatch(this.data);
      this.selectedValueBuilding = {
        ...new Select2(),
        id: this.data?.buildingId,
        name: this.data?.buildingName,
      };
    }
  }

  onPatch(patchData: IRoom): void {    
    this.addEditForm.patchValue({
      id: patchData.id,
      name: patchData.name,
      amountOfPeople: patchData.amountOfPeople,
      floor: patchData.floor,
      area: patchData.area,
      rent: patchData.rent,
      parkingFee: patchData.parkingFee,
      electricFee: patchData.electricFee,
      waterFee: patchData.waterFee,
      internetFee: patchData.internetFee,
      environmentFee: patchData.environmentFee,
      description: patchData.description,
      status: patchData.status == 0 ? true : false,
    });
  }

  getFromSearch(): Room {
    let { name, amountOfPeople, floor, rent, parkingFee, electricFee, waterFee, internetFee, environmentFee, status, building, description, area } = this.addEditForm.value;
    return {
      ...new Room(),
      id: this.data?.id,
      name: name,
      amountOfPeople: amountOfPeople,
      floor: floor,
      area: area,
      electricFee: electricFee,
      waterFee: waterFee,
      internetFee: internetFee,
      environmentFee: environmentFee,
      buildingId: building?.id,
      buildingName: building?.name,
      description: description,
      rent: rent,
      parkingFee: parkingFee,
      status: status ? 0 : 2
    };
  }

  handleOk(): void {
    if (this.validateCreate()) {
      this.isLoading = true;
      this.roomService.save(this.getFromSearch()).subscribe(
          (res) => {
            this.isLoading = false;
            this.notification.success("Thao tác thực hiện thành công!");
            this.modal.destroy();
          }, (error: HttpErrorResponse) => {
                this.notification.error(error.error.message);
          }
        );
    }
  }

  handleCancel(): void {
    this.modal.destroy();
  }

  validateCreate() {
    let isValid = true;
    if (!this.addEditForm.value.name || !this.addEditForm.value.name.trim()) {
      this.nameErrMsg = "Tên nội thất bắt buộc nhập";
      isValid = false;
      this.focusOnErrName();
    }
    if (!this.addEditForm.value.amountOfPeople) {
      this.amountOfPeopleErrMsg = "Giá trị của nội thất bắt buộc nhập";
      isValid = false;
      this.focusOnErrAmountOfPeople();
    }
    if (!this.addEditForm.value.floor) {
      this.floorErrMsg = "Giá trị của nội thất bắt buộc nhập";
      isValid = false;
      this.focusOnErrFloor();
    }
    if (!this.addEditForm.value.electricFee) {
      this.electricFeeErrMsg = "Bạn phải chọn thông tin phòng";
      isValid = false;
      this.focusOnErrElectricFee();
    }
    if (!this.addEditForm.value.waterFee) {
      this.waterFeeErrMsg = "Tên nội thất bắt buộc nhập";
      isValid = false;
      this.focusOnErrWaterFee();
    }
    if (!this.addEditForm.value.internetFee) {
      this.internetFeeErrMsg = "Giá trị của nội thất bắt buộc nhập";
      isValid = false;
      this.focusOnErrInternetFee();
    }
    if (!this.addEditForm.value.environmentFee) {
      this.environmentFeeErrMsg = "Giá trị của nội thất bắt buộc nhập";
      isValid = false;
      this.focusOnErrEnvironmentFee();
    }
    if (!this.addEditForm.value.rent) {
      this.rentErrMsg = "Tiền thuê phòng bắt buộc nhập";
      isValid = false;
      this.focusOnErrRent();
    }
    if (!this.addEditForm.value.parkingFee) {
      this.parkingFeeErrMsg = "Phì gửi xe bắt buộc nhập";
      isValid = false;
      this.focusOnErrParkingFee();
    }
    if (!this.addEditForm.value.area) {
      this.areaErrMsg = "Diện tích bắt buộc phải nhập";
      isValid = false;
      this.focusOnErArea();
    }
    if (!this.addEditForm.value.area) {
      this.buildingErrMsg = "Toà nhà bắt buộc nhập";
      isValid = false;
    }

    return isValid;
  }

  clearNameMessage() {
    this.nameErrMsg = "";
  }

  clearAmountOfPeopleMessage() {
    this.amountOfPeopleErrMsg = "";
  }

  clearFloorMessage() {
    this.floorErrMsg = "";
  }

  clearElectricFeeMessage() {
    this.electricFeeErrMsg = "";
  }

  clearWaterFeeMessage() {
    this.waterFeeErrMsg = "";
  }

  clearInternetFeeMessage() {
    this.internetFeeErrMsg = "";
  }

  clearEnvironmentFeeMessage() {
    this.environmentFeeErrMsg = "";
  }

  clearBuildingMessage() {
    this.buildingErrMsg = "";
  }

  clearRentMessage() {
    this.rentErrMsg = "";
  }

  clearAreaMessage() {
    this.areaErrMsg = "";
  }

  clearParkingFeeMessage() {
    this.parkingFeeErrMsg = "";
  }

  compareFn = (o1: any, o2: any) => (o1 && o2 ? o1.id === o2.id : o1 === o2);
  //SELECT2 Building
  totalBuilding: number = 1;
  pageBuilding = 1;
  buildings: ISelect2[] = [];
  selectedValueBuilding: ISelect2;

  loadMoreBuilding(key?: any): void {
    if (!this.isLoading && this.buildings.length <= this.totalBuilding) {
      this.isLoading = true;
      this.roomService
        .loadBuilding({
          ...new Select2(),
          key: key ?? '',
          page: this.pageBuilding,
          size: 10,
        })
        .subscribe((res) => {
          if (res != null && res.data) {
            this.buildings = this.buildings.concat(res.data);
            this.pageBuilding += 1;
            this.totalBuilding = res.total;
            this.isLoading = false;
          }
        });
    }
  }

  onSearchBuilding(key?: any): void {
    this.isSearch = true;
    this.pageBuilding = 1;
    this.buildings = [];
    this.loadMoreBuilding(key);
  }

}
