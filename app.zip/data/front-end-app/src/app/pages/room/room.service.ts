import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ResponseAPI } from 'src/app/_utils/response.model';
import { Constants } from '../../_utils/constants';
import { IRoom } from './room.model';

@Injectable({
  providedIn: 'root',
})
export class RoomService {
  private baseUrl = Constants.HOST + "/v1/room";
  constructor(private http: HttpClient) {}

  search(room: IRoom) {
    return this.http.post<ResponseAPI<IRoom[]>>(`${this.baseUrl}/search`, room);
  }

  save(room: IRoom){
    return this.http.post<ResponseAPI<any>>(`${this.baseUrl}/save`, room)
  }

  delete(room: IRoom){
    return this.http.post<ResponseAPI<any>>(`${this.baseUrl}/delete`, room)
  }
  
  loadBuilding(data: any) {
    return this.http.post<ResponseAPI<any>>(`${this.baseUrl}/load-building`, data);
  }

  loadFurniture(roomId: number) {
    return this.http.get<ResponseAPI<any>>(`${this.baseUrl}/load-furniture/${roomId}`);
  }
}
