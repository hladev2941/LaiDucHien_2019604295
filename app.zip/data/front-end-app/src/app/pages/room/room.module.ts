import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RoomRoutingModule } from './room-routing.module';
import { ListRoomComponent } from './list-room/list-room.component';
import { AddEditRoomComponent } from './add-edit-room/add-edit-room.component';
import { ModuleShare } from 'src/app/ng-zorro-antd.module';
import { ViewRoomComponent } from './view-room/view-room.component';


@NgModule({
  declarations: [
    ListRoomComponent,
    AddEditRoomComponent,
    ViewRoomComponent
  ],
  imports: [
    CommonModule,
    RoomRoutingModule,
    ModuleShare
  ]
})
export class RoomModule { }
