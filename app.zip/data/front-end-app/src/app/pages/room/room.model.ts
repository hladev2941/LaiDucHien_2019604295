export interface IRoom {
    id?: number;
    name?: string;
    status?: number;
    amountOfPeople?: number;
    floor?: number;
    area?: number;
    rent?: number;
    parkingFee?: number;
    electricFee?: number;
    waterFee?: number;
    internetFee?: number;
    environmentFee?: number;
    buildingId?: number;
    rentFrom?: number;
    rentTo?: number;
    buildingName?: string;
    description?: string;
    lastModifiedBy?: string;
    lastModifiedDate?: string;
    createdBy?: string;
    createdDate?: string;
    page?: number;
    size?: number;
  }
  
  export class Room implements IRoom {
    constructor(
      public id?: number,
      public name?: string,
      public status?: number,
      public amountOfPeople?: number,
      public floor?: number,
      public area?: number,
      public rent?: number,
      public parkingFee?: number,
      public electricFee?: number,
      public waterFee?: number,
      public internetFee?: number,
      public environmentFee?: number,
      public buildingId?: number,
      public rentFrom?: number,
      public rentTo?: number,
      public buildingName?: string,
      public description?: string,
      public lastModifiedBy?: string,
      public lastModifiedDate?: string,
      public createdBy?: string,
      public createdDate?: string,
      public page?: number,
      public size?: number
    ) {}
  }