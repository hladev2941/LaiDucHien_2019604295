import { Component, HostListener, OnInit, ViewContainerRef } from '@angular/core';
import { IRoom, Room } from '../room.model';
import { FormBuilder, FormGroup } from '@angular/forms';
import { NzModalService } from 'ng-zorro-antd/modal';
import { RoomService } from '../room.service';
import { AlertService } from 'src/app/_utils/notification.service';
import { AddEditRoomComponent } from '../add-edit-room/add-edit-room.component';
import { ViewRoomComponent } from '../view-room/view-room.component';
import { ISelect2, Select2 } from 'src/app/_utils/select2.model';

@Component({
  selector: 'app-list-room',
  templateUrl: './list-room.component.html',
  styleUrls: ['./list-room.component.scss']
})
export class ListRoomComponent implements OnInit {

  rooms: IRoom[];
  size = 10;
  page = 1;
  total: number = 0;
  searchForm: FormGroup;
  pageSizeOptions: number[] = [10, 20, 50, 100];

  constructor(
    private fb: FormBuilder,
    private nzModalService: NzModalService,
    private viewContainerRef: ViewContainerRef,
    private roomService: RoomService,
    private notification: AlertService,
  ) { }

  ngOnInit(): void {
    this.searchForm = this.fb.group({
      name: [null, []],
      status: [null, []],
      building: [null, []],
      rentFrom: [null, []],
      rentTo: [null, []],
    });

    this.search();
  }

  getFromSearch(): Room {
    let { name, status, building, rentFrom, rentTo } = this.searchForm.value;
    return {
      ...new Room(),
      name: name,
      status: status ? status : null,
      buildingId: building?.id,
      rentFrom: rentFrom,
      rentTo: rentTo,
      page: this.page,
      size: this.size,
    };
  }

  onSearch() {
    this.roomService.search(this.getFromSearch()).subscribe({
      next: (res) => {
        this.total = res.total;
        this.rooms = res.data;
      },
      error: (err) => console.log(err),
    });
  }

  search() {
    this.page = 1;
    this.size = 10;
    this.onSearch();
  }

  resetForm() {

  }

  showModal() {
    const modal = this.nzModalService.create({
      nzTitle: 'Thêm mới thông tin phòng',
      nzContent: AddEditRoomComponent,
      nzViewContainerRef: this.viewContainerRef,
      nzWidth: '1000px',
      nzComponentParams: {
      },
      nzOnCancel: () => this.handleCancel(modal),
    });
    modal.afterClose.subscribe(() => {
      this.onSearch();
    });
  }

  handleCancel(modal): Promise<void> {
    return new Promise((resolve, reject) => {
      const confirmModal = this.nzModalService.confirm({
        nzTitle: 'Thông báo xác nhận huỷ',
        nzContent: 'Bạn có chắc chắn muốn huỷ?',
        nzOnOk: () => {
          modal.close();
          confirmModal.close();
          resolve();
        },
        nzOnCancel: () => {
          reject();
        },
      });
    });
  }

  isLoading = false;

  showModalEdit(data: any) {
    const modal = this.nzModalService.create({
      nzTitle: 'Chỉnh sửa thông tin phòng',
      nzContent: AddEditRoomComponent,
      nzViewContainerRef: this.viewContainerRef,
      nzWidth: '1000px',
      nzComponentParams: {
        data: data
      },
      nzOnCancel: () => this.handleCancel(modal),
    });
    modal.afterClose.subscribe(() => {
      this.onSearch();
    });
  }

  showModalView(data: any) {
    const modal = this.nzModalService.create({
      nzTitle: 'Xem chi tiết thông tin phòng',
      nzContent: ViewRoomComponent,
      nzViewContainerRef: this.viewContainerRef,
      nzWidth: '1000px',
      nzComponentParams: {
        data: data,
      },
      nzFooter: null,
    });
  }

  onChangePage($event: number) {
    this.page = $event;
    this.onSearch();
  }

  onChangeSizePage($event: number) {
    this.size = $event;
    this.onSearch();
  }


  delete(data: any) {
    this.nzModalService.confirm({
      nzTitle: 'Thông báo xác nhận xóa',
      nzContent: 'Bạn có chắc chắn muốn xóa thông tin phòng này không?',
      nzOkText: 'Xác nhận',
      nzCancelText: 'Huỷ',
      nzOkDanger: true,
      nzIconType: 'delete',
      nzOnOk: () => {
        this.roomService.delete(data).subscribe((res) => {
          if (res.err_code == 0) {
            this.notification.success(
              'Thao tác thực hiện thành công!'
            );
          } else {
            this.notification.error(
              'Thao tác thực hiện không thành công!'
            );
          }
          this.search();
        });
      },
    });
  }

  //SELECT2 Building
  totalBuilding: number = 1;
  pageBuilding = 1;
  buildings: ISelect2[] = [];
  loadMoreBuilding(key?: any): void {
    if (!this.isLoading && this.buildings.length <= this.totalBuilding) {
      this.isLoading = true;
      this.roomService
        .loadBuilding({
          ...new Select2(),
          key: key ?? '',
          page: this.pageBuilding,
          size: 10,
        })
        .subscribe((res) => {
          if (res != null && res.data) {
            this.buildings = this.buildings.concat(res.data);
            this.pageBuilding += 1;
            this.totalBuilding = res.total;
            this.isLoading = false;
          }
        });
    }
  }
  isSearch: any
  onSearchBuilding(key?: any): void {
    this.isSearch = true;
    this.pageBuilding = 1;
    this.buildings = [];
    this.loadMoreBuilding(key);
  }

  @HostListener('document:keypress', ['$event'])
  keyEvent(event: KeyboardEvent) {
    if (event.keyCode === 13) {
      this.search();
    }
  }

}
