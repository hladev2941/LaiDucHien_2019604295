import { Component, ElementRef, Input, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { NzModalRef } from 'ng-zorro-antd/modal';
import { BookingService } from '../booking.service';
import { ContractService } from '../../contract-rent/contract.service';
import { AlertService } from 'src/app/_utils/notification.service';
import { Booking, IBooking } from '../booking.model';
import { ISelect2, Select2 } from 'src/app/_utils/select2.model';

@Component({
  selector: 'app-add-edit-booking',
  templateUrl: './add-edit-booking.component.html',
  styleUrls: ['./add-edit-booking.component.scss']
})
export class AddEditBookingComponent implements OnInit {
  @Input() data?: any;
  addEditForm: FormGroup;
  isSearch: boolean = false;
  isLoading = false;

  @ViewChild("building") building: ElementRef;
  buildingErrMsg: any;
  focusOnErrBuilding() {
    this.building.nativeElement?.focus();
  }
  @ViewChild("room") room: ElementRef;
  roomErrMsg: any;
  focusOnErrRoom() {
    this.room.nativeElement?.focus();
  }
  @ViewChild("afterDays") afterDays: ElementRef;
  afterDaysErrMsg: any;
  focusOnErrAfterDays() {
    this.afterDays.nativeElement?.focus();
  }
  @ViewChild("cusName") cusName: ElementRef;
  cusNameErrMsg: any;
  focusOnErrCusName() {
    this.cusName.nativeElement?.focus();
  }
  dateSetErrMsg: any;
  @ViewChild("rentalDeposit") rentalDeposit: ElementRef;
  rentalDepositErrMsg: any;
  focusOnErrRentalDeposit() {
    this.rentalDeposit.nativeElement?.focus();
  }

  constructor(private fb: FormBuilder,
    private modal: NzModalRef,
    private bookingService: BookingService,
    private contractService: ContractService,
    private notification: AlertService) { }

  ngOnInit(): void {
    this.addEditForm = this.fb.group({
      id: [null, []],
      building: [null, []],
      room: [null, []],
      cusName: [null, []],
      dateSet: [null, []],
      afterDays: [null, []],
      rentalDeposit: [null, []],
    });
    if (this.data) {
      this.onPatch(this.data);
      this.selectedValueBuilding = {
          ...new Select2(),
          id: this.data?.buildingId,
          name: this.data?.buildingName,
      };
      this.selectedValueRoom = {
          ...new Select2(),
          id: this.data?.roomId,
          name: this.data?.roomName,
      };
    }
  }

  onPatch(patchData: IBooking): void {
    this.addEditForm.patchValue({
        id: patchData.id,
        cusName: patchData.cusName,
        dateSet: patchData.dateSet,
        afterDays: patchData.afterDays,
        rentalDeposit: patchData.rentalDeposit
    });
  }

  getFromSearch(): Booking {
    let { room, building, cusName, dateSet, afterDays, rentalDeposit } = this.addEditForm.value;
    return {
      ...new Booking(),
      id: this.data?.id,
      roomId: room?.id,
      roomName: room?.name,
      buildingId: building?.id,
      buildingName: building?.name,
      cusName: cusName,
      dateSet: dateSet,
      afterDays: afterDays,
      rentalDeposit: rentalDeposit
    };
  }

  handleOk(): void {
    if (this.validateCreate()) {
      this.isLoading = true;
      this.bookingService.save(this.getFromSearch()).subscribe(
        {
          next: (res) => {
            this.isLoading = false;
            this.notification.success("Thao tác thực hiện thành công!");
            this.modal.destroy();
          }, error: (err) => {
            this.notification.error("Có lỗi xảy ra trong quá trình thực hiện!");
          }
        })
    }
  }

  handleCancel(): void {
    this.modal.destroy();
  }

  validateCreate() {
    let isValid = true;
    if (!this.addEditForm.value.building) {
      this.buildingErrMsg = "Bắt buộc phải chọn tòa nhà";
      isValid = false;
      this.focusOnErrBuilding();
    }
    if (!this.addEditForm.value.room) {
      this.roomErrMsg = "Bắt buộc phải chọn tòa nhà";
      isValid = false;
      this.focusOnErrRoom();
    }
    if (!this.addEditForm.value.afterDays) {
      this.afterDaysErrMsg = "Bắt buộc phải nhập thông tin này";
      isValid = false;
      this.focusOnErrAfterDays();
    }
    if (!this.addEditForm.value.rentalDeposit) {
      this.rentalDepositErrMsg = "Bắt buộc phải nhập số tiền cọc";
      isValid = false;
      this.focusOnErrRentalDeposit();
    }
    if (!this.addEditForm.value.dateSet) {
      this.dateSetErrMsg = "Bắt buộc phải nhập thông tin ngày cọc";
      isValid = false;
    }
    if (!this.addEditForm.value.cusName) {
      this.cusNameErrMsg = "Bắt buộc phải nhập tên người cọc";
      isValid = false;
      this.focusOnErrCusName();
    }

    return isValid;
  }
  clearBuildingMessage() {
    this.buildingErrMsg = "";
  }

  clearRoomMessage() {
    this.roomErrMsg = "";
  }

  clearDateSetMessage() {
    this.dateSetErrMsg = "";
  }

  clearRentalDepositMessage() {
    this.rentalDepositErrMsg = "";
  }

  clearAfterDaysMessage() {
    this.afterDaysErrMsg = "";
  }

  clearCusNameMessage() {
    this.cusNameErrMsg = "";
  }

  compareFn = (o1: any, o2: any) => (o1 && o2 ? o1.id === o2.id : o1 === o2);
  // SELECT2 Building
  totalBuilding: number = 1;
  pageBuilding = 1;
  buildings: ISelect2[] = [];
  selectedValueRoom: ISelect2;
  selectedValueBuilding: ISelect2;

  loadMoreBuilding(key?: any): void {
    if (this.buildings.length <= this.totalBuilding) {
      this.isLoading = true;
      this.bookingService
        .loadBuilding({
          ...new Select2(),
          key: key ?? '',
          page: this.pageBuilding,
          size: 10,
        })
        .subscribe((res) => {
          if (res != null && res.data) {
            this.buildings = this.buildings.concat(res.data);
            this.pageBuilding += 1;
            this.totalBuilding = res.total;
            this.isLoading = false;
          }
        });
    }
  }

  onSearchBuilding(key?: any): void {
    this.isSearch = true;
    this.pageBuilding = 1;
    this.buildings = [];
    this.loadMoreBuilding(key);
  }

  loadRoom() {
    this.addEditForm.get('room').setValue(null);
    this.onSearchRoom();
  }

  //SELECT2 Room
  totalRoom: number = 1;
  pageRoom = 1;
  rooms: ISelect2[] = [];

  loadMoreRoom(key?: any): void {
    if (this.rooms.length <= this.totalRoom) {
      this.isLoading = true;
      if (!this.addEditForm.value.building) {
        return;
      }
      this.bookingService
        .loadRoom({
          ...new Select2(),
          key: key ?? '',
          page: this.pageRoom,
          status: 0,
          size: 10,
        }, this.addEditForm.value.building?.id)
        .subscribe((res) => {
          if (res != null && res.data) {
            this.rooms = this.rooms.concat(res.data);

            this.pageRoom += 1;
            this.totalRoom = res.total;
            this.isLoading = false;
          }
        });
    }
  }

  onSearchRoom(key?: any): void {
    this.isSearch = true;
    this.totalRoom = 1;
    this.pageRoom = 1;
    this.rooms = [];
    this.loadMoreRoom(key);
  }
}
