import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { BookingRoutingModule } from './booking-routing.module';
import { ListBookingComponent } from './list-booking/list-booking.component';
import { AddEditBookingComponent } from './add-edit-booking/add-edit-booking.component';
import { ModuleShare } from 'src/app/ng-zorro-antd.module';
import { ViewBookingComponent } from './view-booking/view-booking.component';


@NgModule({
  declarations: [
    ListBookingComponent,
    AddEditBookingComponent,
    ViewBookingComponent
  ],
  imports: [
    CommonModule,
    BookingRoutingModule,
    ModuleShare
  ]
})
export class BookingModule { }
