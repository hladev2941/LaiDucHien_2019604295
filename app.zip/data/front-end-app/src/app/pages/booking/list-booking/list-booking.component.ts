import { Component, HostListener, OnInit, ViewContainerRef } from '@angular/core';
import { Booking, IBooking } from '../booking.model';
import { FormBuilder, FormGroup } from '@angular/forms';
import { NzModalService } from 'ng-zorro-antd/modal';
import { BookingService } from '../booking.service';
import { ContractService } from '../../contract-rent/contract.service';
import { AlertService } from 'src/app/_utils/notification.service';
import { AddEditBookingComponent } from '../add-edit-booking/add-edit-booking.component';
import { ISelect2, Select2 } from 'src/app/_utils/select2.model';
import { ViewBookingComponent } from '../view-booking/view-booking.component';

@Component({
  selector: 'app-list-booking',
  templateUrl: './list-booking.component.html',
  styleUrls: ['./list-booking.component.scss']
})
export class ListBookingComponent implements OnInit {
  bookings: IBooking[];
  size = 10;
  page = 1;
  total: number = 0;
  searchForm: FormGroup;
  pageSizeOptions: number[] = [10, 20, 50, 100];

  constructor(
    private fb: FormBuilder,
    private nzModalService: NzModalService,
    private viewContainerRef: ViewContainerRef,
    private bookingService: BookingService,
    private contractService: ContractService,
    private notification: AlertService,
  ) { }

  ngOnInit(): void {
    this.searchForm = this.fb.group({
      cusName: [null, []],
      room: [null, []],
      building: [null, []],
      fromDate: [null, []],
      toDate: [null, []],
      isDeleted: ["1", []],
      status: [null, []],
    });

    this.search();
  }

  getFromSearch(): Booking {
    let { cusName, room, building, fromDate, toDate, isDeleted, status } = this.searchForm.value;
    return {
      ...new Booking(),
      cusName: cusName,
      roomId: room?.id,
      buildingId: building?.id,
      fromDate: fromDate,
      toDate: toDate,
      isDeleted: isDeleted ? (isDeleted == '0' ? 0 : 1) : null,
      status: status ? (status == '0' ? 0 : 1) : null,
      page: this.page,
      size: this.size,
    };
  }

  onSearch() {
    this.bookingService.search(this.getFromSearch()).subscribe({
      next: (res) => {
        this.total = res.total;
        this.bookings = res.data;
      },
      error: (err) => console.log(err),
    });
  }

  search() {
    this.page = 1;
    this.size = 10;
    this.onSearch();
  }

  resetForm() {
    this.searchForm.reset();
    this.search();
  }

  showModal() {
    const modal = this.nzModalService.create({
      nzTitle: 'Thêm mới thông tin cọc phòng',
      nzContent: AddEditBookingComponent,
      nzViewContainerRef: this.viewContainerRef,
      nzWidth: '1000px',
      nzOnCancel: () => this.handleCancel(modal),
    });
    modal.afterClose.subscribe(() => {
      this.onSearch();
    });
  }

  handleCancel(modal): Promise<void> {
    return new Promise((resolve, reject) => {
      const confirmModal = this.nzModalService.confirm({
        nzTitle: 'Thông báo xác nhận huỷ',
        nzContent: 'Bạn có chắc chắn muốn huỷ?',
        nzOnOk: () => {
          modal.close();
          confirmModal.close();
          resolve();
        },
        nzOnCancel: () => {
          reject();
        },
      });
    });
  }

  isLoading = false;

  showModalEdit(data: any) {
    const modal = this.nzModalService.create({
      nzTitle: 'Chỉnh sửa thông tin cọc phòng',
      nzContent: AddEditBookingComponent,
      nzViewContainerRef: this.viewContainerRef,
      nzWidth: '1000px',
      nzComponentParams: {
        data: data
      },
      nzOnCancel: () => this.handleCancel(modal),
    });
    modal.afterClose.subscribe(() => {
      this.onSearch();
    });
  }

  showModalView(data: any) {
    const modal = this.nzModalService.create({
      nzTitle: 'Xem chi tiết thông tin cọc phòng',
      nzContent: ViewBookingComponent,
      nzViewContainerRef: this.viewContainerRef,
      nzWidth: '800px',
      nzComponentParams: {
        data: data
      },
      nzFooter: null,
    });
  }

  onChangePage($event: number) {
    this.page = $event;
    this.onSearch();
  }

  onChangeSizePage($event: number) {
    this.page = 1;
    this.size = $event;
    this.onSearch();
  }


  delete(data: any) {
    this.nzModalService.confirm({
      nzTitle: 'Thông báo xác nhận xóa',
      nzContent: 'Bạn có chắc chắn muốn xóa thông tin hóa đơn này không?',
      nzOkText: 'Xác nhận',
      nzCancelText: 'Huỷ',
      nzOkDanger: true,
      nzIconType: 'delete',
      nzOnOk: () => {
        this.bookingService.delete(data).subscribe((res) => {
          if (res.err_code == 0) {
            this.notification.success(
              'Thao tác thực hiện thành công!'
            );
          } else {
            this.notification.error(
              'Thao tác thực hiện không thành công!'
            );
          }
          this.search();
        });
      },
    });
  }

  // SELECT2 Building
  isSearch: boolean = false;
  totalBuilding: number = 1;
  pageBuilding = 1;
  buildings: ISelect2[] = [];

  loadMoreBuilding(key?: any): void {
    if (this.buildings.length <= this.totalBuilding) {
      this.isLoading = true;
      this.contractService
        .loadBuilding({
          ...new Select2(),
          key: key ?? '',
          page: this.pageBuilding,
          size: 10,
        })
        .subscribe((res) => {
          if (res != null && res.data) {
            this.buildings = this.buildings.concat(res.data);
            this.pageBuilding += 1;
            this.totalBuilding = res.total;
            this.isLoading = false;
          }
        });
    }
  }

  onSearchBuilding(key?: any): void {
    this.isSearch = true;
    this.pageBuilding = 1;
    this.buildings = [];
    this.loadMoreBuilding(key);
  }

  loadRoom() {
    this.searchForm.get('room').setValue(null);
    // this.onSearchRoom();
  }

  //SELECT2 Room
  totalRoom: number = 1;
  pageRoom = 1;
  rooms: ISelect2[] = [];
  selectedValueRoom: ISelect2;

  loadMoreRoom(key?: any): void {
    this.isLoading = true;
    if (!this.isLoading && this.rooms.length <= this.totalRoom) {
      if (!this.searchForm.value.building) {
        this.isLoading = false;
        return;
      }
      this.contractService
        .loadRoom({
          ...new Select2(),
          key: key ?? '',
          page: this.pageRoom,
          size: 10,
        }, this.searchForm.value.building?.id)
        .subscribe((res) => {
          if (res != null && res.data) {
            this.rooms = this.rooms.concat(res.data);
            this.pageRoom += 1;
            this.totalRoom = res.total;
            this.isLoading = false;
          }
        });
    }
  }

  onSearchRoom(key?: any): void {
    this.isSearch = true;
    this.pageRoom = 1;
    this.rooms = [];
    this.loadMoreRoom(key);
  }

  destroyBooking(data: any) {
    this.nzModalService.confirm({
      nzTitle: 'Thông báo xác nhận thanh toán',
      nzContent: 'Bạn có chắc chắn hủy cọc phòng này không?',
      nzOkText: 'Xác nhận',
      nzCancelText: 'Huỷ',
      nzOnOk: () => {
        this.isLoading = true;
        data.status = 1;
        this.bookingService.changeStatus({
          ...data
        }).subscribe(
          {
            next: (res) => {
              this.isLoading = false;
              this.notification.success("Thao tác thực hiện thành công!");
              this.search();
            }, error: (err) => {
              this.isLoading = false;
              this.notification.error("Có lỗi sảy ra trong quá trình thực hiện!");
            }
          })
      },
    });
  }

  @HostListener('document:keypress', ['$event'])
  keyEvent(event: KeyboardEvent) {
    if (event.keyCode === 13) {
      this.search();
    }
  }
}
