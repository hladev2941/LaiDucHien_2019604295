import { Component, Input, OnInit } from '@angular/core';
import { IBooking } from '../booking.model';
import { FormGroup } from '@angular/forms';

@Component({
  selector: 'app-view-booking',
  templateUrl: './view-booking.component.html',
  styleUrls: ['./view-booking.component.scss']
})
export class ViewBookingComponent implements OnInit {
  @Input() data?: IBooking;

  constructor() { }

  ngOnInit(): void {
  }
}
