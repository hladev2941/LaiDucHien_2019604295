import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ResponseAPI } from 'src/app/_utils/response.model';
import { Constants } from '../../_utils/constants';
import { IBooking } from './booking.model';

@Injectable({
  providedIn: 'root',
})
export class BookingService {
  private baseUrl = Constants.HOST + "/v1/booking";
  constructor(private http: HttpClient) {}

  search(booking: IBooking) {
    return this.http.post<ResponseAPI<IBooking[]>>(`${this.baseUrl}/search`, booking);
  }

  save(booking: IBooking){
    return this.http.post<ResponseAPI<any>>(`${this.baseUrl}/save`, booking)
  }

  delete(booking: IBooking){
    return this.http.post<ResponseAPI<any>>(`${this.baseUrl}/delete`, booking)
  }

  changeStatus(booking: IBooking){
    return this.http.post<ResponseAPI<any>>(`${this.baseUrl}/change-status`, booking)
  }
  
  loadBuilding(data: any) {
    return this.http.post<ResponseAPI<any>>(`${this.baseUrl}/load-building`, data);
  }

  loadRoom(data: any, buildingId: any) {
    return this.http.post<ResponseAPI<any>>(`${this.baseUrl}/load-room/`+buildingId, data);
  }
}
