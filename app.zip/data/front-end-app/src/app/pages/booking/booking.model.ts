export interface IBooking {
    id?: number;
    dateSet?: string;
    rentalDeposit?: number;
    buildingId?:number;
    buildingName?: string;
    roomId?: number;
    roomName?: string;
    cusName?: string;
    isDeleted?: number;
    fromDate?: string;
    toDate?: string;
    status?: number;
    afterDays?:number;
    lastModifiedBy? : string;
    lastModifiedDate? : string;
    createdBy? : string;
    createdDate? : string;
    page?: number;
    size?: number;
  }
  
  export class Booking implements IBooking {
    constructor(
        public id?: number,
        public dateSet?: string,
        public rentalDeposit?: number,
        public buildingId?:number,
        public buildingName?: string,
        public roomId?: number,
        public roomName?: string,
        public cusName?: string,
        public isDeleted?: number,
        public fromDate?: string,
        public toDate?: string,
        public status?: number,
        public afterDays?: number,
        public page?: number,
        public size?: number,
    ) {}
  }