import { AfterViewInit, Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import * as Highcharts from 'highcharts';
import { AlertService } from 'src/app/_utils/notification.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements AfterViewInit, OnInit {
  Highcharts: any = require('highcharts');
  ngAfterViewInit() {
    this.Highcharts.chart('container', {
      chart: {
        type: 'line'
      },
      title: {
        text: 'Monthly Sales Data'
      },
      xAxis: {
        categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
      },
      yAxis: {
        title: {
          text: 'Sales'
        }
      },
      series: [{
        name: '2023',
        data: [100, 150, 200, 250, 300, 350, 400, 450, 500, 550, 600, 650]
      }, {
        name: '2024',
        data: [150, 200, 250, 300, 350, 400, 450]
      }]
    });

    this.Highcharts.chart('test', {
      chart: {
        type: 'line'
      },
      title: {
        text: 'Monthly Sales Data'
      },
      xAxis: {
        categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
      },
      yAxis: {
        title: {
          text: 'Sales'
        }
      },
      series: [{
        name: '2023',
        data: [100, 150, 200, 250, 300, 350, 400, 450, 500, 550, 600, 650]
      }, {
        name: '2024',
        data: [150, 200, 250, 300, 350, 400, 450, 500, 550, 600, 650, 700]
      }]
    });

    this.Highcharts.chart('test-2', {
      chart: {
        type: 'pie'
      },
      title: {
        text: 'Browser market shares in January, 2024'
      },
      series: [{
        name: 'Brands',
        colorByPoint: true,
        data: [{
          name: 'Chrome',
          y: 61.41,
          sliced: true,
          selected: true
        }, {
          name: 'Internet Explorer',
          y: 11.84
        }, {
          name: 'Firefox',
          y: 10.85
        }, {
          name: 'Edge',
          y: 4.67
        }, {
          name: 'Safari',
          y: 4.18
        }, {
          name: 'Other',
          y: 7.05
        }]
      }]
    });

    this.Highcharts.chart('test-3', {
      chart: {
        type: 'column'
      },
      title: {
        text: 'Monthly Sales Data'
      },
      xAxis: {
        categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
      },
      yAxis: {
        title: {
          text: 'Sales'
        }
      },
      series: [{
        name: '2023',
        data: [100, 150, 200, 250, 300, 350, 400, 450, 500, 550, 600, 650]
      }, {
        name: '2024',
        data: [150, 200, 250, 300, 350, 400, 450, 500, 550, 600, 650, 700]
      }]
    });
  }

  searchForm: FormGroup;

  constructor(
    private fb: FormBuilder,
    private notification: AlertService,
  ) { }

  ngOnInit(): void {
    this.searchForm = this.fb.group({
      name: [null, []],
      status: [null, []],
      building: [null, []],
      year: [null, []],
    });

    this.search();
  }

  search(){

  }
}

