import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ListBillComponent } from './list-bill/list-bill.component';

const routes: Routes = [
  {
    path:'',
    component:ListBillComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class BillRoutingModule { }
