import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { BillRoutingModule } from './bill-routing.module';
import { ListBillComponent } from './list-bill/list-bill.component';
import { AddBillComponent } from './add-bill/add-bill.component';
import { EditBillComponent } from './edit-bill/edit-bill.component';
import { ModuleShare } from 'src/app/ng-zorro-antd.module';
import { ViewBillComponent } from './view-bill/view-bill.component';


@NgModule({
  declarations: [
    ListBillComponent,
    AddBillComponent,
    EditBillComponent,
    ViewBillComponent
  ],
  imports: [
    CommonModule,
    BillRoutingModule,
    ModuleShare
  ]
})
export class BillModule { }
