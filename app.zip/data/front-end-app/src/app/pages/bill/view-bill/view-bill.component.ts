import { Component, Input, OnInit } from '@angular/core';
import { IBill } from '../bill.model';

@Component({
  selector: 'app-view-bill',
  templateUrl: './view-bill.component.html',
  styleUrls: ['./view-bill.component.scss'],
})
export class ViewBillComponent implements OnInit {
  @Input() data?: IBill;
  bills: any[];
  pageSizeOptions: number[] = [10, 20, 50, 100];
  total: number = 0;

  constructor() {}

  ngOnInit(): void {
    // this.bills = this.data.;
    this.bills = this.data ? [
      {
        serviceName: 'Tiền điện',
        consumption: this.data.amountOfElectricity,
        unitPrice: (this.data.electricityBill / this.data.amountOfElectricity) + " VNĐ",
        total: this.data?.electricityBill + " VNĐ",
      },
      {
        serviceName: 'Tiền nước',
        consumption: this.data?.amountOfWater,
        unitPrice: (this.data?.waterBill / this.data?.amountOfWater) + " VNĐ",
        total: this.data?.waterBill + " VNĐ",
      },
      {
        serviceName: 'Phí đỗ xe',
        consumption: this.data?.parkingFee ? 1: null,
        unitPrice: this.data?.parkingFee ? this.data?.parkingFee + " VNĐ" : null,
        total: this.data?.parkingFee ? this.data?.parkingFee + " VNĐ" : null,
      },
      {
        serviceName: 'Phí dịch vụ',
        consumption: this.data?.servicesBill ? 1 : null,
        unitPrice: this.data?.servicesBill ? this.data?.servicesBill + " VNĐ" : null,
        total: this.data?.servicesBill ? this.data?.servicesBill + " VNĐ" : null,
      },
      {
        serviceName: 'Tiền mạng',
        consumption: this.data?.internetFee ? 1 : null,
        unitPrice: this.data?.internetFee ? this.data?.internetFee + " VNĐ" : null,
        total: this.data?.internetFee ? this.data?.internetFee + " VNĐ" : null,
      },
    ] : [];

    // Flatten the array
    this.bills = [].concat(...this.bills);
    console.log(this.bills);
  }
}
