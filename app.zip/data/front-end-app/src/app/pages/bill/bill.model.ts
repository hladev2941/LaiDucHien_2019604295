export interface IBill {
    id?: number;
    month?: number;
    year?: number;
    amountOfElectricity?: number;
    amountOfWater?: number;
    payDate?: string;
    electricityBill?: number;
    waterBill?: number;
    totalBill?: number;
    servicesBill?: number;
    internetFee?: number;
    environmentFee?: number;
    parkingFee?:number;
    buildingId?:number;
    buildingName?: string;
    roomId?: number;
    roomName?: string;
    isDeleted?: number;
    fromDate?: string;
    toDate?: string;
    status?: number;
    lastModifiedBy?: string;
    lastModifiedDate?: string;
    createdBy?: string;
    createdDate?: string;
    page?: number;
    size?: number;
  }
  
  export class Bill implements IBill {
    constructor(
        public id?: number,
        public month?: number,
        public year?: number,
        public amountOfElectricity?: number,
        public amountOfWater?: number,
        public payDate?: string,
        public electricityBill?: number,
        public waterBill?: number,
        public totalBill?: number,
        public servicesBill?: number,
        public internetFee?: number,
        public environmentFee?: number,
        public parkingFee?:number,
        public buildingId?:number,
        public buildingName?: string,
        public roomId?: number,
        public roomName?: string,
        public isDeleted?: number,
        public fromDate?: string,
        public toDate?: string,
        public status?: number,
        public lastModifiedBy?: string,
        public lastModifiedDate?: string,
        public createdBy?: string,
        public createdDate?: string,
        public page?: number,
        public size?: number
    ) {}
  }