import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ResponseAPI } from 'src/app/_utils/response.model';
import { Constants } from '../../_utils/constants';
import { IBill } from './bill.model';

@Injectable({
  providedIn: 'root',
})
export class BillService {
  private baseUrl = Constants.HOST + "/v1/bill";
  constructor(private http: HttpClient) {}

  search(Bill: IBill) {
    return this.http.post<ResponseAPI<IBill[]>>(`${this.baseUrl}/search`, Bill);
  }

  save(Bill: IBill){
    return this.http.post<ResponseAPI<any>>(`${this.baseUrl}/save`, Bill)
  }

  delete(Bill: IBill){
    return this.http.post<ResponseAPI<any>>(`${this.baseUrl}/delete`, Bill)
  }

  loadBuilding(data: any) {
    return this.http.post<ResponseAPI<any>>(`${this.baseUrl}/load-building`, data);
  }

  loadRoom(data: any, buildingId: any) {
    return this.http.post<ResponseAPI<any>>(`${this.baseUrl}/load-room/`+ buildingId, data);
  }
}
