import { Component, ElementRef, Input, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ISelect2, Select2 } from 'src/app/_utils/select2.model';
import { BillService } from '../bill.service';
import { NzModalRef } from 'ng-zorro-antd/modal';
import { AlertService } from 'src/app/_utils/notification.service';
import { ContractService } from '../../contract-rent/contract.service';
import { Bill } from '../bill.model';

@Component({
  selector: 'app-add-bill',
  templateUrl: './add-bill.component.html',
  styleUrls: ['./add-bill.component.scss']
})
export class AddBillComponent implements OnInit {

  addEditForm: FormGroup;
  isSearch: boolean = false;
  isLoading = false;

  @ViewChild("building") building: ElementRef;
  buildingErrMsg: any;
  focusOnErrBuilding() {
    this.building.nativeElement.focus();
  }
  @ViewChild("room") room: ElementRef;
  roomErrMsg: any;
  focusOnErrRoom() {
    this.room.nativeElement.focus();
  }
  @ViewChild("month") month: ElementRef;
  monthErrMsg: any;
  focusOnErrMonth() {
    this.month.nativeElement.focus();
  }
  @ViewChild("year") year: ElementRef;
  yearErrMsg: any;
  focusOnErrYear() {
    this.year.nativeElement.focus();
  }
  @ViewChild("amountOfElectricity") amountOfElectricity: ElementRef;
  amountOfElectricityErrMsg: any;
  focusOnErrAmountOfElectricity() {
    this.amountOfElectricity.nativeElement.focus();
  }

  @ViewChild("amountOfWater") amountOfWater: ElementRef;
  amountOfWaterErrMsg: any;
  focusOnErrAmountOfWater() {
    this.amountOfWater.nativeElement.focus();
  }

  constructor(private fb: FormBuilder,
    private modal: NzModalRef,
    private billService: BillService,
    private notification: AlertService) { }

  ngOnInit(): void {
    this.addEditForm = this.fb.group({
      building: [null, []],
      room: [null, []],
      month: [null, []],
      year: [null, []],
      amountOfElectricity: [null, []],
      amountOfWater: [null, []],
    });
  }

  getFromSearch(): Bill {
    let { room, building, month, year, amountOfElectricity, amountOfWater } = this.addEditForm.value;
    return {
      ...new Bill(),
      roomId: room?.id,
      roomName: room?.name,
      buildingId: building?.id,
      buildingName: building?.name,
      month: month,
      year: year,
      amountOfElectricity: amountOfElectricity,
      amountOfWater: amountOfWater,
    };
  }

  handleOk(): void {
    if (this.validateCreate()) {
      this.isLoading = true;
      this.billService.save(this.getFromSearch()).subscribe(
        {
          next: (res) => {
            this.isLoading = false;
            this.notification.success("Thao tác thực hiện thành công!");
            this.modal.destroy();
          }, error: (err) => {
            this.notification.error("Có lỗi xảy ra trong quá trình thực hiện!");
          }
        })
    }
  }

  handleCancel(): void {
    this.modal.destroy();
  }

  validateCreate() {
    let isValid = true;
    if (!this.addEditForm.value.building) {
      this.buildingErrMsg = "Bắt buộc phải chọn tòa nhà";
      isValid = false;
      this.focusOnErrBuilding();
    }
    if (!this.addEditForm.value.room) {
      this.roomErrMsg = "Bắt buộc phải chọn tòa nhà";
      isValid = false;
      this.focusOnErrRoom();
    }
    if (!this.addEditForm.value.month) {
      this.monthErrMsg = "Bắt buộc phải nhập thông tin tháng";
      isValid = false;
      this.focusOnErrMonth();
    }
    if (!this.addEditForm.value.year) {
      this.yearErrMsg = "Bắt buộc phải nhập thông tin năm";
      isValid = false;
      this.focusOnErrYear();
    }
    if (!this.addEditForm.value.amountOfWater) {
      this.amountOfWaterErrMsg = "Bắt buộc phải nhập thông tin chỉ số nước sử dụng";
      isValid = false;
      this.focusOnErrAmountOfWater();
    }
    if (!this.addEditForm.value.amountOfElectricity) {
      this.amountOfElectricityErrMsg = "Bắt buộc phải nhập thông tin chỉ số tiêu thụ điện";
      isValid = false;
      this.focusOnErrAmountOfElectricity();
    }

    return isValid;
  }
  clearBuildingMessage() {
    this.buildingErrMsg = "";
  }

  clearRoomMessage() {
    this.roomErrMsg = "";
  }

  clearMonthMessage() {
    this.monthErrMsg = "";
  }

  clearYearMessage() {
    this.yearErrMsg = "";
  }

  clearAmountOfElectricityMessage() {
    this.amountOfElectricityErrMsg = "";
  }

  clearAmountOfWaterMessage() {
    this.amountOfWaterErrMsg = "";
  }

  compareFn = (o1: any, o2: any) => (o1 && o2 ? o1.id === o2.id : o1 === o2);
  // SELECT2 Building
  totalBuilding: number = 1;
  pageBuilding = 1;
  buildings: ISelect2[] = [];

  loadMoreBuilding(key?: any): void {
    if (this.buildings.length <= this.totalBuilding) {
      this.isLoading = true;
      this.billService
        .loadBuilding({
          ...new Select2(),
          key: key ?? '',
          page: this.pageBuilding,
          size: 10,
        })
        .subscribe((res) => {
          if (res != null && res.data) {
            this.buildings = this.buildings.concat(res.data);
            this.pageBuilding += 1;
            this.totalBuilding = res.total;
            this.isLoading = false;
          }
        });
    }
  }

  onSearchBuilding(key?: any): void {
    this.isSearch = true;
    this.pageBuilding = 1;
    this.buildings = [];
    this.loadMoreBuilding(key);
  }

  loadRoom() {
    this.addEditForm.get('room').setValue(null);
    this.onSearchRoom();
  }

  //SELECT2 Room
  totalRoom: number = 1;
  pageRoom = 1;
  rooms: ISelect2[] = [];

  loadMoreRoom(key?: any): void {
    if (this.rooms.length <= this.totalRoom) {
      this.isLoading = true;
      if (!this.addEditForm.value.building) {
        return;
      }
      this.billService
        .loadRoom({
          ...new Select2(),
          key: key ?? '',
          page: this.pageRoom,
          size: 10,
        }, this.addEditForm.value.building?.id)
        .subscribe((res) => {
          if (res != null && res.data) {
            this.rooms = this.rooms.concat(res.data);

            this.pageRoom += 1;
            this.totalRoom = res.total;
            this.isLoading = false;
          }
        });
    }
  }

  onSearchRoom(key?: any): void {
    this.isSearch = true;
    this.totalRoom = 1;
    this.pageRoom = 1;
    this.rooms = [];
    this.loadMoreRoom(key);
  }
}
