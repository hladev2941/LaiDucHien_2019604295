import { ChangeDetectorRef, Component, HostListener, OnInit, ViewContainerRef } from '@angular/core';
import { AddBillComponent } from '../add-bill/add-bill.component';
import { EditBillComponent } from '../edit-bill/edit-bill.component';
import { Bill, IBill } from '../bill.model';
import { FormBuilder, FormGroup } from '@angular/forms';
import { NzModalService } from 'ng-zorro-antd/modal';
import { AlertService } from 'src/app/_utils/notification.service';
import { BillService } from '../bill.service';
import { ISelect2, Select2 } from 'src/app/_utils/select2.model';
import { ContractService } from '../../contract-rent/contract.service';
import { ViewBillComponent } from '../view-bill/view-bill.component';

@Component({
  selector: 'app-list-bill',
  templateUrl: './list-bill.component.html',
  styleUrls: ['./list-bill.component.scss']
})
export class ListBillComponent implements OnInit {

  bills: IBill[];
  size = 10;
  page = 1;
  total: number = 0;
  searchForm: FormGroup;
  pageSizeOptions: number[] = [10, 20, 50, 100];

  constructor(
    private fb: FormBuilder,
    private nzModalService: NzModalService,
    private viewContainerRef: ViewContainerRef,
    private billService: BillService,
    private contractService: ContractService,
    private notification: AlertService,
    private ref: ChangeDetectorRef,
  ) { }

  ngOnInit(): void {
    this.searchForm = this.fb.group({
      room: [null, []],
      building: [null, []],
      fromDate: [null, []],
      toDate: [null, []],
      isDeleted: ["1", []],
      status: [null, []],
    });

    this.search();
  }

  getFromSearch(): Bill {
    let { room, building, fromDate, toDate, isDeleted, status } = this.searchForm.value;
    return {
      ...new Bill(),
      roomId: room?.id,
      buildingId: building?.id,
      fromDate: fromDate,
      toDate: toDate,
      isDeleted: isDeleted,
      status: status ? (status == '0' ? 0 : 1) : null,
      page: this.page,
      size: this.size,
    };
  }

  onSearch() {
    this.billService.search(this.getFromSearch()).subscribe({
      next: (res) => {
        this.total = res.total;
        this.bills = res.data;
      },
      error: (err) => console.log(err),
    });
  }

  search() {
    this.page = 1;
    this.size = 10;
    this.onSearch();
  }

  resetForm() {

  }

  showModal() {
    const modal = this.nzModalService.create({
      nzTitle: 'Thêm mới thông tin hóa đơn',
      nzContent: AddBillComponent,
      nzViewContainerRef: this.viewContainerRef,
      nzWidth: '1000px',
      nzComponentParams: {
      },
      nzOnCancel: () => this.handleCancel(modal),
    });
    modal.afterClose.subscribe(() => {
      this.onSearch();
    });
  }

  handleCancel(modal): Promise<void> {
    return new Promise((resolve, reject) => {
      const confirmModal = this.nzModalService.confirm({
        nzTitle: 'Thông báo xác nhận huỷ',
        nzContent: 'Bạn có chắc chắn muốn huỷ?',
        nzOnOk: () => {
          modal.close();
          confirmModal.close();
          resolve();
        },
        nzOnCancel: () => {
          reject();
        },
      });
    });
  }

  isLoading = false;

  showModalEdit(id: any) {
    const modal = this.nzModalService.create({
      nzTitle: 'Chỉnh sửa thông tin hóa đơn',
      nzContent: EditBillComponent,
      nzViewContainerRef: this.viewContainerRef,
      nzWidth: '1000px',
      nzComponentParams: {
        id: id
      },
      nzOnCancel: () =>  this.handleCancel(modal),
    });
    modal.afterClose.subscribe(() => {
      this.onSearch();
    });
  }

  showModalView(data: IBill) {
    const modal = this.nzModalService.create({
      nzTitle: 'Chỉnh sửa thông tin hóa đơn',
      nzContent: ViewBillComponent,
      nzViewContainerRef: this.viewContainerRef,
      nzWidth: '1000px',
      nzComponentParams: {
        data: data
      },
      nzFooter: null
    });
  }

  onChangePage($event: number) {
    this.page = $event;
    this.onSearch();
  }

  onChangeSizePage($event: number) {
    this.page = 1;
    this.size = $event;
    this.onSearch();
  }


  delete(data: any) {
    this.nzModalService.confirm({
      nzTitle: 'Thông báo xác nhận xóa',
      nzContent: 'Bạn có chắc chắn muốn xóa thông tin hóa đơn này không?',
      nzOkText: 'Xác nhận',
      nzCancelText: 'Huỷ',
      nzOkDanger: true,
      nzIconType: 'delete',
      nzOnOk: () => {
        this.billService.delete(data).subscribe((res) => {
          if (res.err_code == 0) {
            this.notification.success(
              'Thao tác thực hiện thành công!'
            );
          } else {
            this.notification.error(
              'Thao tác thực hiện không thành công!'
            );
          }
          this.search();
        });
      },
    });
  }

  // SELECT2 Building
  isSearch: boolean = false;
  totalBuilding: number = 1;
  pageBuilding = 1;
  buildings: ISelect2[] = [];

  loadMoreBuilding(key?: any): void {
    if (this.buildings.length <= this.totalBuilding) {
      this.isLoading = true;
      this.contractService
        .loadBuilding({
          ...new Select2(),
          key: key ?? '',
          page: this.pageBuilding,
          size: 10,
        })
        .subscribe((res) => {
          if (res != null && res.data) {
            this.buildings = this.buildings.concat(res.data);
            this.pageBuilding += 1;
            this.totalBuilding = res.total;
            this.isLoading = false;
          }
        });
    }
  }

  onSearchBuilding(key?: any): void {
    this.isSearch = true;
    this.pageBuilding = 1;
    this.buildings = [];
    this.loadMoreBuilding(key);
  }

  loadRoom() {
    this.searchForm.get('room').setValue(null);
    this.onSearchRoom();
  }

  //SELECT2 Room
  totalRoom: number = 1;
  pageRoom = 1;
  rooms: ISelect2[] = [];
  selectedValueRoom: ISelect2;

  loadMoreRoom(key?: any): void {
    if (this.rooms.length <= this.totalRoom) {
      this.isLoading = true;
      if (!this.searchForm.value.building) {
        return;
      }
      this.contractService
        .loadRoom({
          ...new Select2(),
          key: key ?? '',
          page: this.pageRoom,
          size: 10,
        }, this.searchForm.value.building?.id)
        .subscribe((res) => {
          if (res != null && res.data) {
            this.rooms = this.rooms.concat(res.data);

            this.pageRoom += 1;
            this.totalRoom = res.total;
            this.isLoading = false;
          }
        });
    }
  }

  onSearchRoom(key?: any): void {
    this.isSearch = true;
    this.totalRoom = 1;
    this.pageRoom = 1;
    this.rooms = [];
    this.loadMoreRoom(key);
  }

  payment(id: any) {
    this.nzModalService.confirm({
      nzTitle: 'Thông báo xác nhận thanh toán',
      nzContent: 'Bạn có chắc chắn phòng này đã thanh toán không?',
      nzOkText: 'Xác nhận',
      nzCancelText: 'Huỷ',
      nzOnOk: () => {
        this.isLoading = true;
        this.billService.save({
          id: id,
          status: 1
        }).subscribe(
          {
            next: (res) => {
              this.isLoading = false;
              this.notification.success("Thao tác thực hiện thành công!");
            }, error: (err) => {
              this.isLoading = false;
              this.notification.error("Có lỗi sảy ra trong quá trình thực hiện!");
            }
          })
        this.search();
      },
    });
  }

  @HostListener('document:keypress', ['$event'])
  keyEvent(event: KeyboardEvent) {
    if (event.keyCode === 13) {
      this.search();
    }
  }
}
