import { Component, ElementRef, Input, OnInit, ViewChild } from '@angular/core';
import { AlertService } from 'src/app/_utils/notification.service';
import { BillService } from '../bill.service';
import { NzModalRef } from 'ng-zorro-antd/modal';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Bill } from '../bill.model';

@Component({
  selector: 'app-edit-bill',
  templateUrl: './edit-bill.component.html',
  styleUrls: ['./edit-bill.component.scss']
})
export class EditBillComponent implements OnInit {

  @Input() id?: any;

  addEditForm: FormGroup;
  isSearch: boolean = false;
  isLoading = false;

  @ViewChild("amountOfElectricity") amountOfElectricity: ElementRef;
  amountOfElectricityErrMsg: any;
  focusOnErrAmountOfElectricity() {
    this.amountOfElectricity.nativeElement.focus();
  }

  @ViewChild("amountOfWater") amountOfWater: ElementRef;
  amountOfWaterErrMsg: any;
  focusOnErrAmountOfWater() {
    this.amountOfWater.nativeElement.focus();
  }

  constructor(private fb: FormBuilder,
    private modal: NzModalRef,
    private billService: BillService,
    private notification: AlertService) { }

  ngOnInit(): void {
    this.addEditForm = this.fb.group({
      amountOfElectricity: [null, []],
      amountOfWater: [null, []],
    });
  }

  getFromSearch(): Bill {
    let {amountOfElectricity, amountOfWater } = this.addEditForm.value;
    return {
      ...new Bill(),
      id: this.id,
      amountOfElectricity: amountOfElectricity,
      amountOfWater: amountOfWater,
    };
  }

  handleOk(): void {
    if (this.validateCreate()) {
      this.isLoading = true;
      this.billService.save(this.getFromSearch()).subscribe(
        {
          next: (res) => {
            this.isLoading = false;
            this.notification.success("Thao tác thực hiện thành công!");
            this.modal.destroy();
          }, error: (err) => {
            this.notification.error("Có lỗi xảy ra trong quá trình thực hiện!");
          }
        })
    }
  }

  handleCancel(): void {
    this.modal.destroy();
  }

  validateCreate() {
    let isValid = true;
    if (!this.addEditForm.value.amountOfWater) {
      this.amountOfWaterErrMsg = "Bắt buộc phải nhập thông tin chỉ số nước sử dụng";
      isValid = false;
      this.focusOnErrAmountOfWater();
    }
    if (!this.addEditForm.value.amountOfElectricity) {
      this.amountOfElectricityErrMsg = "Bắt buộc phải nhập thông tin chỉ số tiêu thụ điện";
      isValid = false;
      this.focusOnErrAmountOfElectricity();
    }

    return isValid;
  }

  clearAmountOfElectricityMessage() {
    this.amountOfElectricityErrMsg = "";
  }

  clearAmountOfWaterMessage() {
    this.amountOfWaterErrMsg = "";
  }

}
