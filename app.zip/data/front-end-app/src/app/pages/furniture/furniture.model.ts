export interface IFurniture {
    id?: number;
    name?: string;
    status?: number;
    image?: string;
    price?: number;
    roomId?: number;
    roomName?: string;
    buildingId?: number;
    buildingName?: string;
    description?: string;
    lastModifiedBy?: string;
    lastModifiedDate?: string;
    createdBy?: string;
    createdDate?: string;
    page?: number;
    size?: number;
    images?: string[];
  }
  
  export class Furniture implements IFurniture {
    constructor(
      public id?: number,
      public name?: string,
      public status?: number,
      public image?: string,
      public price?: number,
      public roomId?: number,
      public roomName?: string,
      public buildingId?: number,
      public buildingName?: string,
      public description?: string,
      public lastModifiedBy?: string,
      public lastModifiedDate?: string,
      public createdBy?: string,
      public createdDate?: string,
      public page?: number,
      public size?: number,
      public images?: string[],
    ) {}
  }