import { Component, HostListener, OnInit, ViewContainerRef } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { NzModalService } from 'ng-zorro-antd/modal';
import { AlertService } from 'src/app/_utils/notification.service';
import { AddEditFurnitureComponent } from '../add-edit-furniture/add-edit-furniture.component';
import { FurnitureService } from '../furniture.service';
import { Furniture, IFurniture } from '../furniture.model';
import { AssignFurnitureComponent } from '../assign-furniture/assign-furniture.component';

@Component({
  selector: 'app-list-furniture',
  templateUrl: './list-furniture.component.html',
  styleUrls: ['./list-furniture.component.scss']
})
export class ListFurnitureComponent implements OnInit {

  furnitures: IFurniture[];
  size = 10;
  page = 1;
  total: number = 0;
  searchForm: FormGroup;
  pageSizeOptions: number[] = [10, 20, 50, 100];

  constructor(
    private fb: FormBuilder,
    private nzModalService: NzModalService,
    private viewContainerRef: ViewContainerRef,
    private furnitureService: FurnitureService,
    private notification: AlertService,
  ) { }

  ngOnInit(): void {
    this.searchForm = this.fb.group({
      name: [null, []],
      status: [null, []],
    });

    this.search();
  }

  getFromSearch(): Furniture {
    let { name, status } = this.searchForm.value;
    return {
      ...new Furniture(),
      name: name,
      status: status ? (status == '0' ? 0 : 1) : null,
      page: this.page,
      size: this.size,
    };
  }

  onSearch() {
    this.furnitureService.search(this.getFromSearch()).subscribe({
      next: (res) => {
        this.total = res.total;
        this.furnitures = res.data;
      },
      error: (err) => console.log(err),
    });
  }

  search() {
    this.page = 1;
    this.size = 10;
    this.onSearch();
  }

  resetForm() {

  }

  showModal() {
    const modal = this.nzModalService.create({
      nzTitle: 'Thêm mới thông tin nội thất',
      nzContent: AddEditFurnitureComponent,
      nzViewContainerRef: this.viewContainerRef,
      nzWidth: '1000px',
      nzComponentParams: {
      },
      nzOnCancel: () => this.handleCancel(modal),
    });
    modal.afterClose.subscribe(() => {
      this.onSearch();
    });
  }

  handleCancel(modal): Promise<void> {
    return new Promise((resolve, reject) => {
      const confirmModal = this.nzModalService.confirm({
        nzTitle: 'Thông báo xác nhận huỷ',
        nzContent: 'Bạn có chắc chắn muốn huỷ?',
        nzOnOk: () => {
          modal.close();
          confirmModal.close();
          resolve();
        },
        nzOnCancel: () => {
          reject();
        },
      });
    });
  }

  isLoading = false;

  showModalEdit(data: any) {
    const modal = this.nzModalService.create({
      nzTitle: 'Chỉnh sửa thông tin nội thất',
      nzContent: AddEditFurnitureComponent,
      nzViewContainerRef: this.viewContainerRef,
      nzWidth: '1000px',
      nzComponentParams: {
        data: data
      },
      nzOnCancel: () => this.handleCancel(modal),
    });
    modal.afterClose.subscribe(() => {
      this.onSearch();
    });
  }

  showModalView(data: any) {
    const modal = this.nzModalService.create({
      nzTitle: 'Xem chi tiết thông tin nội thất',
      nzContent: AddEditFurnitureComponent,
      nzViewContainerRef: this.viewContainerRef,
      nzWidth: '1000px',
      nzComponentParams: {
        data: data,
        view: true
      },
      nzOnCancel: () => this.handleCancel(modal),
    });
  }

  showModalAssignFurniture(data: any) {
    const modal = this.nzModalService.create({
      nzTitle: 'Quản lý thông tin sử dụng nội thất',
      nzContent: AssignFurnitureComponent,
      nzViewContainerRef: this.viewContainerRef,
      nzWidth: '1000px',
      nzComponentParams: {
        data: data
      },
      nzOnCancel: () => this.handleCancel(modal),
    });
    modal.afterClose.subscribe(() => {
      this.onSearch();
    });
  }

  onChangePage($event: number) {
    this.page = $event;
    this.onSearch();
  }

  onChangeSizePage($event: number) {
    this.page = 1;
    this.size = $event;
    this.onSearch();
  }


  delete(data: any) {
    this.nzModalService.confirm({
      nzTitle: 'Thông báo xác nhận xóa',
      nzContent: 'Bạn có chắc chắn muốn xóa thông tin nội thất này không?',
      nzOkText: 'Xác nhận',
      nzCancelText: 'Huỷ',
      nzOkDanger: true,
      nzIconType: 'delete',
      nzOnOk: () => {
        this.furnitureService.delete(data).subscribe((res) => {
          if (res.err_code == 0) {
            this.notification.success(
              'Thao tác thực hiện thành công!'
            );
          } else {
            this.notification.error(
              'Thao tác thực hiện không thành công!'
            );
          }
          this.search();
        });
      },
    });
  }

  @HostListener('document:keypress', ['$event'])
  keyEvent(event: KeyboardEvent) {
    if (event.keyCode === 13) {
      this.search();
    }
  }

}
