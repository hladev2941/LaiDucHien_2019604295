import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ListFurnitureComponent } from './list-furniture/list-furniture.component';

const routes: Routes = [
  {
    path:'',
    component: ListFurnitureComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FurnitureRoutingModule { }
