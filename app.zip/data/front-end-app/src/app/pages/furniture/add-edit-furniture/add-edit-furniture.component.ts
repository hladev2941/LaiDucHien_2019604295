import { Component, ElementRef, Input, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Furniture, IFurniture } from '../furniture.model';
import { NzModalRef } from 'ng-zorro-antd/modal';
import { FurnitureService } from '../furniture.service';
import { AlertService } from 'src/app/_utils/notification.service';
import { NzImageService } from 'ng-zorro-antd/image';

@Component({
  selector: 'app-add-edit-furniture',
  templateUrl: './add-edit-furniture.component.html',
  styleUrls: ['./add-edit-furniture.component.scss']
})
export class AddEditFurnitureComponent implements OnInit {
  addEditForm: FormGroup;
  isSearch: boolean = false;
  isLoading = false;
  selectedImages: any[] = [];
  images: any[] = [];
  deleteImages: any[] = [];
  viewImages: any;
  @Input() data?: IFurniture;
  @Input() view?: boolean;

  @ViewChild("name") name: ElementRef;
  nameErrMsg: any;
  focusOnErrName() {
    this.name.nativeElement.focus();
  }

  @ViewChild("price") price: ElementRef;
  priceErrMsg: any;
  focusOnErrPrice() {
    this.price.nativeElement.focus();
  }

  @ViewChild("files") files: ElementRef;
  filesErrMsg: any;
  focusOnErrFile() {
    this.files.nativeElement.focus();
  }

  constructor(private fb: FormBuilder,
    private modal: NzModalRef,
    private nzImageService: NzImageService,
    private furnitureService: FurnitureService,
    private notification: AlertService) { }

  ngOnInit(): void {
    this.addEditForm = this.fb.group({
      id: [null, []],
      name: [null, [Validators.required]],
      image: [[], []],
      price: [null, [Validators.required]],
      description: [null, []],
      status: [true, []],
    });
    if (this.data) {
      this.onPatch(this.data);
      this.images = this.data.image.split(",");
      this.initViewImages();
    }
    if (this.view) this.addEditForm.disable();
  }

  onPatch(patchData: IFurniture): void {
    this.addEditForm.patchValue({
      id: patchData.id,
      name: patchData.name,
      // image: patchData.image,
      price: patchData.price,
      description: patchData.description,
      status: patchData.status == 1 ? true : false,
    });
  }

  initViewImages() {
    this.furnitureService.getFiles(this.data?.id).subscribe({
      next: (res) => {
        this.viewImages = res.data;
      },
      error: (err) => console.log(err),
    });
  }

  getFromSearch(files: any): Furniture {
    let { name, price, description, status } = this.addEditForm.value;
    return {
      ...new Furniture(),
      id: this.data?.id,
      name: name,
      image: files,
      price: price,
      description: description,
      status: status ? 1 : 0
    };
  }

  handleOk(): void {
    if (this.validateCreate()) {
      this.isLoading = true;

      this.deleteImages.forEach(e => {
        const formData1: FormData = new FormData();
        formData1.append("name", e);
        this.furnitureService.deleteFiles(formData1, this.data.id).subscribe({
          next: (res) => {
          }, error: (err) => {
            this.notification.error("Có lỗi sảy ra trong quá trình thực hiện!");
          }
        })
      })

      const formData2: FormData = new FormData();
      formData2.append("name", this.addEditForm.value.name)
      this.selectedImages.forEach(file => {
        formData2.append('fileUpload', file.file);
      });
      if (this.selectedImages.length > 0) {
        var listFileName = [];
        this.furnitureService.addFiles(formData2).subscribe((res) => {
          listFileName = res.data
          this.furnitureService.save(this.getFromSearch(this.images.length > 0 ? this.images.join(",") + "," + listFileName.join(",") : listFileName.join(","))).subscribe(
            {
              next: (res) => {
                this.isLoading = false;
                this.notification.success("Thao tác thực hiện thành công!");
                this.modal.destroy();
              }, error: (err) => {
                this.notification.error("Có lỗi sảy ra trong quá trình thực hiện!");
              }
            })
        })
      } else {
        this.furnitureService.save(this.getFromSearch(this.images.join(","))).subscribe(
          {
            next: (res) => {
              this.isLoading = false;
              this.notification.success("Thao tác thực hiện thành công!");
              this.modal.destroy();
            }, error: (err) => {
              this.notification.error("Có lỗi sảy ra trong quá trình thực hiện!");
            }
          })
      }
    }
  }

  handleCancel(): void {
    this.modal.destroy();
  }

  validateCreate() {
    let isValid = true;
    if (!this.addEditForm.value.name || !this.addEditForm.value.name.trim()) {
      this.nameErrMsg = "Tên nội thất bắt buộc nhập";
      isValid = false;
      this.focusOnErrName();
    }
    if (!this.addEditForm.value.price) {
      this.priceErrMsg = "Giá trị của nội thất bắt buộc nhập";
      isValid = false;
      this.focusOnErrPrice();
    }
    if (this.selectedImages.length == 0 && this.images.length == 0) {
      this.filesErrMsg = "Vui lòng chọn ảnh cho nội thất";
      isValid = false;
      this.focusOnErrFile();
    }

    return isValid;
  }

  clearNameMessage() {
    this.nameErrMsg = "";
  }

  clearPricelMessage() {
    this.priceErrMsg = "";
  }

  clearFileMessage() {
    this.filesErrMsg = "";
  }

  onFileSelected(event: any): void {
    const files: File[] = event.target.files;
    if (files.length >= 1) this.filesErrMsg = '';
    for (const file of files) {
      const reader = new FileReader();
      reader.onload = (e: any) => {
        this.selectedImages.push({ file: file, url: e.target.result });
      };
      reader.readAsDataURL(file);
    }
  }

  removeImage(image: any): void {
    const index = this.selectedImages.indexOf(image);
    if (index !== -1) {
      this.selectedImages.splice(index, 1);
    }
  }

  previewImage(image): void {
    const data = [
      {
        src: this.viewImages[image],
        alt: ''
      }
    ];
    this.nzImageService.preview(data, { nzZoom: 1, nzRotate: 0 });
  }

  removeImageInSystem(image) {
    this.deleteImages.push(image);
    const index = this.images.indexOf(image);
    if (index !== -1) {
      this.images.splice(index, 1);
    }
  }
}
