import { Component, ElementRef, Input, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NzModalRef } from 'ng-zorro-antd/modal';
import { FurnitureService } from '../furniture.service';
import { AlertService } from 'src/app/_utils/notification.service';
import { ISelect2, Select2 } from 'src/app/_utils/select2.model';

@Component({
  selector: 'app-assign-furniture',
  templateUrl: './assign-furniture.component.html',
  styleUrls: ['./assign-furniture.component.scss']
})
export class AssignFurnitureComponent implements OnInit {

  @ViewChild("building") building: ElementRef;
  buildingErrMsg: any;
  focusOnErrBuilding() {
    this.building.nativeElement.focus();
  }

  @Input() data?: any;
  addEditForm: FormGroup;

  constructor(
    private fb: FormBuilder,
    private modal: NzModalRef,
    private service: FurnitureService,
    private notification: AlertService
  ) { }

  ngOnInit(): void {
    this.addEditForm = this.fb.group({
      building: [null, [Validators.required]],
      room: [null, []]
    });
  }

  isLoading = false
  compareFn = (o1: any, o2: any) => (o1 && o2 ? o1.id === o2.id : o1 === o2);
  
  handleOk() {
    let dataApi = {
      furnitureId: this.data.id,
      buildingId: this.addEditForm.value.building.id,
      rooms: this.addEditForm.value.room
    };

    if( this.validateCreate()){
      this.service.assignFurniture(dataApi).subscribe(
      {
          next: (res) => {
            this.isLoading = false;
            this.notification.success("Thao tác thực hiện thành công!");
            this.modal.destroy();
          }, error: (err) => {
            this.notification.error("Có lỗi sảy ra trong quá trình thực hiện!");
          }
      })
    }
  }

  handleCancel() {

  }

  validateCreate() {
    let isValid = true;
    if (!this.addEditForm.value.building) {
      this.buildingErrMsg = "Bắt buộc phải chọn tòa nhà";
      isValid = false;
      this.focusOnErrBuilding();
    }

    return isValid;
  }
  clearBuildingMessage() {
    this.buildingErrMsg = "";
  }


  isSearch: boolean = false;
  // SELECT2 Building
  totalBuilding: number = 1;
  pageBuilding = 1;
  buildings: ISelect2[] = [];
  selectedValueBuilding: ISelect2;

  loadMoreBuilding(key?: any): void {
    if (this.buildings.length <= this.totalBuilding) {
      this.isLoading = true;
      this.service
        .loadBuilding({
          ...new Select2(),
          key: key ?? '',
          page: this.pageBuilding,
          size: 10,
        })
        .subscribe((res) => {
          if (res != null && res.data) {
            this.buildings = this.buildings.concat(res.data);
            this.pageBuilding += 1;
            this.totalBuilding = res.total;
            this.isLoading = false;
          }
        });
    }
  }

  onSearchBuilding(key?: any): void {
    this.isSearch = true;
    this.pageBuilding = 1;
    this.buildings = [];
    this.loadMoreBuilding(key);
  }

  loadRoom() {
    this.addEditForm.get('room').setValue(null);
    this.onSearchRoom();
  }

  //SELECT2 Room
  totalRoom: number = 1;
  pageRoom = 1;
  rooms: ISelect2[] = [];
  selectedValueRoom: ISelect2;

  loadMoreRoom(key?: any): void {
    if (this.rooms.length <= this.totalRoom) {
      this.isLoading = true;
      if (!this.addEditForm.value.building) {
        this.isLoading = false;
        return;
      }
      this.service
        .loadRoom({
          ...new Select2(),
          key: key ?? '',
          page: this.pageRoom,
          status: 1,
          size: 10,
        }, this.addEditForm.value.building?.id)
        .subscribe((res) => {
          if (res != null && res.data) {
            this.rooms = this.rooms.concat(res.data);
            this.pageRoom += 1;
            this.totalRoom = res.total;
            this.isLoading = false;
          }
        });
    }
  }

  onSearchRoom(key?: any): void {
    this.isSearch = true;
    this.pageRoom = 1;
    this.rooms = [];
    this.loadMoreRoom(key);
  }
}
