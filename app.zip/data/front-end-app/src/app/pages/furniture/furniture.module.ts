import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FurnitureRoutingModule } from './furniture-routing.module';
import { ListFurnitureComponent } from './list-furniture/list-furniture.component';
import { AddEditFurnitureComponent } from './add-edit-furniture/add-edit-furniture.component';
import { ModuleShare } from 'src/app/ng-zorro-antd.module';
import { AssignFurnitureComponent } from './assign-furniture/assign-furniture.component';


@NgModule({
  declarations: [
    ListFurnitureComponent,
    AddEditFurnitureComponent,
    AssignFurnitureComponent
  ],
  imports: [
    CommonModule,
    FurnitureRoutingModule,
    ModuleShare
  ]
})
export class FurnitureModule { }
