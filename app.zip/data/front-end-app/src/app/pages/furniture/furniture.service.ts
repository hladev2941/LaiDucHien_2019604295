import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ResponseAPI } from 'src/app/_utils/response.model';
import { Constants } from '../../_utils/constants';
import { IFurniture } from './furniture.model';

@Injectable({
  providedIn: 'root',
})
export class FurnitureService {
  private baseUrl = Constants.HOST + "/v1/furniture";
  constructor(private http: HttpClient) {}

  search(furniture: IFurniture) {
    return this.http.post<ResponseAPI<IFurniture[]>>(`${this.baseUrl}/search`, furniture);
  }

  save(furniture: IFurniture){
    return this.http.post<ResponseAPI<any>>(`${this.baseUrl}/save`, furniture)
  }

  delete(furniture: IFurniture){
    return this.http.post<ResponseAPI<any>>(`${this.baseUrl}/delete`, furniture)
  }
  
  addFiles(data: any) {
    return this.http.post<ResponseAPI<any>>(`${this.baseUrl}/add-file`, data);
  }

  loadBuilding(data: any) {
    return this.http.post<ResponseAPI<any>>(`${this.baseUrl}/load-building`, data);
  }

  loadRoom(data: any, buildingId: any) {
    return this.http.post<ResponseAPI<any>>(`${this.baseUrl}/load-room/`+buildingId, data);
  }

  deleteFiles(data: any, id: any) {
    return this.http.post<ResponseAPI<any>>(`${this.baseUrl}/delete-file/`+id, data);
  }

  getFiles(furnitureId: any) {
    return this.http.get<ResponseAPI<any>>(`${this.baseUrl}/get-files/` + furnitureId);
  }

  getRooms(data: any) {
    return this.http.post<ResponseAPI<any>>(`${this.baseUrl}/get-rooms`, data);
  }

  assignFurniture(data: any){
    return this.http.post<ResponseAPI<any>>(`${this.baseUrl}/assign-furniture`, data)
  }
}
