import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-report-cus',
  templateUrl: './report-cus.component.html',
  styleUrls: ['./report-cus.component.scss']
})
export class ReportCusComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
