import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { AlertService } from 'src/app/_utils/notification.service';

@Component({
  selector: 'app-report-overview',
  templateUrl: './report-overview.component.html',
  styleUrls: ['./report-overview.component.scss']
})
export class ReportOverviewComponent implements OnInit {

  Highcharts: any = require('highcharts');
  ngAfterViewInit() {
    this.Highcharts.chart('test-2', {
      chart: {
        type: 'pie'
      },
      title: {
        text: 'Tỷ lệ phòng theo các trạng thái'
      },
      series: [{
        name: 'Brands',
        colorByPoint: true,
        data: [{
          name: 'Chrome',
          y: 61.41
        }, {
          name: 'Internet Explorer',
          y: 11.84
        }, {
          name: 'Firefox',
          y: 10.85
        }, {
          name: 'Edge',
          y: 4.67
        }, {
          name: 'Safari',
          y: 4.18
        }, {
          name: 'Other',
          y: 7.05
        }]
      }]
    });

    this.Highcharts.chart('test-3', {
      chart: {
        type: 'column'
      },
      title: {
        text: 'Số phòng được thuê theo các tháng'
      },
      xAxis: {
        categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
      },
      yAxis: {
        title: {
          text: 'Phòng'
        }
      },
      series: [{
        name: '2024',
        data: [150, 200, 250, 300, 350, 400, 450, 500, 550, 600, 650, 700]
      }]
    });
  }

  searchForm: FormGroup;

  constructor(
    private fb: FormBuilder,
    private notification: AlertService,
  ) { }

  ngOnInit(): void {
    this.searchForm = this.fb.group({
      name: [null, []],
      status: [null, []],
    });

    this.search();
  }

  search(){

  }
}
