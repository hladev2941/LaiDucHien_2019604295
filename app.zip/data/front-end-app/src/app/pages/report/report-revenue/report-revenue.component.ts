import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-report-revenue',
  templateUrl: './report-revenue.component.html',
  styleUrls: ['./report-revenue.component.scss']
})
export class ReportRevenueComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
