import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ReportOverviewComponent } from './report-overview/report-overview.component';
import { ReportCusComponent } from './report-cus/report-cus.component';
import { ReportRevenueComponent } from './report-revenue/report-revenue.component';

const routes: Routes = [
  {
    path:"over-view",
    component:ReportOverviewComponent
  },
  {
    path:"cus",
    component:ReportCusComponent
  },
  {
    path:"revenue",
    component:ReportRevenueComponent
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ReportRoutingModule { }
