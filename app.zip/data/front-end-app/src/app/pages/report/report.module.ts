import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ReportRoutingModule } from './report-routing.module';
import { ReportOverviewComponent } from './report-overview/report-overview.component';
import { ReportCusComponent } from './report-cus/report-cus.component';
import { ReportRevenueComponent } from './report-revenue/report-revenue.component';
import { ModuleShare } from 'src/app/ng-zorro-antd.module';


@NgModule({
  declarations: [
    ReportOverviewComponent,
    ReportCusComponent,
    ReportRevenueComponent
  ],
  imports: [
    CommonModule,
    ReportRoutingModule,
    ModuleShare
  ]
})
export class ReportModule { }
