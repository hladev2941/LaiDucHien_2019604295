import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ResponseAPI } from 'src/app/_utils/response.model';
import { Constants } from '../../_utils/constants';
import { INoticeWarning } from './notice-warning.model';

@Injectable({
  providedIn: 'root',
})
export class NoticeWarningService {
  private baseUrl = Constants.HOST + "/v1/notice-warning";
  constructor(private http: HttpClient) {}

  search(NoticeWarning: INoticeWarning) {
    return this.http.post<ResponseAPI<INoticeWarning[]>>(`${this.baseUrl}/search`, NoticeWarning);
  }

  save(NoticeWarning: INoticeWarning){
    return this.http.post<ResponseAPI<any>>(`${this.baseUrl}/save`, NoticeWarning)
  }

  delete(NoticeWarning: INoticeWarning){
    return this.http.post<ResponseAPI<any>>(`${this.baseUrl}/delete`, NoticeWarning)
  }

  runNow(NoticeWarning: INoticeWarning) {
    return this.http.post<ResponseAPI<any>>(`${this.baseUrl}/run-now`, NoticeWarning)
  }
  
  loadBuilding(data: any) {
    return this.http.post<ResponseAPI<any>>(`${this.baseUrl}/load-building`, data);
  }

  loadRoom(data: any) {
    return this.http.post<ResponseAPI<any>>(`${this.baseUrl}/load-room`, data);
  }

  loadUser(data: any) {
    return this.http.post<ResponseAPI<any>>(`${this.baseUrl}/load-user`, data);
  }
}
