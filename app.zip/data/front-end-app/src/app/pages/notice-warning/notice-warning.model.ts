export interface INoticeWarning {
    id?: number;
    title?: string;
    severity?: number;
    description?: string;
    problem?: string;
    typeWarning?: number;
    objectType?: number;
    content?: string;
    objectId?: number;
    objectName?: string;
    lastModifiedBy?: string;
    lastModifiedDate?: string;
    createdBy?: string;
    createdDate?: string;
    page?: number;
    size?: number;
  }
  
  export class NoticeWarning implements INoticeWarning {
    constructor(
      public id?: number,
      public title?: string,
      public severity?: number,
      public description?: string,
      public problem?: string,
      public typeWarning?: number,
      public objectType?: number,
      public content?: string,
      public objectId?: number,
      public objectName?: string,
      public lastModifiedBy?: string,
      public lastModifiedDate?: string,
      public createdBy?: string,
      public createdDate?: string,
      public page?: number,
      public size?: number
    ) {}
  }