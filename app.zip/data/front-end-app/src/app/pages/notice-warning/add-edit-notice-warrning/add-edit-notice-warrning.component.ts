import { Component, ElementRef, Input, OnInit, ViewChild } from '@angular/core';
import { INoticeWarning, NoticeWarning } from '../notice-warning.model';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NzModalRef } from 'ng-zorro-antd/modal';
import { AlertService } from 'src/app/_utils/notification.service';
import { NoticeWarningService } from '../notice-warning.service';
import { ISelect2, Select2 } from 'src/app/_utils/select2.model';

@Component({
  selector: 'app-add-edit-notice-warrning',
  templateUrl: './add-edit-notice-warrning.component.html',
  styleUrls: ['./add-edit-notice-warrning.component.scss']
})
export class AddEditNoticeWarrningComponent implements OnInit {

  addEditForm: FormGroup;
  isSearch: boolean = false;
  isLoading = false;
  @Input() data?: INoticeWarning;
  @Input() view: boolean;

  @ViewChild("title") title: ElementRef;
  titleErrMsg: any;
  focusOnErrTitle() {
    this.title.nativeElement.focus();
  }

  @ViewChild("problem") problem: ElementRef;
  problemErrMsg: any;
  focusOnErrProblem() {
    this.problem.nativeElement.focus();
  }

  @ViewChild("object") object: ElementRef;
  objectErrMsg: any;
  focusOnErrObject() {
    this.object.nativeElement.focus();
  }

  constructor(private fb: FormBuilder,
    private modal: NzModalRef,
    private noticeWarningService: NoticeWarningService,
    private notification: AlertService) { }

  ngOnInit(): void {
    this.addEditForm = this.fb.group({
      id: [null, []],
      title: [null, []],
      problem: [null, []],
      severity: ['0', []],
      description: [null, []],
      typeWarning: [null, []],
      objectType: [null, []],
      object: [null, []],
      content: [null, []],
    });
    if (this.data) {
      this.onPatch(this.data);
      this.selectedValueObject = {
        ...new Select2(),
        id: this.data?.objectId,
        name: this.data?.objectName,
      };
    }
    if (this.view) this.addEditForm.disable();
  }

  onPatch(patchData: INoticeWarning): void {
    this.addEditForm.patchValue({
      id: patchData.id,
      title: patchData.title,
      problem: patchData.problem,
      severity: patchData.severity + "",
      description: patchData.description,
      objectType: patchData.objectType + "",
      typeWarning: patchData.typeWarning + "",
      content: patchData.content
    });
  }

  getFromSearch(): NoticeWarning {
    let { title, problem, severity, description, objectType, typeWarning, content, object} = this.addEditForm.value;
    return {
      ...new NoticeWarning(),
      id: this.data?.id,
      title: title,
      problem: problem,
      severity: Number(severity),
      description: description,
      objectType: Number(objectType),
      typeWarning: Number(typeWarning),
      objectId: object?.id,
      objectName: object?.name,
      content: content
    };
  }

  handleOk(): void {
    if (this.validateCreate()) {
      this.isLoading = true;
      this.noticeWarningService.save(this.getFromSearch()).subscribe(
        {
          next: (res) => {
            this.isLoading = false;
            this.notification.success("Thao tác thực hiện thành công!");
            this.modal.destroy();
          }, error: (err) => {
            this.notification.error("Có lỗi sảy ra trong quá trình thực hiện!");
          }
        })
    }
  }

  handleCancel(): void {
    this.modal.destroy();
  }

  validateCreate() {
    let isValid = true;
    if (!this.addEditForm.value.title || !this.addEditForm.value.title.trim()) {
      this.titleErrMsg = "Tiêu đề bắt buộc nhập";
      isValid = false;
      this.focusOnErrTitle();
    }
    if (!this.addEditForm.value.problem || !this.addEditForm.value.problem.trim()) {
      this.problemErrMsg = "Vấn đề bắt buộc nhập";
      isValid = false;
      this.focusOnErrProblem();
    }

    return isValid;
  }

  clearTitleMessage() {
    this.titleErrMsg = "";
  }

  clearProblemMessage() {
    this.problemErrMsg = "";
  }

  clearObjectMessage() {
    this.objectErrMsg = "";
  }

  compareFn = (o1: any, o2: any) => (o1 && o2 ? o1.id === o2.id : o1 === o2);


  loadObject() {
    this.addEditForm.get('object').setValue(null);
    this.onSearchObject();
  }

  //SELECT2 Object
  totalObject: number = 1;
  pageObject = 1;
  objects: ISelect2[] = [];
  selectedValueObject: ISelect2;
  loadMoreObject(key?: any): void {
    console.log(this.addEditForm.get('objectType').value);
    
    if (this.objects.length <= this.totalObject) {
      this.isLoading = true;
      if (!this.addEditForm.get('objectType').value) {
        return;
      }
      if (this.addEditForm.get('objectType').value == 1) {
        this.noticeWarningService
          .loadBuilding({
            ...new Select2(),
            key: key ?? '',
            page: this.pageObject,
            size: 10,
          })
          .subscribe((res) => {
            if (res != null && res.data) {
              this.objects = this.objects.concat(res.data);
              this.pageObject += 1;
              this.totalObject = res.total;
              this.isLoading = false;
            }
          });
      } else if (this.addEditForm.get('objectType').value == 2) {
        this.noticeWarningService
          .loadRoom({
            ...new Select2(),
            key: key ?? '',
            page: this.pageObject,
            size: 10,
          })
          .subscribe((res) => {
            if (res != null && res.data) {
              this.objects = this.objects.concat(res.data);
              this.pageObject += 1;
              this.totalObject = res.total;
              this.isLoading = false;
            }
          });
      } else {
        this.noticeWarningService
          .loadUser({
            ...new Select2(),
            key: key ?? '',
            page: this.pageObject,
            size: 10,
          })
          .subscribe((res) => {
            if (res != null && res.data) {
              this.objects = this.objects.concat(res.data);
              this.pageObject += 1;
              this.totalObject = res.total;
              this.isLoading = false;
            }
          });
      }
    }
  }

  onSearchObject(key?: any): void {
    this.isSearch = true;
    this.pageObject = 1;
    this.totalObject = 1;
    this.objects = [];
    this.loadMoreObject(key);
  }
}
