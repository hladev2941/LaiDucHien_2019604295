import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { NoticeWarningRoutingModule } from './notice-warning-routing.module';
import { ListNoticeWarrningComponent } from './list-notice-warrning/list-notice-warrning.component';
import { AddEditNoticeWarrningComponent } from './add-edit-notice-warrning/add-edit-notice-warrning.component';
import { ModuleShare } from 'src/app/ng-zorro-antd.module';


@NgModule({
  declarations: [
    ListNoticeWarrningComponent,
    AddEditNoticeWarrningComponent
  ],
  imports: [
    CommonModule,
    NoticeWarningRoutingModule,
    ModuleShare
  ]
})
export class NoticeWarningModule { }
