export interface IAuthResponse {
    exp?: number;
    access_token?: string;
}

export class AuthResponse implements IAuthResponse {
    constructor(
        public exp?: number,
        public access_token?: string,
    ) { }

}