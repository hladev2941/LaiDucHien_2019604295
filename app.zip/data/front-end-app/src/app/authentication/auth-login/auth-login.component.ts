import { Component, HostListener, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { AuthService } from '../auth.service';
import { AlertService } from 'src/app/_utils/notification.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-auth-login',
  templateUrl: './auth-login.component.html',
  styleUrls: ['./auth-login.component.scss']
})
export class AuthLoginComponent implements OnInit {

  loginForm: FormGroup;

  submitForm() {
    if (this.loginForm.valid) {
      // console.log('submit', this.loginForm.value);
      this.login();
    } else {
      Object.values(this.loginForm.controls).forEach(control => {
        if (control.invalid) {
          control.markAsDirty();
          control.updateValueAndValidity({ onlySelf: true });
        }
      });
    }
  }
  constructor( private fb: FormBuilder,private authService: AuthService, private notification: AlertService, private router: Router,) {}

  ngOnInit(): void {
    this.loginForm = this.fb.group({
        username: [null, []],
        password: [null, []],
        remember: [true, []]
    });
  }


  async login() {
     await this.authService.login(this.loginForm.value);
     if(this.authService.isLogin){
        this.router.navigateByUrl("/pages/home")
    }
  }

  @HostListener('document:keypress', ['$event'])
    keyEvent(event: KeyboardEvent) {
        if (event.keyCode === 13) {
            this.submitForm();
        }
    }
}
