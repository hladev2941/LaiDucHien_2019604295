import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ResponseAPI } from 'src/app/_utils/response.model';
import { Constants } from '../_utils/constants';
import { AuthResponse } from './auth-response.model';
import { AlertService } from '../_utils/notification.service';
@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private baseUrl = Constants.HOST + "/v1/user";
  isLogin: any;
  constructor(private http: HttpClient, private notification: AlertService) {}

  getToken(auth: any) {
    return this.http.post<ResponseAPI<AuthResponse>>(`${this.baseUrl}/authenticate`, auth);
  }

  login(data : any): Promise<void>{
    return new Promise((resolve, reject) => {
      this.getToken(data).subscribe((res) => {
        localStorage.setItem("token", res.data.access_token);
        
        const actualExpirationTime = res.data.exp * 1000 + new Date().getTime();
        localStorage.setItem("expirationTime", actualExpirationTime.toString());
        
        this.isLogin = true;
        resolve();
      },(error: HttpErrorResponse) => {
        this.notification.error(error.error.message);
        reject();
      })
    })
  }

  logout(){
    localStorage.removeItem("token");
    localStorage.removeItem("expirationTime");
    this.isLogin = false;
  }

  isAuthenticated() {
    const token = localStorage.getItem("token");
    const expirationTime = localStorage.getItem("expirationTime");
    
    if (token && expirationTime) {
      const isTokenExpired = parseInt(expirationTime) < new Date().getTime();
      if (isTokenExpired) {
        this.logout();
        return false;
      }
      return true;
    }
    return false;
  }
}

