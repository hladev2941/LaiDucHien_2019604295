package vn.hienld.admin.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.mail.internet.MimeMessage;
import jakarta.transaction.Transactional;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;
import org.apache.velocity.runtime.RuntimeConstants;
import org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import vn.hienld.admin.dto.NoticeWarningDTO;
import vn.hienld.admin.error.BadRequestException;
import vn.hienld.admin.model.Account;
import vn.hienld.admin.model.NoticeWarning;
import vn.hienld.admin.repository.AccountRepository;
import vn.hienld.admin.repository.NoticeWarningRepository;
import vn.hienld.admin.service.NoticeWarningService;
import vn.hienld.admin.util.TelegramBotchat;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

@Service
@Slf4j
public class NoticeWarningServiceImpl implements NoticeWarningService {

    @Value(value = "${botchat.telegram.url}")
    private String urlBot;

    @Autowired
    private NoticeWarningRepository noticeWarningRepository;
    @Autowired
    private AccountRepository accountRepository;
    @Autowired
    private ObjectMapper objectMapper;
    @Value("${spring.mail.username}")
    private String fromEmail;
    @Autowired
    private JavaMailSender javaMailSender;
    @Autowired
    private TelegramBotchat telegramBotchat;

    @Override
    public Page<NoticeWarningDTO> findAll(NoticeWarningDTO dto) {
        Pageable pageable = PageRequest.of(dto.getPage() - 1, dto.getSize());
        return noticeWarningRepository.findAll(dto.getTitle(), dto.getProblem(), dto.getSeverity(), pageable)
                .map(p -> objectMapper.convertValue(p, NoticeWarningDTO.class));
    }

    @Override
    public void delete(NoticeWarningDTO dto) {
        try {
            noticeWarningRepository.delete(noticeWarningRepository.getReferenceById(dto.getId()));
        }catch (Exception e){
            log.error("Delete notification exception : {}", e.getMessage());
            throw new BadRequestException("Có lỗi sảy ra trong quá trình thực hiện!");
        }
    }

    @Override
    @Transactional
    public NoticeWarning save(NoticeWarningDTO dto) {
        if(dto.getId() == null){
            return add(dto);
        }
        return update(dto);
    }

    private NoticeWarning add(NoticeWarningDTO dto) {
        NoticeWarning noticeWarning = new NoticeWarning();
        initNoticeWarning(dto, noticeWarning);
        return noticeWarning;
    }

    private NoticeWarning update(NoticeWarningDTO dto) {
        NoticeWarning noticeWarning = noticeWarningRepository.findById(dto.getId()).get();
        initNoticeWarning(dto, noticeWarning);
        return noticeWarning;
    }

    private void initNoticeWarning(NoticeWarningDTO dto, NoticeWarning noticeWarning) {
        noticeWarning.setTitle(dto.getTitle());
        noticeWarning.setProblem(dto.getProblem());
        noticeWarning.setSeverity(dto.getSeverity());
        noticeWarning.setDescription(dto.getDescription());
        noticeWarning.setTypeWarning(dto.getTypeWarning());
        noticeWarning.setObjectType(dto.getObjectType());
        noticeWarning.setObjectId(dto.getObjectId());
        noticeWarning.setObjectName(dto.getObjectName());
        noticeWarning.setContent(dto.getContent());

        noticeWarningRepository.save(noticeWarning);
    }

    @Override
    public void activeNow(NoticeWarningDTO dto) {
        NoticeWarning noticeWarning = noticeWarningRepository.getReferenceById(dto.getId());

        switch (noticeWarning.getObjectType()) {
            case 0 -> {
                log.info("Send warning/notice to all");
                List<Account> data = noticeWarningRepository.getAllAccount();
                if (noticeWarning.getTypeWarning() == 1)
                    sendMail(data, noticeWarning);
                else if (noticeWarning.getTypeWarning() == 2)
                    sendMessageTelegram(data, noticeWarning);
                else {
                    sendMail(data, noticeWarning);
                    sendMessageTelegram(data, noticeWarning);
                }
            }
            case 1 -> {
                log.info("Send warning/notice to building. BuildingId: {}", noticeWarning.getObjectId());
                List<Account> data = noticeWarningRepository.getAccountInBuilding(noticeWarning.getObjectId());
                if (noticeWarning.getTypeWarning() == 1)
                    sendMail(data, noticeWarning);
                else if (noticeWarning.getTypeWarning() == 2)
                    sendMessageTelegram(data, noticeWarning);
                else {
                    sendMail(data, noticeWarning);
                    sendMessageTelegram(data, noticeWarning);
                }
            }
            case 2 -> {
                log.info("Send warning/notice to room. RoomId: {}", noticeWarning.getObjectId());
                List<Account> data = noticeWarningRepository.getAccountInRoom(noticeWarning.getObjectId());
                if (noticeWarning.getTypeWarning() == 1)
                    sendMail(data, noticeWarning);
                else if (noticeWarning.getTypeWarning() == 2)
                    sendMessageTelegram(data, noticeWarning);
                else {
                    sendMail(data, noticeWarning);
                    sendMessageTelegram(data, noticeWarning);
                }
            }
            case 3 -> {
                log.info("Send warning/notice to person. UserId: {}", noticeWarning.getObjectId());
                List<Account> data = new ArrayList<>();
                data.add(accountRepository.getReferenceById(noticeWarning.getObjectId()));

                if (noticeWarning.getTypeWarning() == 1)
                    sendMail(data, noticeWarning);
                else if (noticeWarning.getTypeWarning() == 2)
                    sendMessageTelegram(data, noticeWarning);
                else {
                    sendMail(data, noticeWarning);
                    sendMessageTelegram(data, noticeWarning);
                }
            }
            default -> {
                log.error("Cannot get type of warning! warningId: {}", dto.getId());
                throw new BadRequestException("Cannot get type of warning!");
            }
        }
    }

    @SneakyThrows
    private void sendMessageTelegram(List<Account> data, NoticeWarning noticeWarning) {
        for (Account e: data) {
            String message = "Kính gửi: Ông/Bà "+ e.getFullName() +"\n" +
                    "Ông/bà nhận được mail này để cảnh báo về vấn đề "+ noticeWarning.getProblem() + "\n" +
                    "Mức độ cảnh báo: " + noticeWarning.getSeverity() + "\n" +
                    "Nội dung cảnh báo: " +  noticeWarning.getContent() +"\n" +
                    "Ghi chú: " + noticeWarning.getDescription() + "\n" +
                    "Trân trọng./.";
            String encodedMessage = URLEncoder.encode(message, "UTF-8");
            sendNotification(encodedMessage);
        }
    }

    private void sendNotification(String message){
        String urlString = urlBot + message;
        System.out.println(urlString);
        try {
            URL url = new URL(urlString);
            URLConnection conn = url.openConnection();
            InputStream is = new BufferedInputStream(conn.getInputStream());

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void sendMail(List<Account> data, NoticeWarning noticeWarning) {
        for (Account account:data) {
            toDoSendMail(account, noticeWarning);
        }
    }

    @Async
    public void toDoSendMail(Account data, NoticeWarning noticeWarning) {
        VelocityEngine velocityEngine = new VelocityEngine();
        velocityEngine.setProperty(RuntimeConstants.RESOURCE_LOADER, "classpath");
        velocityEngine.setProperty("classpath.resource.loader.class", ClasspathResourceLoader.class.getName());
        velocityEngine.setProperty("input.encoding", "UTF-8");
        velocityEngine.setProperty("output.encoding", "UTF-8");
        velocityEngine.setProperty("response.encoding", "UTF-8");
        velocityEngine.init();

        VelocityContext context = new VelocityContext();
        context.put("name",data.getFullName());
        context.put("problem", noticeWarning.getProblem());
        context.put("severity", noticeWarning.getSeverity());
        context.put("content", noticeWarning.getContent());
        context.put("description", noticeWarning.getDescription());

        StringWriter writer = new StringWriter();
        velocityEngine.mergeTemplate("template/mail-warning.vm", "UTF-8", context, writer);
        String emailContent = writer.toString();

        try {
            MimeMessage mimeMessage = javaMailSender.createMimeMessage();
            MimeMessageHelper mimeMessageHelper = new MimeMessageHelper(mimeMessage, true, "UTF-8");
            mimeMessageHelper.setFrom(fromEmail);
            if (data.getEmail().isEmpty()) {
                throw new BadRequestException("Can't send email");
            }
            mimeMessageHelper.setTo(data.getEmail());
            mimeMessageHelper.setSubject(noticeWarning.getTitle());
            mimeMessageHelper.setText(emailContent, true);
            javaMailSender.send(mimeMessage);
        } catch (Exception e) {
            throw new BadRequestException("Can't send email");
        }

    }



}
