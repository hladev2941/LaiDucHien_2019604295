package vn.hienld.admin.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
public class AutoSyncRoomDTO {
    private Integer status;
    private Integer amountOfPeople;
    private Integer electricFee;
    private Integer waterFee;
    private Integer internetFee;
    private Integer environmentFee;
    private Integer rent;
    private Integer parkingFee;
    private Integer buildingId;
    private String buildingName;
    private String description;
    private Integer area;
    private Integer amountRooms;
    private List<Floor> floors;
}
