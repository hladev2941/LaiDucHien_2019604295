package vn.hienld.admin.dto;

import lombok.Data;

@Data
public class Floor
{
    private Integer floor;
    private Integer amountOfRoom;
}
