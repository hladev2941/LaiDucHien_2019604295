package vn.hienld.admin.dto;

import lombok.Data;

@Data
public class ReportOverviewDTO {
    private Integer buildingId ;
    private Integer year;
}
