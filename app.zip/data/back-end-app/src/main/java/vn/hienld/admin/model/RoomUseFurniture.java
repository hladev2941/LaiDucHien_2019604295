package vn.hienld.admin.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity(name = "room_use_furniture")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class RoomUseFurniture {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;
    private Integer furnitureId;
    private Integer roomId;
    private Integer buildingId;
}
