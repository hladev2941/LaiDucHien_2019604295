package vn.hienld.admin.dto.view;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
public class PeopleInRoomView {
    private Integer id;
    private String fullName;
    private String phone;
    private LocalDateTime dob;
    private String citizenIdentificationNumber;
    private Integer gender;
}
