package vn.hienld.admin.dto.view;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class RoomUseFurnitureView {
    private Integer id;
    private String roomName;
}
