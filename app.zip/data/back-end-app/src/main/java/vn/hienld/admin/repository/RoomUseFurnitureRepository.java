package vn.hienld.admin.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import vn.hienld.admin.dto.FurnitureDTO;
import vn.hienld.admin.model.Furniture;
import vn.hienld.admin.model.RoomUseFurniture;

import java.util.List;

public interface RoomUseFurnitureRepository extends JpaRepository<RoomUseFurniture, Integer> {
    @Query(value = "select count(*) from room_use_furniture where furnitureId = ?1 and roomId = ?2", nativeQuery = true)
    Integer checkFurnitureUsedAtRoomId(Integer furnitureId, Integer roomId);

    @Query("select f from furniture f where f.id in (select r.furnitureId from room_use_furniture r where r.roomId = ?1)")
    List<Furniture> loadInfoFurnitureForRoom(Integer roomId);
}
