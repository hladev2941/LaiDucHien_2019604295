package vn.hienld.admin.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import vn.hienld.admin.dto.Select2DTO;
import vn.hienld.admin.dto.view.PeopleInRoomView;
import vn.hienld.admin.model.PeopleInRoom;

import java.util.List;

public interface PeopleInRoomRepository extends JpaRepository<PeopleInRoom, Integer> {
    @Modifying
    @Query(value = "update people_in_room set status = 0 where roomId = ?1 and contractId = ?2 and (?3 is null or customerId not in ?3)")
    void deleteByRoomId(Integer roomId, Integer contractId, List<Integer> cusIds);
    @Query(value =
            "select new vn.hienld.admin.dto.view.PeopleInRoomView(u.customerId,  u.customerName, a.phone, a.dob, a.citizenIdentificationNumber, a.gender) " +
                    "from people_in_room u inner join account a on u.customerId = a.id where 1 = 1 " +
                    "and (:roomId is null or u.roomId = :roomId) and u.contractId = :contractId and u.status = 1")
    List<PeopleInRoomView> findPeopleInRoom(Integer roomId, Integer contractId);
}
