package vn.hienld.admin.controller;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StopWatch;
import org.springframework.web.bind.annotation.*;
import vn.hienld.admin.dto.*;
import vn.hienld.admin.model.Booking;
import vn.hienld.admin.service.BookingService;
import vn.hienld.admin.service.BuildingService;
import vn.hienld.admin.service.RoomService;

@RestController
@RequestMapping("/v1/booking")
@Slf4j
@CrossOrigin("*")
public class BookingController {
    private final String START_LOG = "Booking {}";
    private final String END_LOG = "Booking {} finished in: {}";

    @Autowired
    private BookingService bookingService;
    @Autowired
    RoomService roomService;
    @Autowired
    BuildingService buildingService;

    @PostMapping("/search")
    public ResponseEntity<BaseResponse> search(@RequestBody BookingDTO dto) {
        final String action = "Search Booking";
        StopWatch sw = new StopWatch();
        sw.start();
        log.info(START_LOG, action);

        BaseResponse baseResponse = new BaseResponse();
        Page<BookingDTO> data = bookingService.findAll(dto);
        baseResponse.setErr_code("0");
        baseResponse.setData(data.getContent());
        baseResponse.setTotal(data.getTotalElements());

        sw.stop();
        log.info(END_LOG, action, sw.getTotalTimeSeconds());

        return new ResponseEntity<BaseResponse>(baseResponse, HttpStatus.OK);
    }

    @PostMapping("/save")
    public ResponseEntity<BaseResponse> save(@RequestBody BookingDTO dto) {
        final String action = "Breate Booking";
        StopWatch sw = new StopWatch();
        sw.start();
        log.info(START_LOG, action);

        BaseResponse baseResponse = new BaseResponse();
        Booking data = bookingService.save(dto);
        baseResponse.setErr_code("0");
        baseResponse.setMessage("Created Booking successfully!");
        baseResponse.setData(data);

        sw.stop();
        log.info(END_LOG, action, sw.getTotalTimeSeconds());

        return new ResponseEntity<BaseResponse>(baseResponse, HttpStatus.OK);
    }

    @PostMapping("/delete")
    public ResponseEntity<BaseResponse> delete(@RequestBody BookingDTO dto) {
        final String action = "Delete Booking";
        StopWatch sw = new StopWatch();
        sw.start();
        log.info(START_LOG, action);

        BaseResponse baseResponse = new BaseResponse();
        bookingService.delete(dto);
        baseResponse.setErr_code("0");
        baseResponse.setMessage("Deleted Booking successfully!");

        sw.stop();
        log.info(END_LOG, action, sw.getTotalTimeSeconds());

        return new ResponseEntity<BaseResponse>(baseResponse, HttpStatus.OK);
    }

    @PostMapping("/change-status")
    public ResponseEntity<BaseResponse> changeStatus(@RequestBody BookingDTO dto) {
        final String action = "Change status Booking";
        StopWatch sw = new StopWatch();
        sw.start();
        log.info(START_LOG, action);

        BaseResponse baseResponse = new BaseResponse();
        bookingService.changeStatus(dto);
        baseResponse.setErr_code("0");
        baseResponse.setMessage("Change status Booking successfully!");

        sw.stop();
        log.info(END_LOG, action, sw.getTotalTimeSeconds());

        return new ResponseEntity<BaseResponse>(baseResponse, HttpStatus.OK);
    }

    @PostMapping("/load-building")
    public ResponseEntity<BaseResponse> loadBuilding(@RequestBody Select2DTO dto) {
        final String action = "Load building";
        StopWatch sw = new StopWatch();
        sw.start();
        log.info(START_LOG, action);

        BaseResponse baseResponse = new BaseResponse();

        BuildingDTO buildingDTO = new BuildingDTO();
        buildingDTO.setName(dto.getKey());
        buildingDTO.setPage(dto.getPage());
        buildingDTO.setSize(dto.getSize());

        Page<BuildingDTO> data = buildingService.findAll(buildingDTO);
        baseResponse.setErr_code("0");
        baseResponse.setData(data.getContent());
        baseResponse.setTotal(data.getTotalElements());

        sw.stop();
        log.info(END_LOG, action, sw.getTotalTimeSeconds());

        return new ResponseEntity<BaseResponse>(baseResponse, HttpStatus.OK);
    }

    @PostMapping("/load-room/{buildingId}")
    public ResponseEntity<BaseResponse> loadRoom(@PathVariable Integer buildingId, @RequestBody Select2DTO dto) {
        final String action = "Load room";
        StopWatch sw = new StopWatch();
        sw.start();
        log.info(START_LOG, action);

        BaseResponse baseResponse = new BaseResponse();

        RoomDTO roomDTO = new RoomDTO();
        roomDTO.setName(dto.getKey());
        roomDTO.setBuildingId(buildingId);
        roomDTO.setStatus(dto.getStatus());
        roomDTO.setPage(dto.getPage());
        roomDTO.setSize(dto.getSize());

        Page<RoomDTO> data = roomService.findByBuildingId(roomDTO);
        baseResponse.setErr_code("0");
        baseResponse.setData(data.getContent());
        baseResponse.setTotal(data.getTotalElements());

        sw.stop();
        log.info(END_LOG, action, sw.getTotalTimeSeconds());

        return new ResponseEntity<BaseResponse>(baseResponse, HttpStatus.OK);
    }
}
