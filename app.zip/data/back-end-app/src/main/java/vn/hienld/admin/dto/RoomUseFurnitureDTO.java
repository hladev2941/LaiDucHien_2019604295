package vn.hienld.admin.dto;

import lombok.Data;

import java.util.List;
import java.util.Map;

@Data
public class RoomUseFurnitureDTO {
    private Integer furnitureId;
    private List<RoomDTO> rooms;
    private Integer buildingId;
}
