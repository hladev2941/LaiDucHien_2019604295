package vn.hienld.admin.util;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;

@Service
public class TelegramBotchat {

    @Value(value = "${botchat.telegram.url}")
    private String urlBot;

     public void sendNotification(String message){
         String urlString = urlBot + message;
         try {
             URL url = new URL(urlString);
             URLConnection conn = url.openConnection();
             InputStream is = new BufferedInputStream(conn.getInputStream());
         } catch (IOException e) {
             e.printStackTrace();
         }
     }
}
