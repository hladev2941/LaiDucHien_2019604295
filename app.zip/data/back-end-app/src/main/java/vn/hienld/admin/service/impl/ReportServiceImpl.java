package vn.hienld.admin.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import vn.hienld.admin.dto.ReportOverviewDTO;
import vn.hienld.admin.repository.RoomRepository;
import vn.hienld.admin.service.ReportService;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class ReportServiceImpl implements ReportService {
    @Autowired
    private RoomRepository roomRepository;
    @Override
    public Map<String, Object> reportOverView(ReportOverviewDTO dto) {
        List<Integer> data = new ArrayList<>();
        for (int i = 1; i <= 12 ; i++) {
            Integer item = roomRepository.countRoomForReportOverview(i, dto.getYear(), dto.getBuildingId());
            data.add(item);
        }
        Map<String, Object> result = new HashMap<>();
        result.put("data_chart1", data);
        result.put("numberOfRoomsRented", roomRepository.countByStatus(1, dto.getBuildingId()));
        result.put("numberOfRoomsBooked", roomRepository.countByStatus(2, dto.getBuildingId()));
        result.put("numberOfRoomsEmpty", roomRepository.countByStatus(0, dto.getBuildingId()));
        
        return result;
    }

    @Override
    public Map<String, Object> reportCus(ReportOverviewDTO dto) {
        return null;
    }

    @Override
    public Map<String, Object> reportRevenue(ReportOverviewDTO dto) {
        return null;
    }
}
