package vn.hienld.admin.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import vn.hienld.admin.dto.AutoSyncRoomDTO;
import vn.hienld.admin.dto.BuildingDTO;
import vn.hienld.admin.dto.Floor;
import vn.hienld.admin.dto.Select2DTO;
import vn.hienld.admin.error.BadRequestException;
import vn.hienld.admin.model.Account;
import vn.hienld.admin.model.Building;
import vn.hienld.admin.model.Room;
import vn.hienld.admin.model.ServicePackage;
import vn.hienld.admin.repository.AccountRepository;
import vn.hienld.admin.repository.BuildingRepository;
import vn.hienld.admin.repository.RoomRepository;
import vn.hienld.admin.repository.ServicePackageRepository;
import vn.hienld.admin.service.BuildingService;
import vn.hienld.admin.util.DataFormat;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
@Slf4j
public class BuildingServiceImpl implements BuildingService {

    @Autowired
    BuildingRepository buildingRepository;
    @Autowired
    ObjectMapper objectMapper;
    @Autowired
    private AccountRepository accountRepository;
    @Autowired
    private RoomRepository roomRepository;
    @Autowired
    private ServicePackageRepository servicePackageRepository;

    @Override
    public Page<BuildingDTO> findAll(BuildingDTO dto) {
        Pageable pageable = PageRequest.of(dto.getPage() - 1, dto.getSize());
        return buildingRepository.findAll(dto.getName(), dto.getAddressDetail(), dto.getCityId(), dto.getDistrictId(), dto.getWardId(), dto.getStatus(), pageable)
                .map(p -> objectMapper.convertValue(p, BuildingDTO.class));
    }

    @Override
    @Transactional
    public Building save(BuildingDTO dto) {
        if(dto.getId() == null){
            return add(dto);
        }
        return update(dto);
    }

    public Building add(BuildingDTO dto) {
        Building building = new Building();
        buildEntity(dto, building);

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();
        Optional<Account> acc = accountRepository.findByUsername(username);
        building.setAccountId(acc.get().getId());

        return buildingRepository.save(building);
    }

    public Building update(BuildingDTO dto) {
        Building building = buildingRepository.getReferenceById(dto.getId());

        if(dto.getStatus() == 1 && building.getStatus() == 0){
            roomRepository.updateStatusByBuildingId(building.getId(), 1);
        }

        if(dto.getStatus() == 0 && building.getStatus() == 1){
            throw new BadRequestException("Bạn phải thay đổi trạng thái phòng trong tòa nhà để có thể thay đổi trạng thái tòa nhà!");
        }

        buildEntity(dto, building);
        return buildingRepository.save(building);
    }

    private void buildEntity(BuildingDTO dto, Building building) {
        building.setName(dto.getName());
        building.setAddressDetail(dto.getAddressDetail());
        building.setAmountRooms(dto.getAmountRooms());
        building.setStatus(dto.getStatus());
        building.setCityId(dto.getCityId());
        building.setDistrictId(dto.getDistrictId());
        building.setWardId(dto.getWardId());
        building.setCityName(dto.getCityName());
        building.setDistrictName(dto.getDistrictName());
        building.setWardName(dto.getWardName());
        building.setFloors(dto.getFloors());
        building.setDescription(dto.getDescription());
    }

    @Override
    @Transactional
    public void syncRoom(AutoSyncRoomDTO dto) {
        List<Room> rooms = new ArrayList<>();
        roomRepository.deleteRoomByBuildingId(dto.getBuildingId());

        for (Floor floor: dto.getFloors()) {
            for (int i = 0; i < floor.getAmountOfRoom(); i++) {
                String name = i+1 >= 10 ?
                        String.valueOf(floor.getFloor()) + String.valueOf(i+1) : String.valueOf(floor.getFloor()) + "0" + String.valueOf(i+1);
                Room room = getRoom(dto, floor, name);
                rooms.add(room);
            }
        }

        if(dto.getStatus() != 0){
            Building building = buildingRepository.getReferenceById(dto.getBuildingId());
            building.setStatus(1);

            buildingRepository.save(building);
        }else {
            Building building = buildingRepository.getReferenceById(dto.getBuildingId());
            building.setStatus(0);

            buildingRepository.save(building);
        }

        roomRepository.saveAllAndFlush(rooms);
    }

    private static Room getRoom(AutoSyncRoomDTO dto, Floor floor, String name) {
        Room room = new Room();
        room.setAmountOfPeople(dto.getAmountOfPeople());
        room.setElectricFee(dto.getElectricFee());
        room.setEnvironmentFee(dto.getEnvironmentFee());
        room.setInternetFee(dto.getInternetFee());
        room.setWaterFee(dto.getWaterFee());
        room.setStatus(dto.getStatus());
        room.setRent(dto.getRent());
        room.setParkingFee(dto.getParkingFee());
        room.setBuildingName(dto.getBuildingName());
        room.setDescription(dto.getDescription());
        room.setBuildingId(dto.getBuildingId());
        room.setName(name);
        room.setFloor(floor.getFloor());
        room.setArea(dto.getArea());
        return room;
    }

    @Override
    public List<Map<String, Object>> viewRooms(Integer buildingId, Integer floor) {
        return roomRepository.getDataToViewRooms(buildingId, floor);
    }

    @Override
    @Transactional
    public void delete(BuildingDTO dto) {
        try{
            //Xóa tất cả các phòng
            roomRepository.deleteRoomByBuildingId(dto.getId());
            //Xóa tòa nhà
            buildingRepository.delete(buildingRepository.getReferenceById(dto.getId()));
        }catch (Exception ex){
            log.error("Delete building exception : {}", ex.getMessage());
            throw new BadRequestException("Có lỗi sảy ra trong quá trình thực hiện!");
        }
    }

    @Override
    public Page<Map<String, Object>> findDiaChiByChaId(Select2DTO dto) {
        Pageable pageable = PageRequest.of(dto.getPage() - 1, dto.getSize());
        return buildingRepository.findDiaChiByChaId(dto.getCha_id(), DataFormat.lower(dto.getKey()), pageable);
    }
}
