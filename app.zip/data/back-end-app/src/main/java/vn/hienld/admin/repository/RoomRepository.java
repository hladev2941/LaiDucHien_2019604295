package vn.hienld.admin.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Range;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import vn.hienld.admin.model.Room;

import java.util.List;
import java.util.Map;

public interface RoomRepository extends JpaRepository<Room, Integer> {
    @Query(value = "SELECT u FROM room u where 1 = 1 " +
            "and (?1 is null or lower(u.name) like lower('%' || ?1 || '%') ) " +
            "and (?2 is null or u.buildingId = ?2) " +
            "and (?3 is null or u.rent >= ?3) and (?4 is null or u.rent <= ?4)"  +
            "and (?5 is null or u.status = ?5) " +
            "ORDER BY u.createdDate desc")
    Page<Room> findAll(String name, Integer buildingId, Integer rentFrom, Integer rentTo, Integer status, Pageable pageable);

    @Modifying
    @Query(value = "delete from room where buildingId = ?1", nativeQuery = true)
    void deleteRoomByBuildingId(Integer buildingId);

    @Query(value = "SELECT u FROM room u where 1 = 1 " +
            "and (?1 is null or lower(u.name) like lower('%' || ?1 || '%') ) " +
            "and u.buildingId = ?2 and (?3 is null or u.status = ?3)" +
            "ORDER BY u.createdDate desc, u.name")
    Page<Room> findByBuildingId(String name, Integer buildingId, Integer status, Pageable pageable);

    @Query(value = "select r.name as name, r.status as status from room r where r.buildingId = ?1 and r.floor = ?2")
    List<Map<String, Object>> getDataToViewRooms(Integer buildingId, Integer floor);

//    @Modifying
//    @Query(value = "update room set status = ?2 where id = ?1", nativeQuery = true)
//    void updateStatusRoom(Integer roomId, Integer status);

    @Query(value = "select (select count(*) from contract c where MONTH(c.createdDate) = ?1 and YEAR(c.createdDate) = ?2 and c.status = 1 and c.buildingId = ?3 ) + \n" +
            "(select count(*) from booking b where MONTH(b.createdDate) = ?1 and YEAR(b.createdDate) = ?2 and b.buildingId = ?3) as data", nativeQuery = true)
    Integer countRoomForReportOverview(Integer month, Integer year, Integer buildingId);

    @Query(value = "SELECT u FROM room u where 1 = 1 " +
            "and (?1 is null or lower(u.name) like lower('%' || ?1 || '%') ) " +
            "and u.buildingId = ?2 and (?3 is null or u.status <> ?3)" +
            "ORDER BY u.createdDate desc, u.name")
    Page<Room> findForContract(String name, Integer buildingId, Integer status, Pageable pageable);

    Integer countAllByBuildingId(Integer buildingId);

    @Query(value = "select count(*) from room r where r.status <> 0 and r.buildingId = ?1", nativeQuery = true)
    Integer countAllByStatus(Integer buildingId);

    @Query(value = "select count(*) from room r where r.status = ?1 and r.buildingId = ?2", nativeQuery = true)
    Integer countByStatus(Integer status, Integer buildingId);

    @Query(value = "SELECT u FROM room u where 1 = 1 " +
            "and (?1 is null or lower(u.name) like lower('%' || ?1 || '%') ) " +
            "and u.buildingId = ?2 and (?3 is null or u.status = ?3)" +
            "ORDER BY u.createdDate desc, u.name")
    Page<Room> findForBill(String name, Integer buildingId, Integer status, Pageable pageable);

    @Modifying
    @Query(value = "update room r set r.status = ?2 where r.buildingId = ?1")
    void updateStatusByBuildingId(Integer id, Integer status);
}
