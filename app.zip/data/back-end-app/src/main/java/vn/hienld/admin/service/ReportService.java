package vn.hienld.admin.service;

import vn.hienld.admin.dto.ReportOverviewDTO;

import java.util.Map;

public interface ReportService {
    Map<String, Object> reportOverView(ReportOverviewDTO dto);
    Map<String, Object> reportCus(ReportOverviewDTO dto);
    Map<String, Object> reportRevenue(ReportOverviewDTO dto);
}
